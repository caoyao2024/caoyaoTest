// Layer 4: 产品公告 — 右下角悬浮组件：收起为胶囊按钮，展开为公告面板（轮播 + 左右切换 + 指示点），点击公告查看详情
import { useEffect, useRef, useState } from "react";
import { IconPlusIcPublicChevronDown, IconPlusIcPublicHorn, IconPlusIcPublicLeftArrow, IconPlusIcPublicRightArrow } from '@hui/icon-plus';
import Dialog from "@nce/eview-react/Dialog";
import Tag from "@/shared/Tag";
import { ANNOUNCEMENTS } from "../../mock/dashboard.jsx";
import "./index.css";

const AUTOPLAY_INTERVAL = 5000;

// 手写轮播（eview-react 无 Carousel 对应组件）
function useCarousel({ children, autoPlay, autoPlaySpeed, onSlideChange }) {
  const [index, setIndex] = useState(0);
  const total = children.length;
  const timerRef = useRef(null);

  useEffect(() => {
    if (!autoPlay || total <= 1) return undefined;
    timerRef.current = setInterval(() => {
      setIndex((prev) => (prev + 1) % total);
    }, autoPlaySpeed || AUTOPLAY_INTERVAL);
    return () => clearInterval(timerRef.current);
  }, [autoPlay, autoPlaySpeed, total]);

  useEffect(() => {
    if (onSlideChange) onSlideChange(index);
  }, [index, onSlideChange]);

  const goTo = (i) => setIndex(((i % total) + total) % total);
  const prev = () => goTo(index - 1);
  const next = () => goTo(index + 1);

  return { index, total, prev, next, goTo, current: children[index] };
}

export default function AnnouncementBar() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [detail, setDetail] = useState(null);
  const [slideIndex, setSlideIndex] = useState(0);

  const slides = ANNOUNCEMENTS.map((item) => (
    <div key={item.id} className="announce-slide" onClick={() => setDetail(item)}>
      <div className="announce-slide-top">
        <Tag color={item.tagColor} className="announce-tag">{item.tag}</Tag>
        <span className="announce-slide-date">{item.date}</span>
      </div>
      <p className="announce-slide-title">{item.title}</p>
      <p className="announce-slide-desc">{item.description}</p>
    </div>
  ));

  const carousel = useCarousel({
    children: slides,
    autoPlay: true,
    autoPlaySpeed: AUTOPLAY_INTERVAL,
    onSlideChange: setSlideIndex,
  });

  return (
    <div className="announce-float">
      {isExpanded ? (
        <div className="announce-panel">
          <div className="announce-panel-head">
            <span className="announce-icon">
              <IconPlusIcPublicHorn iconSize="0.875rem" iconColor={['currentcolor']} />
            </span>
            <span className="announce-panel-title">产品公告</span>
            <button
              type="button"
              className="announce-collapse"
              title="收起公告"
              aria-label="收起公告"
              onClick={() => setIsExpanded(false)}
            >
              <IconPlusIcPublicChevronDown iconSize="0.875rem" iconColor={['currentcolor']} />
            </button>
          </div>
          <div className="announce-panel-body">
            <button type="button" className="announce-arrow" title="上一条" aria-label="上一条" onClick={carousel.prev}>
              <IconPlusIcPublicLeftArrow iconSize="0.875rem" iconColor={['currentcolor']} />
            </button>
            <div className="announce-carousel">
              {carousel.current}
            </div>
            <button type="button" className="announce-arrow" title="下一条" aria-label="下一条" onClick={carousel.next}>
              <IconPlusIcPublicRightArrow iconSize="0.875rem" iconColor={['currentcolor']} />
            </button>
          </div>
          <div className="announce-dots">
            {ANNOUNCEMENTS.map((_, i) => (
              <span
                key={i}
                className={`announce-dot ${i === slideIndex ? "is-active" : ""}`}
                onClick={() => carousel.goTo(i)}
              />
            ))}
          </div>
        </div>
      ) : (
        <button
          type="button"
          className="announce-fab-btn"
          title="展开产品公告"
          aria-label="展开产品公告"
          onClick={() => setIsExpanded(true)}
        >
          <IconPlusIcPublicHorn iconSize="1rem" iconColor={['currentcolor']} className="announce-fab-icon" />
          <span>产品公告</span>
          <span className="announce-fab-count">{ANNOUNCEMENTS.length}</span>
        </button>
      )}

      <Dialog
        isOpen={Boolean(detail)}
        title={
          detail ? (
            <span className="announce-detail-title">
              <Tag color={detail.tagColor} className="announce-tag">{detail.tag}</Tag>
              {detail.title}
            </span>
          ) : (
            ""
          )
        }
        onClose={() => setDetail(null)}
        size={[512, "auto"]}
      >
        {detail ? (
          <div className="announce-detail">
            <p className="announce-detail-date">发布于 {detail.date}</p>
            <p className="announce-detail-text">{detail.description}</p>
            <p className="announce-detail-note">如需了解升级节奏与影响范围，请联系产品团队或在团队管理页查看排期。</p>
          </div>
        ) : null}
      </Dialog>
    </div>
  );
}
