// Layer 4: 筛选条 — 关键词搜索 / 时间范围切换 / 行业下拉 / 导出下拉，联动下方所有数据区
import { useState } from "react";
import { IconPlusIcPublicChevronDown, IconPlusIcPublicDownload, IconPlusIcPublicExcleFileTextured, IconPlusIcPublicTxtFileTextured } from '@hui/icon-plus';
import Button from "@nce/eview-react/Button";
import SelectCard from "@nce/eview-react/SelectCard";
import TextField from "@/shared/TextField";
import Select from "@/shared/Select";
import { useApp } from "../../context.jsx";
import { CUSTOMER_COUNTS, INDUSTRY_OPTIONS, TIME_RANGES, getRiskCustomers } from "../../mock/dashboard.jsx";
import "./index.css";

const EXPORT_MENU_ITEMS = [
  { key: "excel", label: "导出 Excel", icon: <IconPlusIcPublicExcleFileTextured iconSize="0.875rem" iconColor={['currentcolor']} /> },
  { key: "pdf", label: "导出 PDF", icon: <IconPlusIcPublicTxtFileTextured iconSize="0.875rem" iconColor={['currentcolor']} /> },
];

export default function FilterBar() {
  const { timeRange, setTimeRange, industry, setIndustry, keyword, setKeyword, notify } = useApp();
  const [exportOpen, setExportOpen] = useState(false);

  const customerTotal = CUSTOMER_COUNTS[industry] != null ? CUSTOMER_COUNTS[industry] : CUSTOMER_COUNTS["全部行业"];
  const riskCount = getRiskCustomers(timeRange, industry, keyword).length;
  const isFilterActive = industry !== "全部行业" || keyword.trim() !== "";

  const handleExport = ({ key }) => {
    const format = key === "excel" ? "Excel" : "PDF";
    notify("success", `正在导出当前筛选结果（${format}），共 ${riskCount} 条风险记录…`);
    setExportOpen(false);
  };

  const handleReset = () => {
    setKeyword("");
    setIndustry("全部行业");
    setTimeRange("30d");
    notify("default", "已重置筛选条件");
  };

  const timeRangeData = TIME_RANGES.map((range) => ({ text: range.label, value: range.key }));
  const industryOptions = INDUSTRY_OPTIONS.map((item) => ({ value: item, text: item }));

  return (
    <section className="filter-bar">
      <TextField
        className="filter-search"
        value={keyword}
        onChange={(value) => setKeyword(value)}
        placeholder="搜索客户、行业或负责人"
      />
      <SelectCard
        value={timeRange}
        onChange={(value) => setTimeRange(value)}
        data={timeRangeData}
      />
      <Select
        className="filter-industry"
        value={industry}
        onChange={(value) => setIndustry(value)}
        options={industryOptions}
      />
      <span className="filter-summary">
        在管客户 {customerTotal} 家 · 风险记录 {riskCount} 条
      </span>
      {isFilterActive ? (
        <a className="filter-reset" onClick={handleReset}>重置筛选</a>
      ) : null}
      <div className="filter-export-dropdown">
        <Button
          text="导出"
          leftIcon={<IconPlusIcPublicDownload iconSize="0.875rem" iconColor={['currentcolor']} />}
          rightIcon={<IconPlusIcPublicChevronDown iconSize="0.875rem" iconColor={['currentcolor']} />}
          onClick={() => setExportOpen((open) => !open)}
        />
        {exportOpen ? (
          <>
            <div className="dropdown-backdrop" onClick={() => setExportOpen(false)} />
            <ul className="dropdown-menu">
              {EXPORT_MENU_ITEMS.map((item) => (
                <li
                  key={item.key}
                  className="dropdown-menu-item"
                  onClick={() => handleExport({ key: item.key })}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </li>
              ))}
            </ul>
          </>
        ) : null}
      </div>
    </section>
  );
}
