// Layer 3: 客户健康状态标签 — 按级别分色（健康=success / 观察=warning / 风险=error / 流失预警=volcano）
import Tag from "@/shared/Tag";
import Icon from "@/shared/Icon";
import "./index.css";

const STATUS_CONFIG = {
  健康: { color: "success" },
  观察: { color: "warning" },
  风险: { color: "error" },
  流失预警: { color: "volcano", icon: "triangle-alert" },
};

export default function StatusTag({ status }) {
  const config = STATUS_CONFIG[status] || { color: "default" };
  return (
    <Tag color={config.color} className="status-tag">
      {config.icon ? <Icon name={config.icon} size="0.75rem" /> : null}
      {status}
    </Tag>
  );
}
