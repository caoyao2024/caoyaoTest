// Layer 3: 手写进度条（eview-react 无 ProgressBar 对应组件，见 handwrite-templates.md §9）
import "./index.css";

export default function SimpleProgress({ percent, color, showInfo = false, className = "" }) {
  const p = Math.min(100, Math.max(0, percent));
  return (
    <div className={`app-progress ${className}`}>
      <div className="app-progress-track">
        <div className="app-progress-fill" style={{ width: `${p}%`, background: color }} />
      </div>
      {showInfo ? <span className="app-progress-text">{p}%</span> : null}
    </div>
  );
}
