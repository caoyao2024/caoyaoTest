<script setup lang="ts">
import { computed } from "vue"
import { getIconComponentRef, sizeConfig, HUI_ICON_SIZE, mapShapeToHuiType, mapColorToHuiColor } from "./IconBase"
import type { A2UIComponentProps } from "../../renderer"
import { useA2UIComponent } from "../../renderer/render/hooks"
import type { IconNode } from "../types"
import { useIconProvider, iconInfoMap, svgCache, svgCacheVersion, resolveSvgCacheKey } from "../../composables/useIconProvider"
import { iconColors } from "../../utils/themeColors"

const { hasHuiIcons } = useIconProvider()

const BACKGROUND_OPACITY = 0.15

const props = defineProps<A2UIComponentProps<IconNode>>()
const { node, surfaceId } = props
const properties = node.properties
const { resolveValue } = useA2UIComponent(node, surfaceId)

const id = computed(() => node.id)
const className = computed(() => properties.className || "")
const name = computed(() => (resolveValue(properties.name) as string) || "")
const shape = computed(() => (resolveValue(properties.shape) as string | undefined) || "outline")
const color = computed(() => (resolveValue(properties.color) as string | undefined) || "default")

// 响应式判断：SVG 是否已缓存（读取 svgCacheVersion 作为依赖）
const isHuiIcon = computed(() => {
  svgCacheVersion.value  // 响应式依赖：SVG 到达时触发重算
  if (!name.value || !hasHuiIcons.value) return false
  const entry = iconInfoMap.value[name.value]
  if (!entry?.url) return false
  const key = resolveSvgCacheKey(name.value, shape.value, color.value)
  return svgCache.has(key)
})

// 统一图标解析（hui 或 lucide 或 null）
const resolved = computed(() => {
  if (!name.value) return null
  return getIconComponentRef(name.value, { shape: shape.value, color: color.value })
})

const huiIconType = computed(() => mapShapeToHuiType(shape.value))
const huiIconColor = computed(() => mapColorToHuiColor(color.value))
const bgShape = computed(() => shape.value)

const hasApiBackground = computed(() => isHuiIcon.value && (bgShape.value === "circle" || bgShape.value === "square"))
const huiIconSize = computed(() => (hasApiBackground.value ? undefined : HUI_ICON_SIZE))

const iconSizeStyle = computed(() => {
  switch (bgShape.value) {
    case "circle":
      return { width: "min(100%, max(12px, 70%))", height: "min(100%, max(12px, 70%))" }
    case "square":
      return { width: "min(100%, max(12px, 60%))", height: "min(100%, max(12px, 60%))" }
    case "fill":
      return { width: "min(100%, max(12px, 70%))", height: "min(100%, max(12px, 70%))" }
    default:
      return { width: "100%", height: "100%" }
  }
})

const iconColor = computed(() => {
  const c = color.value
  const iconColorEntry = iconColors[c as keyof typeof iconColors]
  if (iconColorEntry) {
    return `var(${iconColorEntry.color})`
  }
  return "currentColor"
})

const borderRadius = computed(() => {
  switch (bgShape.value) {
    case "fill":
    case "circle":
      return "50%"
    case "square":
      return `${Math.floor(sizeConfig.md * 0.25) || 2}px`
    default:
      return "0"
  }
})

const mixPercentage = Math.round(BACKGROUND_OPACITY * 100)

const wrapperStyle = computed(() => {
  if (hasApiBackground.value) {
    return {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: "transparent",
      borderRadius: "0",
    }
  }
  const hasBg = bgShape.value !== "outline"
  const isWhite = bgShape.value === "fill"
  return {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    color: isWhite ? "#fff" : iconColor.value || "#191919",
    backgroundColor: isWhite
      ? iconColor.value
      : hasBg
        ? `color-mix(in srgb, currentColor ${mixPercentage}%, transparent)`
        : "transparent",
    borderRadius: borderRadius.value,
  }
})
</script>

<template>
  <div :id="id" :style="wrapperStyle" class="icon-base" :class="className">
    <!-- hui API 可用 + SVG 已缓存 → 渲染 hui 图标 -->
    <component
      v-if="isHuiIcon && resolved"
      :is="resolved.component"
      v-bind="resolved.props"
      :size="huiIconSize"
      :type="huiIconType"
      :iconColor="huiIconColor"
    />
    <!-- hui API 不可用 → 渲染 lucide 图标 -->
    <component
      v-else-if="!hasHuiIcons && resolved"
      :is="resolved.component"
      :style="iconSizeStyle"
      :color="bgShape === 'fill' ? '#fff' : iconColor"
      :stroke-width="2"
    />
    <!-- hui API 可用但 SVG 未缓存 → 图标空白不显示 -->
  </div>
</template>
