<script setup lang="ts">
import { computed, onMounted, ref, useAttrs } from "vue"
import { ElButton } from "element-plus"
import type { ButtonNode } from "../types"
import type { A2UIComponentProps } from "../../renderer"
import { useA2UIComponent } from "../../renderer/render/hooks"
import { useIconComponentRef } from "../Icon/IconBase"
import "./Button.less"
import { useTheme } from "../../composables/useTheme"

type ButtonType = "" | "default" | "primary" | "danger" | "text" | "success" | "warning" | "info"
type ButtonSize = "" | "large" | "small" | "default" | undefined

const sizeEnum = {
  large: "large",
  medium: "default",
  small: "small",
}

const iconSizeEnum = {
  large: 16,
  default: 14,
  small: 12,
}

// 圆形纯图标按钮的 icon 尺寸 = 字体大小
const circleIconSizeEnum = {
  large: 20,
  default: 18,
  small: 14,
}

const types = [
  "",
  "default",
  "primary",
  "danger",
  "text",
  "success",
  "warning",
  "info",
  undefined,
]

const { isDark } = useTheme()
const props = defineProps<A2UIComponentProps<ButtonNode>>()
const { node, surfaceId } = props
const properties = node.properties
const { resolveValue, sendAction } = useA2UIComponent(node, surfaceId)

defineOptions({ inheritAttrs: false })

const attrs = useAttrs()

const elButtonRef = ref<InstanceType<typeof ElButton>>()

onMounted(() => {
  const wrapper = (elButtonRef.value as any)?.$el
  if (wrapper instanceof HTMLElement) {
    if (attrs['id'] != null)
      wrapper.setAttribute('id', String(attrs['id']))
    if (attrs['dom-picker-component'] != null)
      wrapper.setAttribute('dom-picker-component', String(attrs['dom-picker-component']))
    if (attrs['data-element-props'] != null)
      wrapper.setAttribute('data-element-props', String(attrs['data-element-props']))
  }
})

const id = computed(() => node.id)
const className = computed(() => node.properties.className)

const label = computed(() => resolveValue(properties.value) as string)

const disabled = computed(() => (resolveValue(properties.disabled) as boolean) || false)

const type = ref<ButtonType>("")
const isLink = ref(resolveValue(properties?.types) === "link")
const color = computed(() => {
  let resColor = (resolveValue(properties?.color) as string) || ""
  // 组件内的类型色
  if (isLink.value) {
    type.value = "primary"
    return ""
  } else if (types.findIndex((item) => item === resColor) > -1) {
    type.value = resColor as ButtonType
    return ""
  }
  return resColor
})

const size = computed(() => {
  return (properties.size ? sizeEnum[properties.size] : "default") as ButtonSize
})
const iconName = computed(() => resolveValue(properties?.icon) as string)
const onlyIcon = computed(() => {
  return !label.value && iconName.value
})
const iconPlacement = computed(() => properties.iconPlacement || "start")

function resolveIconColorForType(): string {
  if (!onlyIcon.value) return "currentColor"
  switch (type.value) {
    case "primary":  return "var(--icon-primary)"
    case "success":  return "var(--icon-success)"
    case "warning":  return "var(--icon-warning)"
    case "danger":   return "var(--icon-error)"
    case "default":  return "var(--color-icon-primary)"
    case "info":     return "var(--color-icon-primary)"
    default:         return "currentColor"
  }
}

function resolveIconSize(): number {
  if (onlyIcon.value) {
    return size.value ? circleIconSizeEnum[size.value] : circleIconSizeEnum.default
  }
  return size.value ? iconSizeEnum[size.value] : 16
}

const iconNameForRef = computed(() => {
  const name = resolveValue(properties?.icon) as string
  return name || undefined
})

const iconColor = computed(() => {
  let color = '#191919'
  if (isLink.value) {
    color = disabled.value ? (isDark.value ? '#004EA8' : '#8ABEF3') : '#0067D1'
  } else {
    const isWhiteText = ["primary", "danger", "success", "warning"].some(i => i === type.value)
    if(disabled.value) {
      color = isDark.value ? '#939393' : (isWhiteText ? '#FFFFFF' : '#c9c9c9')
    }
    color = (isWhiteText || isDark.value) ? '#FFFFFF' : '#191919'
  }
  return color
})

const baseIconRef = useIconComponentRef(iconNameForRef, computed(() => ({
  strokeWidth: 1,
  shape: 'lined',
  color: iconColor.value,
})))

const resolvedIcon = computed(() => {
  if (!baseIconRef.value?.component || !iconName.value) return null
  const base = baseIconRef.value
  const isHui = "iconColor" in base.props
  const colorValue = resolveIconColorForType()
  return {
    component: base.component,
    props: isHui
      ? { ...base.props,
          size: resolveIconSize(),
          type: base.props.type,
          iconColor: [colorValue],
        }
      : { size: resolveIconSize(), color: colorValue, "stroke-width": 1 },
  }
})

const shape = computed(() => {
  return {
    circle: properties.shape === "circle",
    round: properties.shape === "round",
  }
})

const handleClick = () => {
  if (!properties?.action) return
  try {
    sendAction(properties.action)
  } catch (error) {
    console.error("Failed to execute button action:", error)
  }
}
</script>

<template>
  <ElButton
    ref="elButtonRef"
    :id="id"
    :class="[className, { 'icon-only-circle': onlyIcon }]" 
    :round="shape.round"
    :circle="shape.circle"
    :type="type"
    :color="color"
    :size="size"
    :disabled="disabled"
    :link="isLink"
    @click="handleClick">
    <template v-if="iconName && resolvedIcon">
      <component 
        v-if="iconPlacement === 'start'"
        :class="label ? 'mr-1' : ''"
        :is="resolvedIcon.component"
        v-bind="resolvedIcon.props"
      />
      {{ label }}
      <component
        v-if="iconPlacement === 'end'"
        :class="label ? 'ml-1.5' : ''"
        :is="resolvedIcon.component"
        v-bind="resolvedIcon.props"
      />
    </template>
    <template v-else>
      {{ label }}
    </template>
  </ElButton>
</template>
