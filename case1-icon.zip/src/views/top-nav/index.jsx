// Layer 4: ① 顶部导航 — 平台 Logo / 主导航 / 快捷创建下拉 / 通知中心 / 用户区
// 顶部导航按规范用原生 nav 自写：选中项品牌色 + 2px 底部下划线，未选中透明下划线占位
import { useState } from "react";
import { IconPlusIcBpitTicket, IconPlusIcCarUser, IconPlusIcDigitalPowerDpFile, IconPlusIcIctLogOut, IconPlusIcIctNodeResourcePackage, IconPlusIcPublicBellClock, IconPlusIcPublicChevronDown, IconPlusIcPublicMoon, IconPlusIcPublicPlus, IconPlusIcPublicSetting, IconPlusIcPublicShoppingBag, IconPlusIcPublicSun } from '@hui/icon-plus';
import Button from "@nce/eview-react/Button";
import DivMessage from "@nce/eview-react/DivMessage";
import { useApp } from "../../context.jsx";
import "./index.css";

const NAV_ITEMS = ["首页", "订单", "商品", "营销", "会员", "设置"];

export default function TopNav({ onQuickCreate }) {
  const { isDark, toggleDark } = useApp();
  const [navActive, setNavActive] = useState("订单");
  const [openMenu, setOpenMenu] = useState(null);
  const [notice, setNotice] = useState(null);
  const [notifs, setNotifs] = useState([
    { key: "n1", title: "3 个订单超时未发货，请及时处理", time: "17:30", unread: true },
    { key: "n2", title: "SO20261019-0377 的售后申请已等待 43 小时", time: "16:20", unread: true },
    { key: "n3", title: "系统将于今晚 02:00 - 04:00 例行维护", time: "14:00", unread: false },
  ]);
  const unreadCount = notifs.filter((n) => n.unread).length;

  const notify = (type, text) => setNotice({ type, text, key: Date.now() });

  const toggleMenu = (name) => setOpenMenu((prev) => (prev === name ? null : name));

  const handleCreate = (key) => {
    if (onQuickCreate) onQuickCreate(key);
    setOpenMenu(null);
  };

  const handleReadAll = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, unread: false })));
    notify("success", "通知已全部标记为已读");
    setOpenMenu(null);
  };

  const handleUserMenu = (key) => {
    if (key === "logout") notify("default", "已安全退出当前账号（演示）");
    else notify("success", `已打开「${key === "profile" ? "个人中心" : "账号设置"}」（演示入口）`);
    setOpenMenu(null);
  };

  return (
    <header className="top-nav">
      <div className="tn-left">
        <span className="tn-logo" title="云驰电商运营台">
          <IconPlusIcPublicShoppingBag iconSize="1.25rem" iconColor={['currentcolor']} />
        </span>
        <span className="tn-brand">云驰电商运营台</span>
        <nav className="tn-nav">
          {NAV_ITEMS.map((item) => (
            <a
              key={item}
              className={navActive === item ? "active" : ""}
              onClick={() => setNavActive(item)}
            >
              {item}
            </a>
          ))}
        </nav>
      </div>
      <div className="tn-right">
        <div className="tn-dropdown">
          <Button
            status="primary"
            text="快捷创建"
            leftIcon={<IconPlusIcPublicPlus iconSize="0.875rem" iconColor={['currentcolor']} />}
            onClick={() => toggleMenu("create")}
          />
          {openMenu === "create" && (
            <div className="tn-menu">
              <div className="tn-menu-item" onClick={() => handleCreate("order")}>
                <IconPlusIcDigitalPowerDpFile iconSize="0.875rem" iconColor={['currentcolor']} />
                <span>新建订单</span>
              </div>
              <div className="tn-menu-item" onClick={() => handleCreate("coupon")}>
                <IconPlusIcBpitTicket iconSize="0.875rem" iconColor={['currentcolor']} />
                <span>新建优惠</span>
              </div>
              <div className="tn-menu-item" onClick={() => handleCreate("product")}>
                <IconPlusIcIctNodeResourcePackage iconSize="0.875rem" iconColor={['currentcolor']} />
                <span>新建商品</span>
              </div>
            </div>
          )}
        </div>
        <span
          className="tn-icon-btn"
          title={isDark ? "切换为亮色模式" : "切换为暗色模式"}
          onClick={toggleDark}
        >
          {isDark ? <IconPlusIcPublicSun iconSize="1rem" iconColor={['currentcolor']} /> : <IconPlusIcPublicMoon iconSize="1rem" iconColor={['currentcolor']} />}
        </span>
        <div className="tn-dropdown">
          <span className="tn-icon-btn" title="系统通知" onClick={() => toggleMenu("notif")}>
            <IconPlusIcPublicBellClock iconSize="1rem" iconColor={['currentcolor']} />
            {unreadCount > 0 && <i className="tn-dot" />}
          </span>
          {openMenu === "notif" && (
            <div className="tn-menu tn-menu-wide">
              {notifs.map((n) => (
                <div
                  key={n.key}
                  className={n.unread ? "tn-notif tn-notif-unread" : "tn-notif"}
                  onClick={() => setOpenMenu(null)}
                >
                  <span className="tn-notif-title">{n.title}</span>
                  <span className="tn-notif-time">{n.time}</span>
                </div>
              ))}
              <div className="tn-menu-divider" />
              <div className="tn-menu-item" onClick={handleReadAll}>
                <span>全部已读</span>
              </div>
            </div>
          )}
        </div>
        <div className="tn-dropdown">
          <span className="tn-user" onClick={() => toggleMenu("user")}>
            <img src="/uploads/user.png" alt="用户头像" />
            <span className="tn-user-info">
              <span className="tn-user-name">林晓</span>
              <span className="tn-user-role">运营组长</span>
            </span>
            <IconPlusIcPublicChevronDown iconSize="0.875rem" iconColor={['currentcolor']} />
          </span>
          {openMenu === "user" && (
            <div className="tn-menu tn-menu-right">
              <div className="tn-menu-item" onClick={() => handleUserMenu("profile")}>
                <IconPlusIcCarUser iconSize="0.875rem" iconColor={['currentcolor']} />
                <span>个人中心</span>
              </div>
              <div className="tn-menu-item" onClick={() => handleUserMenu("settings")}>
                <IconPlusIcPublicSetting iconSize="0.875rem" iconColor={['currentcolor']} />
                <span>账号设置</span>
              </div>
              <div className="tn-menu-divider" />
              <div className="tn-menu-item" onClick={() => handleUserMenu("logout")}>
                <IconPlusIcIctLogOut iconSize="0.875rem" iconColor={['currentcolor']} />
                <span>退出登录</span>
              </div>
            </div>
          )}
        </div>
      </div>
      {openMenu && <div className="tn-backdrop" onClick={() => setOpenMenu(null)} />}
      {notice && (
        <div className="tn-notice-wrap">
          <DivMessage
            key={notice.key}
            display
            type={notice.type}
            text={notice.text}
            onClose={() => setNotice(null)}
          />
        </div>
      )}
    </header>
  );
}
