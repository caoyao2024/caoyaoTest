// Layer 4: ① 顶部导航 — 平台 Logo / 主导航 / 快捷创建下拉 / 通知中心 / 用户区
// 顶部导航按规范用原生 nav 自写：选中项品牌色 + 2px 底部下划线，未选中透明下划线占位
import { useState } from "react";
import { IconPlusIcBpitTicket, IconPlusIcIctLogOut, IconPlusIcIctNewFile, IconPlusIcPublicBellClock, IconPlusIcPublicBoxOpen, IconPlusIcPublicChevronDown, IconPlusIcPublicMoon, IconPlusIcPublicPerson, IconPlusIcPublicPlus, IconPlusIcPublicSetting, IconPlusIcPublicShoppingBag, IconPlusIcPublicSun } from '@hui/icon-plus';
import Button from "@nce/eview-react/Button";
import PopUpMenu from "@nce/eview-react/PopUpMenu";
import DivMessage from "@nce/eview-react/DivMessage";
import { useApp } from "../../context.jsx";
import "./index.css";

const NAV_ITEMS = ["首页", "订单", "商品", "营销", "会员", "设置"];

export default function TopNav({ onQuickCreate }) {
  const { isDark, toggleDark } = useApp();
  const [navActive, setNavActive] = useState("订单");
  // 通知中心
  const [notifs, setNotifs] = useState([
    { key: "n1", title: "3 个订单超时未发货，请及时处理", time: "17:30", unread: true },
    { key: "n2", title: "SO20261019-0377 的售后申请已等待 43 小时", time: "16:20", unread: true },
    { key: "n3", title: "系统将于今晚 02:00 - 04:00 例行维护", time: "14:00", unread: false },
  ]);
  const [notifOpen, setNotifOpen] = useState(false);
  // 顶部提示
  const [notice, setNotice] = useState(null);
  const notify = (type, text) =>
    setNotice({ key: `${Date.now()}-${Math.random()}`, type, text });
  const unreadCount = notifs.filter((n) => n.unread).length;

  const createOptions = [
    { id: "order", serialno: "order", text: "新建订单", iconUrl: <IconPlusIcIctNewFile iconSize="0.875rem" iconColor={['currentcolor']} /> },
    { id: "coupon", serialno: "coupon", text: "新建优惠", iconUrl: <IconPlusIcBpitTicket iconSize="0.875rem" iconColor={['currentcolor']} /> },
    { id: "product", serialno: "product", text: "新建商品", iconUrl: <IconPlusIcPublicBoxOpen iconSize="0.875rem" iconColor={['currentcolor']} /> },
  ];

  const handleCreateClick = (evt) => {
    const key = evt && evt.value;
    if (key == null) return;
    if (onQuickCreate) onQuickCreate(key);
  };

  const userOptions = [
    { id: "profile", serialno: "profile", text: "个人中心", iconUrl: <IconPlusIcPublicPerson iconSize="0.875rem" iconColor={['currentcolor']} /> },
    { id: "settings", serialno: "settings", text: "账号设置", iconUrl: <IconPlusIcPublicSetting iconSize="0.875rem" iconColor={['currentcolor']} /> },
    { id: "logout", serialno: "logout", text: "退出登录", iconUrl: <IconPlusIcIctLogOut iconSize="0.875rem" iconColor={['currentcolor']} /> },
  ];

  const handleUserClick = (evt) => {
    const key = evt && evt.value;
    if (key == null) return;
    if (key === "logout") notify("default", "已安全退出当前账号（演示）");
    else notify("success", `已打开「${key === "profile" ? "个人中心" : "账号设置"}」（演示入口）`);
  };

  const markAllRead = () => {
    setNotifs((prev) => prev.map((n) => ({ ...n, unread: false })));
    notify("success", "通知已全部标记为已读");
    setNotifOpen(false);
  };

  return (
    <header className="top-nav">
      <div className="tn-left">
        <span className="tn-logo" title="云驰电商运营台">
          <IconPlusIcPublicShoppingBag iconSize="1.25rem" iconColor={['currentcolor']} />
        </span>
        <span className="tn-brand">云驰电商运营台</span>
        <nav className="tn-nav">
          {NAV_ITEMS.map((item) => (
            <a
              key={item}
              className={navActive === item ? "active" : ""}
              onClick={() => setNavActive(item)}
            >
              {item}
            </a>
          ))}
        </nav>
      </div>
      <div className="tn-right">
        <PopUpMenu options={createOptions} width="9rem" onClick={handleCreateClick}>
          <Button
            status="primary"
            text="快捷创建"
            leftIcon={<IconPlusIcPublicPlus iconSize="0.875rem" iconColor={['currentcolor']} />}
          />
        </PopUpMenu>
        <span
          className="tn-icon-btn"
          title={isDark ? "切换为亮色模式" : "切换为暗色模式"}
          onClick={toggleDark}
        >
          {isDark ? <IconPlusIcPublicSun iconSize="1rem" iconColor={['currentcolor']} /> : <IconPlusIcPublicMoon iconSize="1rem" iconColor={['currentcolor']} />}
        </span>
        <span className="tn-dropdown">
          <span
            className="tn-icon-btn"
            title="系统通知"
            onClick={() => setNotifOpen((o) => !o)}
          >
            <IconPlusIcPublicBellClock iconSize="1rem" iconColor={['currentcolor']} />
            {unreadCount > 0 && <i className="tn-dot" />}
          </span>
          {notifOpen && (
            <>
              <div className="tn-notif-mask" onClick={() => setNotifOpen(false)} />
              <div className="tn-notif-panel">
                {notifs.map((n) => (
                  <div
                    key={n.key}
                    className={n.unread ? "tn-notif tn-notif-unread" : "tn-notif"}
                    onClick={() => setNotifOpen(false)}
                  >
                    <span className="tn-notif-title">{n.title}</span>
                    <span className="tn-notif-time">{n.time}</span>
                  </div>
                ))}
                <div className="tn-notif-divider" />
                <a className="tn-notif-readall" onClick={markAllRead}>
                  全部已读
                </a>
              </div>
            </>
          )}
        </span>
        <PopUpMenu options={userOptions} width="9rem" onClick={handleUserClick}>
          <span className="tn-user">
            <img src="/uploads/user.png" alt="用户头像" />
            <span className="tn-user-info">
              <span className="tn-user-name">林晓</span>
              <span className="tn-user-role">运营组长</span>
            </span>
            <IconPlusIcPublicChevronDown iconSize="0.875rem" iconColor={['currentcolor']} />
          </span>
        </PopUpMenu>
      </div>
      {notice && (
        <div className="tn-toast">
          <DivMessage
            key={notice.key}
            display
            type={notice.type}
            text={notice.text}
            onClose={() => setNotice(null)}
          />
        </div>
      )}
    </header>
  );
}
