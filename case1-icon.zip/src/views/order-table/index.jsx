// Layer 4: ⑤⑥ 主表格 + 工具栏 + 批量操作栏 + 分页
// 排序外部受控（跨页全局排序），选择/分页状态由容器 order-console 持有
import { useMemo, useState } from "react";
import { IconPlusIcCarShipping, IconPlusIcIctCellColumn, IconPlusIcIctPin, IconPlusIcPublicCloseCircle, IconPlusIcPublicDownload, IconPlusIcPublicEllipsis, IconPlusIcPublicEye, IconPlusIcPublicNotes, IconPlusIcPublicPrinter, IconPlusIcPublicRefreshClockwise, IconPlusIcPublicSuccess } from '@hui/icon-plus';
import Button from "@nce/eview-react/Button";
import Table from "@nce/eview-react/Table";
import TipBox from "@nce/eview-react/TipBox";
import Checkbox from "@nce/eview-react/Checkbox";
import Dialog from "@nce/eview-react/Dialog";
import MessageDialog from "@nce/eview-react/MessageDialog";
import DivMessage from "@nce/eview-react/DivMessage";
import Paging from "@nce/eview-react/Paging";
import TextField from "@/shared/TextField";
import TextArea from "@/shared/TextArea";
import { CATEGORY_STYLE, fmtMoney, maskPhone } from "../../mock/order.jsx";
import { OrderStatusTag } from "../../components/status-tag/index.jsx";
import "./index.css";

const COMPARE = {
  orderNo: (a, b) => a.orderNo.localeCompare(b.orderNo),
  receiver: (a, b) => a.receiver.localeCompare(b.receiver, "zh"),
  paidAmount: (a, b) => a.paidAmount - b.paidAmount,
  payMethod: (a, b) => a.payMethod.localeCompare(b.payMethod, "zh"),
  createdAt: (a, b) => a.createdAt.localeCompare(b.createdAt),
};

const canShip = (o) => o.status === "pendingShipment";
const canCancel = (o) => o.status === "pendingPayment" || o.status === "pendingShipment";

const OPTIONAL_COLS = [
  { key: "items", label: "商品摘要" },
  { key: "receiver", label: "客户" },
  { key: "payMethod", label: "支付方式" },
  { key: "logistics", label: "物流状态" },
  { key: "createdAt", label: "下单时间" },
];

export default function OrderTable({
  data,
  page,
  pageSize,
  sorter,
  selectedRowKeys,
  onPageChange,
  onSorterChange,
  onSelectionChange,
  onShipOrders,
  onCancelOrders,
  onViewOrder,
  onOpenLogistics,
  onExportOrder,
  onUpdateAddress,
  onUpdateRemark,
}) {
  const [addressTarget, setAddressTarget] = useState(null);
  const [addressForm, setAddressForm] = useState({ receiver: "", phone: "", address: "" });
  const [addressErrors, setAddressErrors] = useState({});
  const [remarkTarget, setRemarkTarget] = useState(null);
  const [remarkText, setRemarkText] = useState("");
  const [hiddenCols, setHiddenCols] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showColMenu, setShowColMenu] = useState(false);
  const [openRowMenu, setOpenRowMenu] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [notice, setNotice] = useState(null);

  const notify = (type, text) => setNotice({ type, text, key: Date.now() });

  const selectedOrders = useMemo(
    () => data.filter((o) => selectedRowKeys.includes(o.orderNo)),
    [data, selectedRowKeys]
  );

  const sortedData = useMemo(() => {
    const arr = [...data];
    if (sorter && sorter.order && COMPARE[sorter.field]) {
      const cmp = COMPARE[sorter.field];
      arr.sort((a, b) => (sorter.order === "ascend" ? cmp(a, b) : -cmp(a, b)));
    }
    return arr;
  }, [data, sorter]);

  const pageData = useMemo(
    () => sortedData.slice((page - 1) * pageSize, page * pageSize),
    [sortedData, page, pageSize]
  );

  const checkedIndexes = useMemo(
    () =>
      pageData
        .map((o, i) => (selectedRowKeys.includes(o.orderNo) ? i : -1))
        .filter((i) => i >= 0),
    [pageData, selectedRowKeys]
  );

  const sortDir = (field) => {
    if (sorter?.field !== field || !sorter?.order) return undefined;
    return sorter.order === "ascend" ? "asc" : "desc";
  };

  const toggleCol = (key) => {
    setHiddenCols((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      notify("success", `列表已刷新，当前共 ${sortedData.length} 单`);
    }, 600);
  };

  const handleExportList = () => {
    notify("success", `已导出 ${sortedData.length} 条订单明细（Excel）`);
  };

  const confirmShipOne = (r) => {
    setConfirm({
      content: `确认发货订单 ${r.orderNo}？收货人 ${r.receiver}，实付 ¥${fmtMoney(r.paidAmount)}。发货后订单进入「已发货」状态。`,
      okText: "确认发货",
      onOk: () => {
        onShipOrders([r.orderNo]);
        notify("success", `订单 ${r.orderNo} 已发货，物流单已生成`);
      },
    });
  };

  const confirmCancelOne = (r) => {
    if (!canCancel(r)) {
      notify("warn", "当前订单状态不可取消");
      return;
    }
    setConfirm({
      isRisk: true,
      content: `确认取消订单 ${r.orderNo}？取消后订单将关闭，占用库存自动回滚，已付款项原路退回。`,
      okText: "确认取消",
      onOk: () => {
        onCancelOrders([r.orderNo]);
        notify("success", `订单 ${r.orderNo} 已取消`);
      },
    });
  };

  const openAddress = (r) => {
    setAddressTarget(r);
    setAddressForm({ receiver: r.receiver, phone: r.phone, address: r.address });
    setAddressErrors({});
  };

  const saveAddress = () => {
    const errs = {};
    if (!addressForm.receiver.trim()) errs.receiver = "请输入收货人姓名";
    if (!/^1[3-9]\d{9}$/.test(addressForm.phone.trim())) errs.phone = "请输入 11 位有效手机号";
    if (!addressForm.address.trim()) errs.address = "请输入详细收货地址";
    setAddressErrors(errs);
    if (Object.keys(errs).length) return;
    onUpdateAddress(addressTarget.orderNo, {
      receiver: addressForm.receiver.trim(),
      phone: addressForm.phone.trim(),
      address: addressForm.address.trim(),
    });
    notify("success", `订单 ${addressTarget.orderNo} 收货地址已更新`);
    setAddressTarget(null);
  };

  const openRemark = (r) => {
    setRemarkTarget(r);
    setRemarkText(r.remark || "");
  };

  const saveRemark = () => {
    onUpdateRemark(remarkTarget.orderNo, remarkText.trim());
    notify("success", `订单 ${remarkTarget.orderNo} 备注已保存`);
    setRemarkTarget(null);
  };

  const handleMenu = (key, r) => {
    if (key === "detail") onViewOrder(r.orderNo);
    if (key === "logistics") onOpenLogistics(r);
    if (key === "address") openAddress(r);
    if (key === "cancel") confirmCancelOne(r);
    if (key === "export") onExportOrder(r.orderNo);
  };

  const renderOps = (r) => (
    <div className="ot-ops">
      <IconPlusIcCarShipping
        iconSize="0.875rem"
        iconColor={['currentcolor']}
        className={canShip(r) ? "ot-op" : "ot-op ot-op-disabled"}
        title={canShip(r) ? "发货" : "仅待发货订单可发货"}
        onClick={canShip(r) ? () => confirmShipOne(r) : undefined}
      />
      <IconPlusIcPublicNotes
        iconSize="0.875rem"
        iconColor={['currentcolor']}
        className="ot-op"
        title="备注"
        onClick={() => openRemark(r)}
      />
      <div className="ot-dropdown">
        <IconPlusIcPublicEllipsis iconSize="0.875rem" iconColor={['currentcolor']} className="ot-op" title="更多操作" onClick={() => setOpenRowMenu(openRowMenu === r.orderNo ? null : r.orderNo)} />
        {openRowMenu === r.orderNo && (
          <div className="ot-row-menu">
            <div className="ot-menu-item" onClick={() => { handleMenu("detail", r); setOpenRowMenu(null); }}>
              <IconPlusIcPublicEye iconSize="0.875rem" iconColor={['currentcolor']} />
              <span>查看详情</span>
            </div>
            <div className="ot-menu-item" onClick={() => { handleMenu("logistics", r); setOpenRowMenu(null); }}>
              <IconPlusIcCarShipping iconSize="0.875rem" iconColor={['currentcolor']} />
              <span>物流轨迹</span>
            </div>
            <div className="ot-menu-item" onClick={() => { handleMenu("address", r); setOpenRowMenu(null); }}>
              <IconPlusIcIctPin iconSize="0.875rem" iconColor={['currentcolor']} />
              <span>修改地址</span>
            </div>
            <div className="ot-menu-item" onClick={() => { handleMenu("cancel", r); setOpenRowMenu(null); }}>
              <IconPlusIcPublicCloseCircle iconSize="0.875rem" iconColor={['currentcolor']} />
              <span>取消订单</span>
            </div>
            <div className="ot-menu-divider" />
            <div className="ot-menu-item" onClick={() => { handleMenu("export", r); setOpenRowMenu(null); }}>
              <IconPlusIcPublicDownload iconSize="0.875rem" iconColor={['currentcolor']} />
              <span>导出该单</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const columns = [
    {
      title: "订单号",
      key: "orderNo",
      allowSort: true,
      sort: sortDir("orderNo"),
      render: (cell, _rd, _opt, row) => {
        const r = row?.rawData;
        return (
          <span className="ot-no">
            <a className="ot-link" onClick={() => onViewOrder(r?.orderNo)}>
              {cell}
            </a>
            {r?.remark && (
              <IconPlusIcPublicNotes
                iconSize="0.75rem"
                iconColor={['currentcolor']}
                className="ot-flag"
                title={`备注：${r.remark}`}
              />
            )}
          </span>
        );
      },
    },
    {
      title: "商品摘要",
      key: "items",
      allowSort: false,
      render: (cell, _rd, _opt, row) => {
        const r = row?.rawData;
        const items = cell || r?.items || [];
        if (!items.length) return null;
        const first = items[0];
        const cat = CATEGORY_STYLE[first.cat];
        const totalQty = items.reduce((s, x) => s + x.qty, 0);
        const pop = (
          <div className="ot-pop">
            {items.map((x) => (
              <div className="ot-pop-row" key={x.name}>
                <span className="ot-pop-name">
                  {x.name}（{x.spec}）
                </span>
                <span className="ot-pop-num">
                  ×{x.qty}　¥{fmtMoney(x.price * x.qty)}
                </span>
              </div>
            ))}
            <div className="ot-pop-total">
              共 {totalQty} 件商品 · 实付 ¥{fmtMoney(r?.paidAmount ?? 0)}
            </div>
          </div>
        );
        return (
          <TipBox content={pop} direction="topLeft">
            <div className="ot-goods">
              <span className="ot-thumb" style={{ background: cat.bg, color: cat.text }}>
                {cat.icon}
              </span>
              <span className="ot-goods-info">
                <span className="ot-goods-name">{first.name}</span>
                <span className="ot-goods-sub">
                  ×{first.qty}
                  {items.length > 1 ? ` 等 ${items.length} 种共 ${totalQty} 件` : ` · ${first.spec}`}
                </span>
              </span>
            </div>
          </TipBox>
        );
      },
    },
    {
      title: "客户",
      key: "receiver",
      allowSort: true,
      sort: sortDir("receiver"),
      render: (cell, _rd, _opt, row) => {
        const r = row?.rawData;
        return (
          <div className="ot-cust">
            <span className="ot-cust-name">{cell}</span>
            <span className="ot-cust-phone">{maskPhone(r?.phone ?? "")}</span>
          </div>
        );
      },
    },
    {
      title: "实付金额",
      key: "paidAmount",
      allowSort: true,
      sort: sortDir("paidAmount"),
      align: "right",
      render: (cell) => <span className="ot-amount">¥{fmtMoney(cell)}</span>,
    },
    {
      title: "支付方式",
      key: "payMethod",
      allowSort: true,
      sort: sortDir("payMethod"),
    },
    {
      title: "物流状态",
      key: "logistics",
      allowSort: false,
      render: (cell, _rd, _opt, row) => {
        const r = row?.rawData;
        return (
          <a
            className={cell === "异常" ? "ot-logi-link ot-logi-error" : "ot-logi-link"}
            onClick={() => onOpenLogistics(r)}
            title="查看物流轨迹"
          >
            {cell}
          </a>
        );
      },
    },
    {
      title: "订单状态",
      key: "status",
      allowSort: false,
      render: (cell, _rd, _opt, row) => (
        <OrderStatusTag status={cell} timeout={row?.rawData?.shippingTimeout} />
      ),
    },
    {
      title: "下单时间",
      key: "createdAt",
      allowSort: true,
      sort: sortDir("createdAt"),
      render: (cell) => <span className="ot-time">{cell}</span>,
    },
    {
      title: "操作",
      key: "ops",
      allowSort: false,
      render: (_cell, _rd, _opt, row) => {
        const r = row?.rawData;
        return r ? renderOps(r) : null;
      },
    },
  ].filter((c) => !hiddenCols.includes(c.key));

  const handleBatchShip = () => {
    const shippable = selectedOrders.filter(canShip);
    if (!shippable.length) {
      notify("warn", "选中订单中没有「待发货」订单，无法批量发货");
      return;
    }
    setConfirm({
      content: `确认批量发货 ${shippable.length} 个订单？发货后订单状态变更为「已发货」，物流单号将同步推送至买家。`,
      okText: "确认发货",
      onOk: () => {
        onShipOrders(shippable.map((o) => o.orderNo));
        notify("success", `已批量发货 ${shippable.length} 单，物流单已生成`);
        onSelectionChange([]);
      },
    });
  };

  const handleBatchCancel = () => {
    const cancellable = selectedOrders.filter(canCancel);
    if (!cancellable.length) {
      notify("warn", "选中订单中没有可取消的订单（仅待付款/待发货可取消）");
      return;
    }
    const skipped = selectedOrders.length - cancellable.length;
    setConfirm({
      isRisk: true,
      content: `确认批量取消 ${cancellable.length} 个订单？取消后订单将关闭、库存回滚、款项原路退回。${
        skipped ? `另有 ${skipped} 单当前状态不可取消，将自动跳过。` : ""
      }`,
      okText: "确认取消",
      onOk: () => {
        onCancelOrders(cancellable.map((o) => o.orderNo));
        notify("success", `已批量取消 ${cancellable.length} 单${skipped ? `，跳过 ${skipped} 单` : ""}`);
        onSelectionChange([]);
      },
    });
  };

  const handleBatchPrint = () => {
    notify("success", `已将 ${selectedOrders.length} 个订单加入打印队列`);
    onSelectionChange([]);
  };

  const handleRowCheck = (_row, checkedRows) => {
    const pageOrderNos = pageData.map((o) => o.orderNo);
    const checkedOrderNos = checkedRows.map((i) => pageData[i]?.orderNo).filter(Boolean);
    const otherPageSelections = selectedRowKeys.filter((no) => !pageOrderNos.includes(no));
    onSelectionChange([...otherPageSelections, ...checkedOrderNos]);
  };

  const handleHeaderCheck = (checkedRows) => {
    const pageOrderNos = pageData.map((o) => o.orderNo);
    const checkedOrderNos = checkedRows.map((i) => pageData[i]?.orderNo).filter(Boolean);
    const otherPageSelections = selectedRowKeys.filter((no) => !pageOrderNos.includes(no));
    onSelectionChange([...otherPageSelections, ...checkedOrderNos]);
  };

  return (
    <div className="order-table">
      <div className="ot-toolbar">
        <span className="ot-result">
          共 <b>{sortedData.length}</b> 单
          {selectedRowKeys.length > 0 && (
            <span className="ot-result-sel"> · 已选 {selectedRowKeys.length} 单</span>
          )}
        </span>
        <div className="ot-tools">
          <IconPlusIcPublicRefreshClockwise
            iconSize="0.875rem"
            iconColor={['currentcolor']}
            className={loading ? "ot-tool ot-tool-spin" : "ot-tool"}
            title="刷新列表"
            onClick={handleRefresh}
          />
          <div className="ot-dropdown">
            <IconPlusIcIctCellColumn
              iconSize="0.875rem"
              iconColor={['currentcolor']}
              className="ot-tool"
              title="列显示设置"
              onClick={() => setShowColMenu(!showColMenu)}
            />
            {showColMenu && (
              <div className="ot-col-menu">
                {OPTIONAL_COLS.map((c) => (
                  <div key={c.key} className="ot-col-menu-item">
                    <Checkbox
                      checked={!hiddenCols.includes(c.key)}
                      onChange={() => toggleCol(c.key)}
                      label={c.label}
                    />
                  </div>
                ))}
              </div>
            )}
          </div>
          <Button
            size="small"
            text="导出"
            leftIcon={<IconPlusIcPublicDownload iconSize="0.875rem" iconColor={['currentcolor']} />}
            onClick={handleExportList}
          />
        </div>
      </div>
      {selectedOrders.length > 0 && (
        <div className="ot-batch">
          <div className="ot-batch-left">
            <IconPlusIcPublicSuccess iconSize="1rem" iconColor={['currentcolor']} />
            <span>
              已选 <b className="ot-batch-n">{selectedOrders.length}</b> 单
            </span>
            <a className="ot-batch-clear" onClick={() => onSelectionChange([])}>
              取消选择
            </a>
          </div>
          <div className="ot-batch-actions">
            <Button
              size="small"
              status="primary"
              text="批量发货"
              leftIcon={<IconPlusIcCarShipping iconSize="0.875rem" iconColor={['currentcolor']} />}
              onClick={handleBatchShip}
            />
            <Button
              size="small"
              text="批量打印"
              leftIcon={<IconPlusIcPublicPrinter iconSize="0.875rem" iconColor={['currentcolor']} />}
              onClick={handleBatchPrint}
            />
            <Button
              size="small"
              status="risk"
              text="批量取消"
              leftIcon={<IconPlusIcPublicCloseCircle iconSize="0.875rem" iconColor={['currentcolor']} />}
              onClick={handleBatchCancel}
            />
          </div>
        </div>
      )}
      <Table
        className="ot-table"
        columns={columns}
        dataset={pageData}
        enableLoading={loading}
        emptyTableMsg="暂无订单"
        enableZebraCrossing={false}
        width="unset"
        enableColumnCompareUpdate
        disableEviewSort
        onColumnSort={(sortColumn, sortType) => {
          if (!sortType || sortType === "origin") {
            onSorterChange({});
          } else {
            onSorterChange({ field: sortColumn, order: sortType === "asc" ? "ascend" : "descend" });
          }
        }}
        enableCheckBox
        checkType="multi"
        preserveCheckedRows
        checkedRows={checkedIndexes}
        onRowCheck={handleRowCheck}
        onHeaderCheck={handleHeaderCheck}
      />
      <div className="ot-pager">
        <Paging
          recordCount={sortedData.length}
          pageSize={pageSize}
          currentPage={page}
          pageSizeOptions={[10, 20, 50]}
          onPageChange={(p) => onPageChange(p, pageSize)}
          onPageSizeChange={(size) => onPageChange(1, size)}
          enableSelectedCount
          selectedCount={selectedRowKeys.length}
        />
      </div>

      <Dialog
        isOpen={!!addressTarget}
        title={addressTarget ? `修改收货地址 · ${addressTarget.orderNo}` : ""}
        size={[480, "auto"]}
        style={{ maxHeight: "80vh" }}
        onClose={() => setAddressTarget(null)}
        buttons={[
          { text: "取消", onClick: () => setAddressTarget(null) },
          { text: "保存地址", status: "primary", onClick: saveAddress },
        ]}
      >
        <form
          className="fm"
          onSubmit={(e) => {
            e.preventDefault();
            saveAddress();
          }}
        >
          <div className="fm-field">
            <label className="fm-label fm-required" htmlFor="fm-receiver">
              收货人
            </label>
            <TextField
              id="fm-receiver"
              value={addressForm.receiver}
              placeholder="请输入收货人姓名"
              onChange={(val) => {
                setAddressForm({ ...addressForm, receiver: val });
                if (addressErrors.receiver) setAddressErrors({ ...addressErrors, receiver: "" });
              }}
            />
            {addressErrors.receiver && <div className="fm-error">{addressErrors.receiver}</div>}
          </div>
          <div className="fm-field">
            <label className="fm-label fm-required" htmlFor="fm-phone">
              手机号
            </label>
            <TextField
              id="fm-phone"
              value={addressForm.phone}
              placeholder="请输入 11 位手机号"
              onChange={(val) => {
                setAddressForm({ ...addressForm, phone: val });
                if (addressErrors.phone) setAddressErrors({ ...addressErrors, phone: "" });
              }}
            />
            {addressErrors.phone && <div className="fm-error">{addressErrors.phone}</div>}
          </div>
          <div className="fm-field">
            <label className="fm-label fm-required" htmlFor="fm-address">
              详细地址
            </label>
            <TextField
              id="fm-address"
              value={addressForm.address}
              placeholder="省 / 市 / 区 + 街道门牌"
              onChange={(val) => {
                setAddressForm({ ...addressForm, address: val });
                if (addressErrors.address) setAddressErrors({ ...addressErrors, address: "" });
              }}
            />
            {addressErrors.address && <div className="fm-error">{addressErrors.address}</div>}
          </div>
        </form>
      </Dialog>

      <Dialog
        isOpen={!!remarkTarget}
        title={remarkTarget ? `订单备注 · ${remarkTarget.orderNo}` : ""}
        size={[480, "auto"]}
        style={{ maxHeight: "80vh" }}
        onClose={() => setRemarkTarget(null)}
        buttons={[
          { text: "取消", onClick: () => setRemarkTarget(null) },
          { text: "保存备注", status: "primary", onClick: saveRemark },
        ]}
      >
        <form
          className="fm"
          onSubmit={(e) => {
            e.preventDefault();
            saveRemark();
          }}
        >
          <div className="fm-field">
            <label className="fm-label" htmlFor="fm-remark">
              备注内容
            </label>
            <TextArea
              id="fm-remark"
              rows={3}
              maxLength={80}
              value={remarkText}
              placeholder="输入发货 / 客服备注，保存后在详情中可见"
              onChange={(val) => setRemarkText(val)}
            />
          </div>
        </form>
      </Dialog>

      <MessageDialog
        type={confirm?.isRisk ? "risk" : "confirm"}
        isOpen={!!confirm}
        content={confirm?.content}
        onClose={() => setConfirm(null)}
        buttons={{
          cancel: { text: "再想想", onClick: () => setConfirm(null) },
          ok: {
            text: confirm?.okText,
            focused: true,
            onClick: () => {
              confirm?.onOk?.();
              setConfirm(null);
            },
          },
        }}
      />

      {(openRowMenu || showColMenu) && (
        <div
          className="ot-backdrop"
          onClick={() => {
            setOpenRowMenu(null);
            setShowColMenu(false);
          }}
        />
      )}

      {notice && (
        <div className="ot-notice-wrap">
          <DivMessage
            key={notice.key}
            display
            type={notice.type}
            text={notice.text}
            onClose={() => setNotice(null)}
          />
        </div>
      )}
    </div>
  );
}
