// Layer 4: ⑤⑥ 主表格 + 工具栏 + 批量操作栏 + 分页
// 排序外部受控（跨页全局排序），选择/分页状态由容器 order-console 持有
import { useMemo, useState } from "react";
import { IconPlusIcCarShipping, IconPlusIcIctCellColumn, IconPlusIcPublicCheckmark, IconPlusIcPublicCloseCircle, IconPlusIcPublicDownload, IconPlusIcPublicEllipsis, IconPlusIcPublicEye, IconPlusIcPublicMappinOnMap, IconPlusIcPublicNotes, IconPlusIcPublicPrinter, IconPlusIcPublicRefreshClockwise } from '@hui/icon-plus';
import Button from "@nce/eview-react/Button";
import Checkbox from "@nce/eview-react/Checkbox";
import Table from "@nce/eview-react/Table";
import TipBox from "@nce/eview-react/TipBox";
import Dialog from "@nce/eview-react/Dialog";
import MessageDialog from "@nce/eview-react/MessageDialog";
import PopUpMenu from "@nce/eview-react/PopUpMenu";
import TextField from "@/shared/TextField";
import TextArea from "@/shared/TextArea";
import Icon from "@/shared/Icon";
import Notice from "@/shared/Notice";
import { CATEGORY_STYLE, fmtMoney, maskPhone } from "../../mock/order.js";
import { OrderStatusTag } from "../../components/status-tag/index.jsx";
// 表单骨架 .fm 定义于 order-console/index.css（页面级共享）
import "./index.css";

// 跨页排序比较器
const COMPARE = {
  orderNo: (a, b) => a.orderNo.localeCompare(b.orderNo),
  receiver: (a, b) => a.receiver.localeCompare(b.receiver, "zh"),
  paidAmount: (a, b) => a.paidAmount - b.paidAmount,
  payMethod: (a, b) => a.payMethod.localeCompare(b.payMethod, "zh"),
  createdAt: (a, b) => a.createdAt.localeCompare(b.createdAt),
};

const canShip = (o) => o.status === "pendingShipment";
const canCancel = (o) => o.status === "pendingPayment" || o.status === "pendingShipment";

const MORE_KEYS = new Set(["detail", "logistics", "address", "cancel", "export"]);

// 可隐藏的数据列（订单号 / 实付金额 / 订单状态 / 操作 始终保留）
const OPTIONAL_COLS = [
  { key: "items", label: "商品摘要" },
  { key: "receiver", label: "客户" },
  { key: "payMethod", label: "支付方式" },
  { key: "logistics", label: "物流状态" },
  { key: "createdAt", label: "下单时间" },
];

export default function OrderTable({
  data,
  page,
  pageSize,
  sorter,
  selectedRowKeys,
  onPageChange,
  onSorterChange,
  onSelectionChange,
  onShipOrders,
  onCancelOrders,
  onViewOrder,
  onOpenLogistics,
  onExportOrder,
  onUpdateAddress,
  onUpdateRemark,
}) {
  // 修改地址弹窗（H5 表单骨架）
  const [addressTarget, setAddressTarget] = useState(null);
  const [addressForm, setAddressForm] = useState({ receiver: "", phone: "", address: "" });
  const [addressErrors, setAddressErrors] = useState({});
  // 备注弹窗
  const [remarkTarget, setRemarkTarget] = useState(null);
  const [remarkText, setRemarkText] = useState("");
  // 工具栏：列显隐 + 刷新 loading
  const [hiddenCols, setHiddenCols] = useState([]);
  const [loading, setLoading] = useState(false);
  // 通知浮层
  const [notice, setNotice] = useState(null);
  // 确认弹窗（发货 / 取消 / 批量）
  const [confirm, setConfirm] = useState(null);

  const selectedOrders = useMemo(
    () => data.filter((o) => selectedRowKeys.includes(o.orderNo)),
    [data, selectedRowKeys]
  );

  // 全局排序后切片分页（eview Table enableAutoPaging 负责分页，此处仅排序）
  const sortedData = useMemo(() => {
    const arr = [...data];
    if (sorter && sorter.order && COMPARE[sorter.field]) {
      const cmp = COMPARE[sorter.field];
      arr.sort((a, b) => (sorter.order === "ascend" ? cmp(a, b) : -cmp(a, b)));
    }
    return arr;
  }, [data, sorter]);

  // eview Table 勾选基于行序号；与 order-console 的 orderNo 集合互转
  const selectedIndexes = useMemo(() => {
    const set = new Set(selectedRowKeys);
    const idx = [];
    for (let i = 0; i < sortedData.length; i++) {
      if (set.has(sortedData[i].orderNo)) idx.push(i);
    }
    return idx;
  }, [sortedData, selectedRowKeys]);

  const handleRowCheck = (checkedRows) => {
    const orderNos = checkedRows.map((i) => sortedData[i]?.orderNo).filter(Boolean);
    onSelectionChange(orderNos);
  };

  // row.rawData 不保证含未定义 key 的字段（remark/phone/shippingTimeout），按 orderNo 回查源数据
  const fullRow = (row) => {
    const r = row?.rawData;
    if (!r) return null;
    return sortedData.find((d) => d.orderNo === r.orderNo) || r;
  };

  const so = (field) => (sorter && sorter.field === field ? sorter.order : undefined);

  // ---- 工具栏 ----
  const toggleCol = (key) => {
    setHiddenCols((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setNotice({ key: Date.now(), type: "success", text: `列表已刷新，当前共 ${sortedData.length} 单` });
    }, 600);
  };

  const handleExportList = () => {
    setNotice({ key: Date.now(), type: "success", text: `已导出 ${sortedData.length} 条订单明细（Excel）` });
  };

  // ---- 行内操作 ----
  const confirmShipOne = (r) => setConfirm({ kind: "shipOne", row: r });

  const confirmCancelOne = (r) => {
    if (!canCancel(r)) {
      setNotice({ key: Date.now(), type: "warn", text: "当前订单状态不可取消" });
      return;
    }
    setConfirm({ kind: "cancelOne", row: r });
  };

  const openAddress = (r) => {
    setAddressTarget(r);
    setAddressForm({ receiver: r.receiver, phone: r.phone, address: r.address });
    setAddressErrors({});
  };

  const saveAddress = () => {
    const errs = {};
    if (!addressForm.receiver.trim()) errs.receiver = "请输入收货人姓名";
    if (!/^1[3-9]\d{9}$/.test(addressForm.phone.trim())) errs.phone = "请输入 11 位有效手机号";
    if (!addressForm.address.trim()) errs.address = "请输入详细收货地址";
    setAddressErrors(errs);
    if (Object.keys(errs).length) return;
    onUpdateAddress(addressTarget.orderNo, {
      receiver: addressForm.receiver.trim(),
      phone: addressForm.phone.trim(),
      address: addressForm.address.trim(),
    });
    setNotice({ key: Date.now(), type: "success", text: `订单 ${addressTarget.orderNo} 收货地址已更新` });
    setAddressTarget(null);
  };

  const openRemark = (r) => {
    setRemarkTarget(r);
    setRemarkText(r.remark || "");
  };

  const saveRemark = () => {
    onUpdateRemark(remarkTarget.orderNo, remarkText.trim());
    setNotice({ key: Date.now(), type: "success", text: `订单 ${remarkTarget.orderNo} 备注已保存` });
    setRemarkTarget(null);
  };

  const handleMenu = (key, r) => {
    if (!MORE_KEYS.has(key)) return;
    if (key === "detail") onViewOrder(r.orderNo);
    if (key === "logistics") onOpenLogistics(r);
    if (key === "address") openAddress(r);
    if (key === "cancel") confirmCancelOne(r);
    if (key === "export") onExportOrder(r.orderNo);
  };

  const renderOps = (r) => (
    <div className="ot-ops">
      <IconPlusIcCarShipping
        iconSize="0.875rem"
        iconColor={['currentcolor']}
        className={canShip(r) ? "ot-op" : "ot-op ot-op-disabled"}
        title={canShip(r) ? "发货" : "仅待发货订单可发货"}
        onClick={canShip(r) ? () => confirmShipOne(r) : undefined}
      />
      <IconPlusIcPublicNotes
        iconSize="0.875rem"
        iconColor={['currentcolor']}
        className="ot-op"
        title="备注"
        onClick={() => openRemark(r)}
      />
      <PopUpMenu
        options={[
          { id: "detail", serialno: "detail", text: "查看详情", iconUrl: <IconPlusIcPublicEye iconSize="0.875rem" iconColor={['currentcolor']} /> },
          { id: "logistics", serialno: "logistics", text: "物流轨迹", iconUrl: <IconPlusIcCarShipping iconSize="0.875rem" iconColor={['currentcolor']} /> },
          { id: "address", serialno: "address", text: "修改地址", iconUrl: <IconPlusIcPublicMappinOnMap iconSize="0.875rem" iconColor={['currentcolor']} /> },
          { id: "cancel", serialno: "cancel", text: "取消订单", iconUrl: <IconPlusIcPublicCloseCircle iconSize="0.875rem" iconColor={['currentcolor']} /> },
          { id: "export", serialno: "export", text: "导出该单", iconUrl: <IconPlusIcPublicDownload iconSize="0.875rem" iconColor={['currentcolor']} /> },
        ]}
        width="180px"
        onClick={(evt) => handleMenu(evt.value, r)}
      >
        <span className="ot-op" title="更多操作">
          <IconPlusIcPublicEllipsis iconSize="0.875rem" iconColor={['currentcolor']} />
        </span>
      </PopUpMenu>
    </div>
  );

  const columns = [
    {
      title: "订单号",
      key: "orderNo",
      width: 180,
      allowSort: true,
      sort: so("orderNo") === "ascend" ? "asc" : so("orderNo") === "descend" ? "desc" : undefined,
      render: (cell, _rd, _opt, row) => {
        const r = fullRow(row);
        return (
          <span className="ot-no">
            <a className="ot-link" onClick={() => onViewOrder(cell)}>
              {cell}
            </a>
            {r?.remark && (
              <IconPlusIcPublicNotes
                iconSize="0.75rem"
                iconColor={['currentcolor']}
                className="ot-flag"
                title={`备注：${r.remark}`}
              />
            )}
          </span>
        );
      },
    },
    {
      title: "商品摘要",
      key: "items",
      width: 268,
      allowSort: false,
      render: (cell, _rd, _opt, row) => {
        const r = fullRow(row);
        const items = cell;
        const first = items[0];
        const cat = CATEGORY_STYLE[first.cat];
        const totalQty = items.reduce((s, x) => s + x.qty, 0);
        const pop = (
          <div className="ot-pop">
            {items.map((x) => (
              <div className="ot-pop-row" key={x.name}>
                <span className="ot-pop-name">
                  {x.name}（{x.spec}）
                </span>
                <span className="ot-pop-num">
                  ×{x.qty}　¥{fmtMoney(x.price * x.qty)}
                </span>
              </div>
            ))}
            <div className="ot-pop-total">
              共 {totalQty} 件商品 · 实付 ¥{fmtMoney(r?.paidAmount ?? 0)}
            </div>
          </div>
        );
        return (
          <TipBox content={pop} direction="topLeft" trigger="hover" type="simple">
            <div className="ot-goods">
              <span className="ot-thumb" style={{ background: cat.bg, color: cat.text }}>
                <Icon name={cat.icon} size="0.875rem" />
              </span>
              <span className="ot-goods-info">
                <span className="ot-goods-name">{first.name}</span>
                <span className="ot-goods-sub">
                  ×{first.qty}
                  {items.length > 1 ? ` 等 ${items.length} 种共 ${totalQty} 件` : ` · ${first.spec}`}
                </span>
              </span>
            </div>
          </TipBox>
        );
      },
    },
    {
      title: "客户",
      key: "receiver",
      width: 128,
      allowSort: true,
      sort: so("receiver") === "ascend" ? "asc" : so("receiver") === "descend" ? "desc" : undefined,
      render: (cell, _rd, _opt, row) => {
        const r = fullRow(row);
        return (
          <div className="ot-cust">
            <span className="ot-cust-name">{cell}</span>
            <span className="ot-cust-phone">{maskPhone(r?.phone)}</span>
          </div>
        );
      },
    },
    {
      title: "实付金额",
      key: "paidAmount",
      width: 112,
      align: "right",
      allowSort: true,
      sort: so("paidAmount") === "ascend" ? "asc" : so("paidAmount") === "descend" ? "desc" : undefined,
      render: (cell) => <span className="ot-amount">¥{fmtMoney(cell)}</span>,
    },
    {
      title: "支付方式",
      key: "payMethod",
      width: 100,
      allowSort: true,
      sort: so("payMethod") === "ascend" ? "asc" : so("payMethod") === "descend" ? "desc" : undefined,
    },
    {
      title: "物流状态",
      key: "logistics",
      width: 96,
      allowSort: false,
      render: (cell, _rd, _opt, row) => (
        <a
          className={cell === "异常" ? "ot-logi-link ot-logi-error" : "ot-logi-link"}
          onClick={() => onOpenLogistics(fullRow(row))}
          title="查看物流轨迹"
        >
          {cell}
        </a>
      ),
    },
    {
      title: "订单状态",
      key: "status",
      width: 112,
      allowSort: false,
      render: (cell, _rd, _opt, row) => {
        const r = fullRow(row);
        return <OrderStatusTag status={cell} timeout={r?.shippingTimeout} />;
      },
    },
    {
      title: "下单时间",
      key: "createdAt",
      width: 150,
      allowSort: true,
      sort: so("createdAt") === "ascend" ? "asc" : so("createdAt") === "descend" ? "desc" : undefined,
      render: (cell) => <span className="ot-time">{cell}</span>,
    },
    {
      title: "操作",
      key: "ops",
      width: 132,
      allowSort: false,
      render: (_cell, _rd, _opt, row) => renderOps(fullRow(row)),
    },
  ].filter((c) => !hiddenCols.includes(c.key));

  // ---- 批量操作 ----
  const handleBatchShip = () => {
    const shippable = selectedOrders.filter(canShip);
    if (!shippable.length) {
      setNotice({ key: Date.now(), type: "warn", text: "选中订单中没有「待发货」订单，无法批量发货" });
      return;
    }
    setConfirm({ kind: "batchShip", shippable });
  };

  const handleBatchCancel = () => {
    const cancellable = selectedOrders.filter(canCancel);
    if (!cancellable.length) {
      setNotice({ key: Date.now(), type: "warn", text: "选中订单中没有可取消的订单（仅待付款/待发货可取消）" });
      return;
    }
    const skipped = selectedOrders.length - cancellable.length;
    setConfirm({ kind: "batchCancel", cancellable, skipped });
  };

  const handleBatchPrint = () => {
    setNotice({ key: Date.now(), type: "success", text: `已将 ${selectedOrders.length} 个订单加入打印队列` });
    onSelectionChange([]);
  };

  // 确认弹窗派生配置
  const confirmCfg = useMemo(() => {
    if (!confirm) return null;
    const isCancel = confirm.kind === "cancelOne" || confirm.kind === "batchCancel";
    let content = "";
    let detail;
    let okText = "确定";
    if (confirm.kind === "shipOne") {
      const r = confirm.row;
      content = `确认发货订单 ${r.orderNo}？`;
      detail = `收货人 ${r.receiver}，实付 ¥${fmtMoney(r.paidAmount)}。发货后订单进入「已发货」状态。`;
      okText = "确认发货";
    } else if (confirm.kind === "cancelOne") {
      const r = confirm.row;
      content = `确认取消订单 ${r.orderNo}？`;
      detail = "取消后订单将关闭，占用库存自动回滚，已付款项原路退回。";
      okText = "确认取消";
    } else if (confirm.kind === "batchShip") {
      content = `确认批量发货 ${confirm.shippable.length} 个订单？`;
      detail = "发货后订单状态变更为「已发货」，物流单号将同步推送至买家。";
      okText = "确认发货";
    } else if (confirm.kind === "batchCancel") {
      content = `确认批量取消 ${confirm.cancellable.length} 个订单？`;
      detail = `取消后订单将关闭、库存回滚、款项原路退回。${
        confirm.skipped ? `另有 ${confirm.skipped} 单当前状态不可取消，将自动跳过。` : ""
      }`;
      okText = "确认取消";
    }
    return { type: isCancel ? "risk" : "confirm", content, detail, okText };
  }, [confirm]);

  const handleConfirmOk = () => {
    if (!confirm) return;
    if (confirm.kind === "shipOne") {
      onShipOrders([confirm.row.orderNo]);
      setNotice({ key: Date.now(), type: "success", text: `订单 ${confirm.row.orderNo} 已发货，物流单已生成` });
    } else if (confirm.kind === "cancelOne") {
      onCancelOrders([confirm.row.orderNo]);
      setNotice({ key: Date.now(), type: "success", text: `订单 ${confirm.row.orderNo} 已取消` });
    } else if (confirm.kind === "batchShip") {
      onShipOrders(confirm.shippable.map((o) => o.orderNo));
      setNotice({ key: Date.now(), type: "success", text: `已批量发货 ${confirm.shippable.length} 单，物流单已生成` });
      onSelectionChange([]);
    } else if (confirm.kind === "batchCancel") {
      onCancelOrders(confirm.cancellable.map((o) => o.orderNo));
      setNotice({
        key: Date.now(),
        type: "success",
        text: `已批量取消 ${confirm.cancellable.length} 单${confirm.skipped ? `，跳过 ${confirm.skipped} 单` : ""}`,
      });
      onSelectionChange([]);
    }
    setConfirm(null);
  };

  return (
    <div className="order-table">
      <div className="ot-toolbar">
        <span className="ot-result">
          共 <b>{sortedData.length}</b> 单
          {selectedRowKeys.length > 0 && (
            <span className="ot-result-sel"> · 已选 {selectedRowKeys.length} 单</span>
          )}
        </span>
        <div className="ot-tools">
          <IconPlusIcPublicRefreshClockwise
            iconSize="0.875rem"
            iconColor={['currentcolor']}
            className={loading ? "ot-tool ot-tool-spin" : "ot-tool"}
            title="刷新列表"
            onClick={handleRefresh}
          />
          <TipBox
            trigger="click"
            direction="bottom"
            type="simple"
            isMouseLeaveClose={false}
            content={
              <div className="ot-col-menu">
                {OPTIONAL_COLS.map((c) => (
                  <Checkbox
                    key={c.key}
                    label={c.label}
                    checked={!hiddenCols.includes(c.key)}
                    onChange={() => toggleCol(c.key)}
                  />
                ))}
              </div>
            }
          >
            <span className="ot-tool" title="列显示设置">
              <IconPlusIcIctCellColumn iconSize="0.875rem" iconColor={['currentcolor']} />
            </span>
          </TipBox>
          <Button
            size="small"
            text="导出"
            leftIcon={<IconPlusIcPublicDownload iconSize="0.875rem" iconColor={['currentcolor']} />}
            onClick={handleExportList}
          />
        </div>
      </div>
      {selectedOrders.length > 0 && (
        <div className="ot-batch">
          <div className="ot-batch-left">
            <IconPlusIcPublicCheckmark iconSize="1rem" iconColor={['currentcolor']} />
            <span>
              已选 <b className="ot-batch-n">{selectedOrders.length}</b> 单
            </span>
            <a className="ot-batch-clear" onClick={() => onSelectionChange([])}>
              取消选择
            </a>
          </div>
          <div className="ot-batch-actions">
            <Button
              size="small"
              status="primary"
              text="批量发货"
              leftIcon={<IconPlusIcCarShipping iconSize="0.875rem" iconColor={['currentcolor']} />}
              onClick={handleBatchShip}
            />
            <Button
              size="small"
              text="批量打印"
              leftIcon={<IconPlusIcPublicPrinter iconSize="0.875rem" iconColor={['currentcolor']} />}
              onClick={handleBatchPrint}
            />
            <Button
              size="small"
              status="risk"
              text="批量取消"
              leftIcon={<IconPlusIcPublicCloseCircle iconSize="0.875rem" iconColor={['currentcolor']} />}
              onClick={handleBatchCancel}
            />
          </div>
        </div>
      )}
      <Table
        className="ot-table"
        columns={columns}
        dataset={sortedData}
        width="unset"
        enableZebraCrossing={false}
        enableColumnCompareUpdate
        enableLoading={loading}
        emptyTableMsg="暂无订单"
        enableCheckBox
        checkType="multi"
        preserveCheckedRows
        checkedRows={selectedIndexes}
        onRowCheck={(_row, checkedRows) => handleRowCheck(checkedRows)}
        onHeaderCheck={(checkedRows) => handleRowCheck(checkedRows)}
        enablePagination
        enableAutoPaging
        pagingProps={{
          currentPage: page,
          pageSize,
          pageSizeOptions: [10, 20, 50],
          recordCount: sortedData.length,
          onPageSizeChange: (size) => onPageChange(1, size),
        }}
        onPageChange={(p) => onPageChange(p, pageSize)}
        disableEviewSort
        enableOriginSort
        onColumnSort={(col, type) => {
          if (!type || type === "origin") {
            onSorterChange({});
          } else {
            onSorterChange({ field: col, order: type === "asc" ? "ascend" : "descend" });
          }
        }}
      />

      {/* 发货 / 取消 / 批量确认弹窗（antd Modal.confirm → MessageDialog） */}
      <MessageDialog
        type={confirmCfg?.type || "confirm"}
        isOpen={!!confirm}
        content={confirmCfg?.content || ""}
        detail={confirmCfg?.detail}
        onClose={() => setConfirm(null)}
        buttons={{
          cancel: { text: "再想想", onClick: () => setConfirm(null) },
          ok: { text: confirmCfg?.okText || "确定", onClick: handleConfirmOk },
        }}
      />

      {/* 修改地址弹窗 — H5 表单骨架 */}
      <Dialog
        isOpen={!!addressTarget}
        title={addressTarget ? `修改收货地址 · ${addressTarget.orderNo}` : ""}
        size={[560, "auto"]}
        style={{ maxHeight: "80vh" }}
        onClose={() => setAddressTarget(null)}
        buttons={[
          { text: "取消", onClick: () => setAddressTarget(null) },
          { text: "保存地址", status: "primary", onClick: saveAddress },
        ]}
      >
        <form
          className="fm"
          onSubmit={(e) => {
            e.preventDefault();
            saveAddress();
          }}
        >
          <div className="fm-field">
            <label className="fm-label fm-required" htmlFor="fm-receiver">
              收货人
            </label>
            <TextField
              id="fm-receiver"
              value={addressForm.receiver}
              placeholder="请输入收货人姓名"
              onChange={(value) => {
                setAddressForm({ ...addressForm, receiver: value });
                if (addressErrors.receiver) setAddressErrors({ ...addressErrors, receiver: "" });
              }}
            />
            {addressErrors.receiver && <div className="fm-error">{addressErrors.receiver}</div>}
          </div>
          <div className="fm-field">
            <label className="fm-label fm-required" htmlFor="fm-phone">
              手机号
            </label>
            <TextField
              id="fm-phone"
              value={addressForm.phone}
              placeholder="请输入 11 位手机号"
              onChange={(value) => {
                setAddressForm({ ...addressForm, phone: value });
                if (addressErrors.phone) setAddressErrors({ ...addressErrors, phone: "" });
              }}
            />
            {addressErrors.phone && <div className="fm-error">{addressErrors.phone}</div>}
          </div>
          <div className="fm-field">
            <label className="fm-label fm-required" htmlFor="fm-address">
              详细地址
            </label>
            <TextField
              id="fm-address"
              value={addressForm.address}
              placeholder="省 / 市 / 区 + 街道门牌"
              onChange={(value) => {
                setAddressForm({ ...addressForm, address: value });
                if (addressErrors.address) setAddressErrors({ ...addressErrors, address: "" });
              }}
            />
            {addressErrors.address && <div className="fm-error">{addressErrors.address}</div>}
          </div>
        </form>
      </Dialog>

      {/* 备注弹窗 */}
      <Dialog
        isOpen={!!remarkTarget}
        title={remarkTarget ? `订单备注 · ${remarkTarget.orderNo}` : ""}
        size={[560, "auto"]}
        style={{ maxHeight: "80vh" }}
        onClose={() => setRemarkTarget(null)}
        buttons={[
          { text: "取消", onClick: () => setRemarkTarget(null) },
          { text: "保存备注", status: "primary", onClick: saveRemark },
        ]}
      >
        <form
          className="fm"
          onSubmit={(e) => {
            e.preventDefault();
            saveRemark();
          }}
        >
          <div className="fm-field">
            <label className="fm-label" htmlFor="fm-remark">
              备注内容
            </label>
            <TextArea
              id="fm-remark"
              rows={3}
              maxLength={80}
              value={remarkText}
              placeholder="输入发货 / 客服备注，保存后在详情中可见"
              onChange={(value) => setRemarkText(value)}
            />
          </div>
        </form>
      </Dialog>

      <Notice notice={notice} onClose={() => setNotice(null)} />
    </div>
  );
}
