// Layer 4: ④ 筛选工具栏 — 关键词搜索 / 支付方式 / 下单日期范围 / 金额区间 / 预约配送时段（快捷预设）/ 重置
// 快捷键：任意位置按 "/" 聚焦搜索框
import { useEffect } from "react";
import { IconPlusIcIctX, IconPlusIcPublicAlarmClock, IconPlusIcPublicClose, IconPlusIcPublicResetting, IconPlusIcPublicSearch } from '@hui/icon-plus';
import dayjs from "dayjs";
import Button from "@nce/eview-react/Button";
import TextField from "@/shared/TextField";
import Spinner from "@/shared/Spinner";
import Select from "@/shared/Select";
import DatePicker from "@/shared/DatePicker";
import { PAY_METHODS } from "../../mock/order.jsx";
import "./index.css";

// 预约配送快捷预设（时间段选择带快捷预设）
const SLOT_PRESETS = [
  { label: "上午", value: ["09:00", "12:00"] },
  { label: "下午", value: ["14:00", "18:00"] },
  { label: "晚间", value: ["18:00", "22:00"] },
  { label: "全天", value: ["08:00", "22:00"] },
];

export default function FilterBar({ value, onChange, onReset, exception, exceptionCount, onClearException }) {
  const isSlotActive = (preset) => {
    if (!value.deliveryRange || !value.deliveryRange[0] || !value.deliveryRange[1]) return false;
    return (
      value.deliveryRange[0] === preset.value[0] &&
      value.deliveryRange[1] === preset.value[1]
    );
  };

  const applySlot = (preset) => {
    if (isSlotActive(preset)) {
      onChange({ deliveryRange: null });
    } else {
      onChange({ deliveryRange: preset.value });
    }
  };

  const isTimeoutException = exception === "timeout";

  // "/" 快捷键聚焦搜索框（输入态下不拦截）
  useEffect(() => {
    const handler = (e) => {
      if (e.key !== "/") return;
      const tag = (document.activeElement && document.activeElement.tagName) || "";
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      e.preventDefault();
      const el = document.querySelector(".fb-search input");
      if (el) el.focus();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  // 金额区间校验（min > max 视为无效，过滤时忽略并提示）
  const amountInvalid =
    value.amountMin != null &&
    value.amountMax != null &&
    value.amountMin > value.amountMax;

  return (
    <div className="filter-bar">
      <div className="fb-row">
        <div className="fb-group">
          <span className="fb-label">搜索订单</span>
          <TextField
            className="fb-search"
            size="small"
            placeholder="订单号 / 收货人 / 手机号（按 / 聚焦）"
            value={value.keyword}
            onChange={(val) => onChange({ keyword: val })}
            suffix={<IconPlusIcPublicSearch iconSize="0.875rem" iconColor={['currentcolor']} />}
          />
        </div>
        <div className="fb-group">
          <span className="fb-label">支付方式</span>
          <Select
            size="small"
            enableClear
            style={{ width: "7.5rem" }}
            options={[{ text: "全部方式", value: "" }, ...PAY_METHODS.map((m) => ({ text: m, value: m }))]}
            value={value.payMethod || ""}
            onChange={(v) => onChange({ payMethod: v || "" })}
          />
        </div>
        <div className="fb-group">
          <span className="fb-label">下单日期</span>
          <DatePicker
            style={{ width: "15rem" }}
            type="date"
            format="yyyy-MM-dd"
            range={value.dateRange ? [value.dateRange[0]?.toDate(), value.dateRange[1]?.toDate()] : []}
            onChange={(dateString, date, target) => {
              if (!date) return;
              if (target === "from") {
                const to = value.dateRange?.[1] || dayjs();
                onChange({ dateRange: [dayjs(date), to] });
              } else if (target === "to") {
                const from = value.dateRange?.[0] || dayjs();
                onChange({ dateRange: [from, dayjs(date)] });
              }
            }}
          />
        </div>
        <div className="fb-group">
          <span className="fb-label">金额区间</span>
          <div className="fb-amount">
            <Spinner
              min={0}
              value={value.amountMin ?? 0}
              doNotFocusWhenValueUpdate
              onChange={(v) => onChange({ amountMin: v })}
            />
            <span className="fb-dash">—</span>
            <Spinner
              min={0}
              value={value.amountMax ?? 0}
              doNotFocusWhenValueUpdate
              onChange={(v) => onChange({ amountMax: v })}
            />
          </div>
        </div>
        <div className="fb-group">
          <span className="fb-label">预约配送</span>
          <div className="fb-time-range">
            <input
              type="time"
              className="fb-time-input"
              value={value.deliveryRange?.[0] || ""}
              onChange={(e) => {
                const to = value.deliveryRange?.[1] || "";
                onChange({ deliveryRange: [e.target.value, to] });
              }}
            />
            <span className="fb-dash">—</span>
            <input
              type="time"
              className="fb-time-input"
              value={value.deliveryRange?.[1] || ""}
              onChange={(e) => {
                const from = value.deliveryRange?.[0] || "";
                onChange({ deliveryRange: [from, e.target.value] });
              }}
            />
          </div>
          <div className="fb-chips">
            {SLOT_PRESETS.map((p) => {
              const on = isSlotActive(p);
              return (
                <a
                  key={p.label}
                  className={on ? "fb-chip fb-chip-on" : "fb-chip"}
                  onClick={() => applySlot(p)}
                >
                  {p.label}
                </a>
              );
            })}
          </div>
        </div>
        <Button
          className="fb-reset"
          size="small"
          text="重置"
          leftIcon={<IconPlusIcPublicResetting iconSize="0.875rem" iconColor={['currentcolor']} />}
          onClick={onReset}
        />
      </div>
      {amountInvalid && (
        <div className="fb-applied">
          <span className="fb-amount-warn">
            金额区间无效：最大金额需不小于最小金额，当前已忽略金额筛选
          </span>
        </div>
      )}
      {exception && (
        <div className="fb-applied">
          <span className="fb-applied-chip">
            {isTimeoutException ? <IconPlusIcPublicAlarmClock iconSize="0.875rem" iconColor={['currentcolor']} /> : <IconPlusIcIctX iconSize="0.875rem" iconColor={['currentcolor']} />}
            已应用筛选：
            {isTimeoutException
              ? `超时未发货 · ${exceptionCount} 单`
              : `物流异常 · ${exceptionCount} 单`}
            <IconPlusIcPublicClose iconSize="0.75rem" iconColor={['currentcolor']} className="fb-chip-close" onClick={onClearException} />
          </span>
        </div>
      )}
    </div>
  );
}
