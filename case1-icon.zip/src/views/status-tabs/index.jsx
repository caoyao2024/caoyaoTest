// Layer 4: ③ 状态页签 — 数量角标（切换联动、当前页签高亮）
import Tab, { TabItem } from "@nce/eview-react/Tab";
import "./index.css";

export default function StatusTabs({ tabs, active, onChange }) {
  const activeIndex = tabs.findIndex((t) => t.key === active);

  return (
    <div className="status-tabs">
      <Tab
        selectedIndex={activeIndex}
        draggable={false}
        onClick={(index) => onChange(tabs[index].key)}
      >
        {tabs.map((t, i) => (
          <TabItem
            key={t.key}
            title={t.label}
            titleExtraContent={
              <span
                className={i === activeIndex ? "stab-count stab-count-on" : "stab-count"}
              >
                {t.count}
              </span>
            }
          />
        ))}
      </Tab>
    </div>
  );
}
