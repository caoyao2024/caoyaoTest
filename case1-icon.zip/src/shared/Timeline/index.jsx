import "./Timeline.css";

// antd Timeline 无 eview-react 对应（导出名 TimeLine 存在但无 Reference），手写时间轴
// props 兼容 antd 写法：items=[{ key, color, children }]；color: green/gray/blue/red
const COLOR_CLASS = {
  green: "tl-green",
  gray: "tl-gray",
  blue: "tl-blue",
  red: "tl-red",
};

export default function Timeline({ items = [], className = "" }) {
  return (
    <div className={`tl ${className}`}>
      {items.map((it, i) => {
        const isLast = i === items.length - 1;
        const dotClass = COLOR_CLASS[it.color] || "tl-gray";
        return (
          <div className="tl-item" key={it.key ?? i}>
            <div className="tl-rail">
              <span className={`tl-dot ${dotClass}`} />
              {!isLast && <span className="tl-line" />}
            </div>
            <div className="tl-content">{it.children}</div>
          </div>
        );
      })}
    </div>
  );
}
