import { createPortal } from "react-dom";
import DivMessage from "@nce/eview-react/DivMessage";

// antd message.xxx() 命令式 API → eview-react DivMessage 渲染式
// 用 createPortal 抽离到 body，避免与表单输入组件同渲染树
// notice 形状: { key, type: 'success'|'error'|'warn'|'default', text }
export default function Notice({ notice, onClose }) {
  if (!notice) return null;
  return createPortal(
    <div
      style={{
        position: "fixed",
        top: "1rem",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 1050,
      }}
    >
      <DivMessage
        key={notice.key}
        display
        type={notice.type}
        text={notice.text}
        onClose={onClose}
      />
    </div>,
    document.body
  );
}
