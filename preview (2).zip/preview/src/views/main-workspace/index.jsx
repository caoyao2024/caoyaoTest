import { Tabs } from "antd";
import UnassignedNodes from "../unassigned-nodes/index.jsx";
import BoundNodes from "../bound-nodes/index.jsx";
import "./index.css";

// Layer 4: 主体工作区 — 同级内容页签切换
export default function MainWorkspace() {
  const items = [
    { key: "unassigned", label: "无归属节点", children: <UnassignedNodes /> },
    { key: "bound", label: "已绑定节点", children: <BoundNodes /> },
  ];

  return (
    <section className="workspace">
      <Tabs className="workspace__tabs" defaultActiveKey="unassigned" items={items} />
    </section>
  );
}
