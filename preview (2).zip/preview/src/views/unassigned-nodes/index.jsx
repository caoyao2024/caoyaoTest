import { useMemo, useState } from "react";
import { Button, Tooltip } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import StatusTag from "../../components/status-tag/index.jsx";
import NodeGroupList from "../../components/node-group-list/index.jsx";
import NodeTableCard from "../../components/node-table-card/index.jsx";
import { unassignedGroups, unassignedNodes, nodeTypeLabels } from "../../mock/nodes.js";
import "./index.css";

const GROUP_STATUS_OPTIONS = [
  { value: "all", label: "全部状态" },
  { value: "unbound", label: "待绑定" },
  { value: "pending", label: "待确认" },
  { value: "conflict", label: "IP 冲突" },
  { value: "offline", label: "离线" },
];

// Layer 4: 无归属节点 — 蓝色信息条 + 左侧分组卡片 + 右侧节点表格
export default function UnassignedNodes() {
  const groups = useMemo(
    () =>
      unassignedGroups.map((group) => ({
        ...group,
        count: unassignedNodes.filter((node) => node.groupId === group.id).length,
      })),
    []
  );

  const [activeGroupId, setActiveGroupId] = useState(unassignedGroups[0].id);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);

  const activeGroup = groups.find((group) => group.id === activeGroupId) || groups[0];
  const rows = useMemo(
    () => unassignedNodes.filter((node) => node.groupId === activeGroupId),
    [activeGroupId]
  );

  const handleSelect = (id) => {
    setActiveGroupId(id);
    setSelectedRowKeys([]);
  };

  const columns = [
    {
      title: "节点名称",
      dataIndex: "name",
      key: "name",
      width: 190,
      fixed: "left",
      render: (text) => <a className="table-link">{text}</a>,
    },
    { title: "IP 地址", dataIndex: "ip", key: "ip", width: 140 },
    {
      title: "设备类型",
      dataIndex: "type",
      key: "type",
      width: 110,
      render: (type) => nodeTypeLabels[type] || type,
    },
    { title: "型号", dataIndex: "model", key: "model", width: 200 },
    { title: "软件版本", dataIndex: "version", key: "version", width: 140 },
    { title: "所属区域", dataIndex: "region", key: "region", width: 130 },
    {
      title: "状态",
      dataIndex: "status",
      key: "status",
      width: 110,
      render: (status) => <StatusTag status={status} />,
    },
    { title: "发现时间", dataIndex: "discoveredAt", key: "discoveredAt", width: 160 },
    {
      title: "操作",
      key: "action",
      width: 130,
      render: () => (
        <div className="table-actions">
          <Tooltip title="分配归属">
            <Button shape="circle" size="small" icon={<Icon name="link" size="0.875rem" />} />
          </Tooltip>
          <Tooltip title="忽略该节点">
            <Button shape="circle" size="small" icon={<Icon name="eye-off" size="0.875rem" />} />
          </Tooltip>
          <Tooltip title="更多操作">
            <Button shape="circle" size="small" icon={<Icon name="ellipsis" size="0.875rem" />} />
          </Tooltip>
        </div>
      ),
    },
  ];

  return (
    <div className="unassigned-view">
      <div className="info-banner">
        <Icon name="info" size="1.25rem" className="info-banner__icon" />
        <div className="info-banner__content">
          <p className="info-banner__title">
            发现 {unassignedNodes.length} 个无归属节点，尚未纳入任何业务分组
          </p>
          <p className="info-banner__desc">
            这些设备已接入网络但未完成归属分配，请在 7 天内确认归属，逾期将自动转入隔离网段。
          </p>
        </div>
        <a className="info-banner__link">查看扫描报告</a>
        <Button size="small" type="primary" className="info-banner__action">
          立即处理
        </Button>
      </div>

      <div className="unassigned-body">
        <NodeGroupList
          items={groups}
          activeKey={activeGroupId}
          onSelect={handleSelect}
          statusOptions={GROUP_STATUS_OPTIONS}
          searchPlaceholder="搜索分组名称或网段"
          emptyText="没有匹配的分组"
        />

        <NodeTableCard
          title={activeGroup.name}
          meta={`网段 ${activeGroup.subnet} · 共 ${rows.length} 个节点`}
          selectedCount={selectedRowKeys.length}
          onClearSelection={() => setSelectedRowKeys([])}
          scrollX={1320}
          columns={columns}
          rows={rows}
          rowSelection={{
            selectedRowKeys,
            onChange: (keys) => setSelectedRowKeys(keys),
          }}
          actions={
            <>
              <Tooltip title="刷新列表">
                <Button size="small" icon={<Icon name="refresh-cw" size="0.875rem" />} />
              </Tooltip>
              <Button size="small" icon={<Icon name="download" size="0.875rem" />}>
                导出
              </Button>
              <Button size="small" icon={<Icon name="link" size="0.875rem" />}>
                批量绑定
              </Button>
              <Button size="small" type="primary" icon={<Icon name="plus" size="0.875rem" />}>
                分配节点
              </Button>
            </>
          }
        />
      </div>
    </div>
  );
}
