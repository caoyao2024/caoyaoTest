import { useMemo, useState } from "react";
import { Button, Tooltip } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import StatusTag from "../../components/status-tag/index.jsx";
import NodeGroupList from "../../components/node-group-list/index.jsx";
import NodeTableCard from "../../components/node-table-card/index.jsx";
import { boundGroups, boundNodes, nodeTypeLabels } from "../../mock/nodes.js";
import "./index.css";

const GROUP_STATUS_OPTIONS = [
  { value: "all", label: "全部状态" },
  { value: "online", label: "在线" },
  { value: "warning", label: "告警" },
  { value: "maintenance", label: "维护中" },
  { value: "offline", label: "离线" },
];

// Layer 4: 已绑定节点 — 左侧站点分组 + 右侧已归属节点表格
export default function BoundNodes() {
  const groups = useMemo(
    () =>
      boundGroups.map((group) => ({
        ...group,
        count: boundNodes.filter((node) => node.site === group.id).length,
      })),
    []
  );

  const [activeGroupId, setActiveGroupId] = useState(boundGroups[0].id);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);

  const activeGroup = groups.find((group) => group.id === activeGroupId) || groups[0];
  const rows = useMemo(
    () => boundNodes.filter((node) => node.site === activeGroupId),
    [activeGroupId]
  );

  const handleSelect = (id) => {
    setActiveGroupId(id);
    setSelectedRowKeys([]);
  };

  const columns = [
    {
      title: "节点名称",
      dataIndex: "name",
      key: "name",
      width: 200,
      fixed: "left",
      render: (text) => <a className="table-link">{text}</a>,
    },
    { title: "IP 地址", dataIndex: "ip", key: "ip", width: 140 },
    {
      title: "设备类型",
      dataIndex: "type",
      key: "type",
      width: 110,
      render: (type) => nodeTypeLabels[type] || type,
    },
    { title: "型号", dataIndex: "model", key: "model", width: 200 },
    {
      title: "所属站点",
      dataIndex: "site",
      key: "site",
      width: 200,
      render: (site) => {
        const group = boundGroups.find((item) => item.id === site);
        return group ? group.name : site;
      },
    },
    {
      title: "状态",
      dataIndex: "status",
      key: "status",
      width: 110,
      render: (status) => <StatusTag status={status} />,
    },
    { title: "最近上报", dataIndex: "lastReportAt", key: "lastReportAt", width: 160 },
    {
      title: "操作",
      key: "action",
      width: 130,
      render: () => (
        <div className="table-actions">
          <Tooltip title="查看详情">
            <Button
              shape="circle"
              size="small"
              icon={<Icon name="square-arrow-out-up-right" size="0.875rem" />}
            />
          </Tooltip>
          <Tooltip title="解绑节点">
            <Button shape="circle" size="small" icon={<Icon name="unlink" size="0.875rem" />} />
          </Tooltip>
          <Tooltip title="更多操作">
            <Button shape="circle" size="small" icon={<Icon name="ellipsis" size="0.875rem" />} />
          </Tooltip>
        </div>
      ),
    },
  ];

  return (
    <div className="bound-view">
      <NodeGroupList
        items={groups}
        activeKey={activeGroupId}
        onSelect={handleSelect}
        statusOptions={GROUP_STATUS_OPTIONS}
        searchPlaceholder="搜索站点名称或网段"
        emptyText="没有匹配的站点"
      />

      <NodeTableCard
        title={activeGroup.name}
        meta={`网段 ${activeGroup.subnet} · 共 ${rows.length} 个已绑定节点`}
        selectedCount={selectedRowKeys.length}
        onClearSelection={() => setSelectedRowKeys([])}
        scrollX={1300}
        columns={columns}
        rows={rows}
        rowSelection={{
          selectedRowKeys,
          onChange: (keys) => setSelectedRowKeys(keys),
        }}
        actions={
          <>
            <Tooltip title="刷新列表">
              <Button size="small" icon={<Icon name="refresh-cw" size="0.875rem" />} />
            </Tooltip>
            <Button size="small" icon={<Icon name="download" size="0.875rem" />}>
              导出
            </Button>
            <Button size="small" icon={<Icon name="unlink" size="0.875rem" />}>
              批量解绑
            </Button>
            <Button size="small" type="primary" icon={<Icon name="plus" size="0.875rem" />}>
              绑定新节点
            </Button>
          </>
        }
      />
    </div>
  );
}
