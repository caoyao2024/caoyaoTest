import { useState } from "react";
import { Menu, Button, Dropdown } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import { useApp } from "../../context.jsx";
import "./index.css";

// Layer 4: 顶部导航 — 左 Logo + 顶部菜单，右 换肤 / 国际化 / 个人中心
export default function HeaderBar() {
  const { isDark, toggleDark } = useApp();
  const [current, setCurrent] = useState("node");

  const menuItems = [
    { key: "overview", icon: <Icon name="layout-dashboard" size="0.875rem" />, label: "总览" },
    { key: "assets", icon: <Icon name="server" size="0.875rem" />, label: "资产管理" },
    { key: "node", icon: <Icon name="network" size="0.875rem" />, label: "节点管理" },
    { key: "topology", icon: <Icon name="waypoints" size="0.875rem" />, label: "拓扑视图" },
    { key: "alarm", icon: <Icon name="bell" size="0.875rem" />, label: "告警中心" },
    { key: "report", icon: <Icon name="chart-column" size="0.875rem" />, label: "统计分析" },
    { key: "setting", icon: <Icon name="settings" size="0.875rem" />, label: "系统设置" },
  ];

  const langItems = [
    { key: "zh-CN", label: "简体中文" },
    { key: "en-US", label: "English" },
  ];

  const userItems = [
    { key: "profile", icon: <Icon name="user" size="0.875rem" />, label: "个人中心" },
    { key: "security", icon: <Icon name="shield-check" size="0.875rem" />, label: "账号安全" },
    { key: "preference", icon: <Icon name="sliders-horizontal" size="0.875rem" />, label: "偏好设置" },
    { type: "divider" },
    { key: "logout", icon: <Icon name="log-out" size="0.875rem" />, label: "退出登录", danger: true },
  ];

  return (
    <header className="app-header">
      <div className="app-header__brand">
        <span className="app-header__logo">
          <Icon name="waypoints" size="1.25rem" />
        </span>
        <span className="app-header__title">ICT 智联运维平台</span>
      </div>

      <Menu
        mode="horizontal"
        className="app-header__menu"
        selectedKeys={[current]}
        items={menuItems}
        onClick={({ key }) => setCurrent(key)}
      />

      <div className="app-header__tools">
        <Button
          type="text"
          className="app-header__icon-btn"
          aria-label="切换主题"
          onClick={toggleDark}
          icon={<Icon name={isDark ? "sun" : "moon"} size="1rem" />}
        />

        <Dropdown menu={{ items: langItems, selectedKeys: ["zh-CN"] }} trigger={["click"]}>
          <Button
            type="text"
            className="app-header__icon-btn"
            aria-label="切换语言"
            icon={<Icon name="languages" size="1rem" />}
          />
        </Dropdown>

        <span className="app-header__divider" />

        <Dropdown menu={{ items: userItems }} trigger={["click"]} placement="bottomRight">
          <button type="button" className="app-header__user">
            <span className="app-header__avatar">
              <Icon name="user" size="1rem" />
            </span>
            <span className="app-header__user-info">
              <span className="app-header__user-name">王强</span>
              <span className="app-header__user-role">网络运维管理员</span>
            </span>
            <Icon name="chevron-down" size="0.875rem" className="app-header__user-caret" />
          </button>
        </Dropdown>
      </div>
    </header>
  );
}
