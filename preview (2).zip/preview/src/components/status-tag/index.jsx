import "./index.css";

// Layer 3: 通用状态标签 — 软色底 + 状态点，随 token 自动换肤
const STATUS_MAP = {
  unbound: { label: "待绑定", tone: "info" },
  pending: { label: "待确认", tone: "warning" },
  conflict: { label: "IP 冲突", tone: "error" },
  offline: { label: "离线", tone: "neutral" },
  online: { label: "在线", tone: "success" },
  warning: { label: "告警", tone: "critical" },
  maintenance: { label: "维护中", tone: "info" },
};

export default function StatusTag({ status, label }) {
  const conf = STATUS_MAP[status] || { label: status, tone: "neutral" };
  return (
    <span className={"status-tag status-tag--" + conf.tone}>
      <span className="status-tag__dot" />
      {label || conf.label}
    </span>
  );
}
