import { useMemo, useState } from "react";
import { Input, Select, Empty } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import StatusTag from "../status-tag/index.jsx";
import "./index.css";

// Layer 3: 纵向滚动分组卡片列表（顶部下拉 + 搜索）
export default function NodeGroupList({
  items,
  activeKey,
  onSelect,
  statusOptions,
  searchPlaceholder,
  emptyText,
}) {
  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState("all");

  const filtered = useMemo(() => {
    const kw = keyword.trim().toLowerCase();
    return items.filter((item) => {
      const hitStatus = status === "all" || item.status === status;
      const hitKeyword =
        !kw ||
        item.name.toLowerCase().includes(kw) ||
        item.subnet.toLowerCase().includes(kw);
      return hitStatus && hitKeyword;
    });
  }, [items, keyword, status]);

  const total = items.reduce((sum, item) => sum + item.count, 0);

  return (
    <aside className="node-group-list">
      <div className="node-group-list__head">
        <span className="node-group-list__title">发现分组</span>
        <span className="node-group-list__total">{total} 个节点</span>
      </div>

      <div className="node-group-list__filters">
        <Select
          size="small"
          value={status}
          onChange={setStatus}
          options={statusOptions}
          className="node-group-list__select"
        />
        <Input
          size="small"
          value={keyword}
          allowClear
          onChange={(e) => setKeyword(e.target.value)}
          placeholder={searchPlaceholder}
          suffix={<Icon name="search" size="0.875rem" />}
        />
      </div>

      <div className="node-group-list__scroll">
        {filtered.length === 0 ? (
          <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={emptyText} />
        ) : (
          filtered.map((item) => (
            <button
              type="button"
              key={item.id}
              className={
                "group-card" + (item.id === activeKey ? " group-card--active" : "")
              }
              onClick={() => onSelect(item.id)}
            >
              <span className="group-card__head">
                <span className="group-card__name">{item.name}</span>
                <span className="group-card__count">{item.count}</span>
              </span>
              <span className="group-card__sub">
                <Icon name="network" size="0.875rem" />
                {item.subnet}
              </span>
              <span className="group-card__foot">
                <StatusTag status={item.status} />
                <span className="group-card__time">{item.updatedAt}</span>
              </span>
            </button>
          ))
        )}
      </div>
    </aside>
  );
}
