import { Table } from "antd";
import "./index.css";

// Layer 3: 节点表格卡片 — 卡片头（标题/统计/操作区）+ 数据表格
export default function NodeTableCard({
  title,
  meta,
  selectedCount,
  onClearSelection,
  actions,
  columns,
  rows,
  rowSelection,
  scrollX,
}) {
  return (
    <section className="node-table-card">
      <div className="node-table-card__toolbar">
        <div className="node-table-card__heading">
          <span className="node-table-card__name">{title}</span>
          <span className="node-table-card__meta">
            {meta}
            {selectedCount > 0 && (
              <span className="node-table-card__selected">已选 {selectedCount} 项</span>
            )}
          </span>
        </div>

        <div className="node-table-card__actions">
          {selectedCount > 0 && (
            <a className="table-link" onClick={onClearSelection}>
              清空选择
            </a>
          )}
          {actions}
        </div>
      </div>

      <Table
        rowKey="id"
        columns={columns}
        dataSource={rows}
        scroll={{ x: scrollX }}
        rowSelection={rowSelection}
        pagination={{
          pageSize: 20,
          hideOnSinglePage: true,
          showSizeChanger: false,
          showTotal: (total) => `共 ${total} 条`,
        }}
      />
    </section>
  );
}
