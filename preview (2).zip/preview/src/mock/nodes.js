// Layer 2: 节点管理域 mock 数据
// 分组种子 -> 按设备族群批量展开，保留语义字段：id / name / ip / type / model / version / status

export const nodeTypeOptions = [
  { value: "all", label: "全部类型" },
  { value: "switch", label: "交换机" },
  { value: "router", label: "路由器" },
  { value: "ap", label: "无线 AP" },
  { value: "server", label: "服务器" },
  { value: "storage", label: "存储" },
  { value: "firewall", label: "防火墙" },
  { value: "edge", label: "边缘网关" },
  { value: "camera", label: "视频终端" },
  { value: "phone", label: "IP 话机" },
];

export const nodeTypeLabels = {
  switch: "交换机",
  router: "路由器",
  ap: "无线 AP",
  server: "服务器",
  storage: "存储",
  firewall: "防火墙",
  edge: "边缘网关",
  camera: "视频终端",
  phone: "IP 话机",
};

// 状态循环模板，让同一族群内的节点状态有分布
const U_CYCLE = ["unbound", "unbound", "unbound", "pending", "unbound", "conflict", "unbound", "offline"];
const B_CYCLE = ["online", "online", "online", "warning", "online", "offline", "online", "online", "maintenance", "online"];

function pad(value) {
  return String(value).padStart(2, "0");
}

function timeMinus(stamp, minutes) {
  const parts = stamp.split(" ");
  const hm = parts[1].split(":");
  let total = Number(hm[0]) * 60 + Number(hm[1]) - minutes;
  total = ((total % 1440) + 1440) % 1440;
  return parts[0] + " " + pad(Math.floor(total / 60)) + ":" + pad(total % 60);
}

function staleMinutes(status, index) {
  if (status === "offline") return 300 + index * 6;
  if (status === "maintenance") return 100 + index * 4;
  if (status === "warning") return 30 + index * 3;
  return index * 2;
}

// 按族群展开分组内的节点
function expandGroup(seed, cycle, withReportTime) {
  const nodes = [];
  seed.fleets.forEach((fleet) => {
    const statuses = fleet.statuses || cycle;
    for (let i = 0; i < fleet.count; i += 1) {
      const status = statuses[i % statuses.length];
      const node = {
        id: seed.id + "-" + pad(nodes.length + 1),
        name: fleet.prefix + "-" + seed.code + (fleet.from + i),
        ip: fleet.ipBase + (fleet.ipFrom + i),
        type: fleet.type,
        model: fleet.model,
        version: fleet.version,
        status,
      };
      if (withReportTime) {
        node.lastReportAt = timeMinus(seed.updatedAt, staleMinutes(status, i));
        node.site = seed.id;
      } else {
        node.region = seed.region;
        node.groupId = seed.id;
        node.discoveredAt = seed.updatedAt;
      }
      nodes.push(node);
    }
  });
  return nodes;
}

/* ── 无归属节点：发现分组（12 组 × 20 节点） ── */
const unassignedSeeds = [
  {
    id: "g1", code: "A", name: "研发楼 A 座 · 新发现", subnet: "10.20.31.0/24",
    status: "unbound", updatedAt: "2026-09-29 09:12", region: "研发楼 A 座",
    fleets: [
      { prefix: "汇聚交换机", from: 1, count: 1, ipBase: "10.20.31.", ipFrom: 2, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "接入交换机", from: 1, count: 5, ipBase: "10.20.31.", ipFrom: 11, type: "switch", model: "S5735-L48T4S-A1", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 8, ipBase: "10.20.31.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "打印服务器", from: 1, count: 2, ipBase: "10.20.31.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "视频终端", from: 1, count: 4, ipBase: "10.20.31.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
    ],
  },
  {
    id: "g2", code: "B", name: "研发楼 B 座 · 新发现", subnet: "10.20.32.0/24",
    status: "pending", updatedAt: "2026-09-29 08:47", region: "研发楼 B 座",
    fleets: [
      { prefix: "接入交换机", from: 1, count: 6, ipBase: "10.20.32.", ipFrom: 11, type: "switch", model: "S5735-L48T4S-A1", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 8, ipBase: "10.20.32.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "视频终端", from: 1, count: 4, ipBase: "10.20.32.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "门禁终端", from: 1, count: 2, ipBase: "10.20.32.", ipFrom: 71, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
    ],
  },
  {
    id: "g3", code: "D", name: "数据中心 1F · 机柜排查", subnet: "10.30.11.0/24",
    status: "conflict", updatedAt: "2026-09-28 22:05", region: "数据中心 1F",
    fleets: [
      { prefix: "核心交换机", from: 1, count: 2, ipBase: "10.30.11.", ipFrom: 2, type: "switch", model: "CE6865-48S8CQ", version: "V200R019C10" },
      { prefix: "汇聚交换机", from: 3, count: 4, ipBase: "10.30.11.", ipFrom: 4, type: "switch", model: "CE6863-48S6CQ", version: "V200R019C10" },
      { prefix: "出口路由器", from: 1, count: 2, ipBase: "10.30.11.", ipFrom: 8, type: "router", model: "NE40E-X8A", version: "V800R012" },
      { prefix: "存储阵列", from: 1, count: 4, ipBase: "10.30.11.", ipFrom: 40, type: "storage", model: "OceanStor 5310", version: "V300R006" },
      { prefix: "管理服务器", from: 1, count: 4, ipBase: "10.30.11.", ipFrom: 90, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
      { prefix: "备份服务器", from: 1, count: 4, ipBase: "10.30.11.", ipFrom: 94, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "g4", code: "G", name: "数据中心 3F · 新增设备", subnet: "10.30.13.0/24",
    status: "unbound", updatedAt: "2026-09-28 19:33", region: "数据中心 3F",
    fleets: [
      { prefix: "计算节点", from: 1, count: 10, ipBase: "10.30.13.", ipFrom: 11, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
      { prefix: "存储节点", from: 1, count: 6, ipBase: "10.30.13.", ipFrom: 41, type: "storage", model: "OceanStor 5310", version: "V300R006" },
      { prefix: "管理交换机", from: 1, count: 2, ipBase: "10.30.13.", ipFrom: 3, type: "switch", model: "CE6863-48S6CQ", version: "V200R019C10" },
      { prefix: "带外管理", from: 1, count: 2, ipBase: "10.30.13.", ipFrom: 99, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "g5", code: "H", name: "行政楼 · 无线漫游节点", subnet: "10.40.5.0/24",
    status: "unbound", updatedAt: "2026-09-28 16:21", region: "行政楼",
    fleets: [
      { prefix: "无线AC", from: 1, count: 1, ipBase: "10.40.5.", ipFrom: 11, type: "ap", model: "AirEngine 6761-21", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 10, ipBase: "10.40.5.", ipFrom: 21, type: "ap", model: "AirEngine 6761-21", version: "V200R019C10" },
      { prefix: "接入交换机", from: 1, count: 3, ipBase: "10.40.5.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "打印服务器", from: 1, count: 2, ipBase: "10.40.5.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "视频终端", from: 1, count: 4, ipBase: "10.40.5.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
    ],
  },
  {
    id: "g6", code: "P", name: "生产车间 · 边缘网关", subnet: "10.50.2.0/24",
    status: "pending", updatedAt: "2026-09-28 14:08", region: "生产车间",
    fleets: [
      { prefix: "边缘网关", from: 1, count: 6, ipBase: "10.50.2.", ipFrom: 11, type: "edge", model: "AR617VW-LTE4", version: "V300R019" },
      { prefix: "工业交换机", from: 1, count: 8, ipBase: "10.50.2.", ipFrom: 3, type: "switch", model: "S5735I-L16T4S", version: "V200R019C10" },
      { prefix: "质检终端", from: 1, count: 4, ipBase: "10.50.2.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "工控服务器", from: 1, count: 2, ipBase: "10.50.2.", ipFrom: 90, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "g7", code: "M", name: "会议中心 · 临时接入", subnet: "10.60.1.0/24",
    status: "unbound", updatedAt: "2026-09-27 18:52", region: "会议中心",
    fleets: [
      { prefix: "接入交换机", from: 1, count: 3, ipBase: "10.60.1.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 9, ipBase: "10.60.1.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "会议终端", from: 1, count: 4, ipBase: "10.60.1.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "直播服务器", from: 1, count: 2, ipBase: "10.60.1.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "录播终端", from: 1, count: 2, ipBase: "10.60.1.", ipFrom: 82, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "g8", code: "S", name: "门禁系统 · 视频子网", subnet: "10.70.3.0/24",
    status: "offline", updatedAt: "2026-09-27 11:30", region: "门禁系统",
    fleets: [
      { prefix: "门禁网关", from: 1, count: 2, ipBase: "10.70.3.", ipFrom: 8, type: "firewall", model: "USG6525E", version: "V600R007" },
      { prefix: "安防交换机", from: 1, count: 4, ipBase: "10.70.3.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "视频终端", from: 1, count: 10, ipBase: "10.70.3.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "存储服务器", from: 1, count: 4, ipBase: "10.70.3.", ipFrom: 90, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "g9", code: "T", name: "培训中心 · 新发现", subnet: "10.85.2.0/24",
    status: "unbound", updatedAt: "2026-09-27 09:40", region: "培训中心",
    fleets: [
      { prefix: "接入交换机", from: 1, count: 4, ipBase: "10.85.2.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 8, ipBase: "10.85.2.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "教学终端", from: 1, count: 6, ipBase: "10.85.2.", ipFrom: 61, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "录播服务器", from: 1, count: 2, ipBase: "10.85.2.", ipFrom: 90, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "g10", code: "W", name: "仓储物流 · 无线节点", subnet: "10.88.1.0/24",
    status: "unbound", updatedAt: "2026-09-26 20:15", region: "仓储物流",
    fleets: [
      { prefix: "无线AP", from: 1, count: 10, ipBase: "10.88.1.", ipFrom: 21, type: "ap", model: "AirEngine 6761-21", version: "V200R019C10" },
      { prefix: "边缘网关", from: 1, count: 4, ipBase: "10.88.1.", ipFrom: 11, type: "edge", model: "AR617VW-LTE4", version: "V300R019" },
      { prefix: "工业交换机", from: 1, count: 4, ipBase: "10.88.1.", ipFrom: 3, type: "switch", model: "S5735I-L16T4S", version: "V200R019C10" },
      { prefix: "视频终端", from: 1, count: 2, ipBase: "10.88.1.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
    ],
  },
  {
    id: "g11", code: "V", name: "客服中心 · 语音设备", subnet: "10.80.3.0/24",
    status: "pending", updatedAt: "2026-09-26 15:02", region: "客服中心",
    fleets: [
      { prefix: "语音网关", from: 1, count: 4, ipBase: "10.80.3.", ipFrom: 11, type: "edge", model: "AR617VW-LTE4", version: "V300R019" },
      { prefix: "接入交换机", from: 1, count: 4, ipBase: "10.80.3.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "IP 话机", from: 1, count: 10, ipBase: "10.80.3.", ipFrom: 61, type: "phone", model: "eSpace 7960", version: "V600R006" },
      { prefix: "录音服务器", from: 1, count: 2, ipBase: "10.80.3.", ipFrom: 90, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "g12", code: "K", name: "园区门岗 · 访客终端", subnet: "10.92.1.0/24",
    status: "conflict", updatedAt: "2026-09-26 08:22", region: "园区门岗",
    fleets: [
      { prefix: "门禁网关", from: 1, count: 2, ipBase: "10.92.1.", ipFrom: 8, type: "firewall", model: "USG6525E", version: "V600R007" },
      { prefix: "接入交换机", from: 1, count: 2, ipBase: "10.92.1.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "视频终端", from: 1, count: 10, ipBase: "10.92.1.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "访客终端", from: 1, count: 6, ipBase: "10.92.1.", ipFrom: 101, type: "phone", model: "eSpace 7960", version: "V600R006" },
    ],
  },
];

export const unassignedGroups = unassignedSeeds.map((seed) => ({
  id: seed.id,
  name: seed.name,
  subnet: seed.subnet,
  status: seed.status,
  updatedAt: seed.updatedAt,
}));

export const unassignedNodes = unassignedSeeds.flatMap((seed) => expandGroup(seed, U_CYCLE, false));

/* ── 已绑定节点：业务站点分组（12 组 × 20 节点） ── */
const boundSeeds = [
  {
    id: "b1", code: "R", name: "研发中心 · 有线接入", subnet: "10.20.31.0/24",
    status: "online", updatedAt: "2026-09-29 10:42",
    fleets: [
      { prefix: "研发汇聚交换机", from: 1, count: 2, ipBase: "10.20.31.", ipFrom: 2, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "研发接入交换机", from: 1, count: 6, ipBase: "10.20.31.", ipFrom: 11, type: "switch", model: "S5735-L48T4S-A1", version: "V200R019C10" },
      { prefix: "研发无线AP", from: 1, count: 6, ipBase: "10.20.31.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "研发服务器", from: 1, count: 6, ipBase: "10.20.31.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "b2", code: "DC", name: "数据中心 · 核心网络", subnet: "10.30.11.0/24",
    status: "warning", updatedAt: "2026-09-29 10:41",
    fleets: [
      { prefix: "核心交换机", from: 1, count: 4, ipBase: "10.30.11.", ipFrom: 2, type: "switch", model: "CE6865-48S8CQ", version: "V200R019C10" },
      { prefix: "汇聚交换机", from: 1, count: 6, ipBase: "10.30.11.", ipFrom: 6, type: "switch", model: "CE6863-48S6CQ", version: "V200R019C10" },
      { prefix: "出口路由器", from: 1, count: 2, ipBase: "10.30.11.", ipFrom: 1, type: "router", model: "NE40E-X8A", version: "V800R012" },
      { prefix: "存储阵列", from: 1, count: 4, ipBase: "10.30.11.", ipFrom: 40, type: "storage", model: "OceanStor 5310", version: "V300R006" },
      { prefix: "管理服务器", from: 1, count: 4, ipBase: "10.30.11.", ipFrom: 90, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "b3", code: "AO", name: "行政办公 · 无线覆盖", subnet: "10.40.5.0/24",
    status: "online", updatedAt: "2026-09-29 10:38",
    fleets: [
      { prefix: "行政无线AC", from: 1, count: 1, ipBase: "10.40.5.", ipFrom: 11, type: "ap", model: "AirEngine 6761-21", version: "V200R019C10" },
      { prefix: "行政无线AP", from: 1, count: 10, ipBase: "10.40.5.", ipFrom: 21, type: "ap", model: "AirEngine 6761-21", version: "V200R019C10" },
      { prefix: "行政接入交换机", from: 1, count: 5, ipBase: "10.40.5.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "行政服务器", from: 1, count: 4, ipBase: "10.40.5.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "b4", code: "PP", name: "生产园区 · 工业环网", subnet: "10.50.2.0/24",
    status: "maintenance", updatedAt: "2026-09-29 09:55",
    fleets: [
      { prefix: "工业交换机", from: 1, count: 8, ipBase: "10.50.2.", ipFrom: 3, type: "switch", model: "S5735I-L16T4S", version: "V200R019C10" },
      { prefix: "边缘网关", from: 1, count: 6, ipBase: "10.50.2.", ipFrom: 11, type: "edge", model: "AR617VW-LTE4", version: "V300R019" },
      { prefix: "质检终端", from: 1, count: 4, ipBase: "10.50.2.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "工控服务器", from: 1, count: 2, ipBase: "10.50.2.", ipFrom: 90, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "b5", code: "SC", name: "安防监控 · 视频专网", subnet: "10.70.3.0/24",
    status: "online", updatedAt: "2026-09-29 10:30",
    fleets: [
      { prefix: "安防汇聚交换机", from: 1, count: 4, ipBase: "10.70.3.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "门禁网关", from: 1, count: 2, ipBase: "10.70.3.", ipFrom: 8, type: "firewall", model: "USG6525E", version: "V600R007" },
      { prefix: "视频终端", from: 1, count: 10, ipBase: "10.70.3.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "存储服务器", from: 1, count: 4, ipBase: "10.70.3.", ipFrom: 90, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "b6", code: "FN", name: "财务专线 · 独立域", subnet: "10.90.1.0/24",
    status: "offline", updatedAt: "2026-09-29 07:18",
    fleets: [
      { prefix: "财务防火墙", from: 1, count: 4, ipBase: "10.90.1.", ipFrom: 2, type: "firewall", model: "USG6525E", version: "V600R007" },
      { prefix: "财务交换机", from: 1, count: 6, ipBase: "10.90.1.", ipFrom: 11, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "财务服务器", from: 1, count: 6, ipBase: "10.90.1.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "财务备份", from: 1, count: 4, ipBase: "10.90.1.", ipFrom: 40, type: "storage", model: "OceanStor 5310", version: "V300R006" },
    ],
  },
  {
    id: "b7", code: "CS", name: "客服中心 · 语音专网", subnet: "10.80.2.0/24",
    status: "online", updatedAt: "2026-09-29 10:26",
    fleets: [
      { prefix: "语音网关", from: 1, count: 4, ipBase: "10.80.2.", ipFrom: 11, type: "edge", model: "AR617VW-LTE4", version: "V300R019" },
      { prefix: "客服接入交换机", from: 1, count: 6, ipBase: "10.80.2.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "IP 话机", from: 1, count: 8, ipBase: "10.80.2.", ipFrom: 61, type: "phone", model: "eSpace 7960", version: "V600R006" },
      { prefix: "客服服务器", from: 1, count: 2, ipBase: "10.80.2.", ipFrom: 90, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "b8", code: "TR", name: "培训教室 · 有线接入", subnet: "10.85.1.0/24",
    status: "online", updatedAt: "2026-09-29 10:15",
    fleets: [
      { prefix: "培训接入交换机", from: 1, count: 4, ipBase: "10.85.1.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 6, ipBase: "10.85.1.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "教学终端", from: 1, count: 6, ipBase: "10.85.1.", ipFrom: 61, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "培训服务器", from: 1, count: 4, ipBase: "10.85.1.", ipFrom: 90, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "b9", code: "RB", name: "研发楼 B 座 · 有线接入", subnet: "10.20.32.0/24",
    status: "online", updatedAt: "2026-09-29 10:20",
    fleets: [
      { prefix: "研发B接入交换机", from: 1, count: 5, ipBase: "10.20.32.", ipFrom: 3, type: "switch", model: "S5735-L48T4S-A1", version: "V200R019C10" },
      { prefix: "研发B无线AP", from: 1, count: 6, ipBase: "10.20.32.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "研发B服务器", from: 1, count: 5, ipBase: "10.20.32.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
      { prefix: "研发B视频终端", from: 1, count: 4, ipBase: "10.20.32.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
    ],
  },
  {
    id: "b10", code: "GC", name: "数据中心 3F · 计算集群", subnet: "10.30.13.0/24",
    status: "online", updatedAt: "2026-09-29 10:22",
    fleets: [
      { prefix: "计算节点", from: 1, count: 10, ipBase: "10.30.13.", ipFrom: 11, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
      { prefix: "存储节点", from: 1, count: 6, ipBase: "10.30.13.", ipFrom: 41, type: "storage", model: "OceanStor 5310", version: "V300R006" },
      { prefix: "管理交换机", from: 1, count: 2, ipBase: "10.30.13.", ipFrom: 3, type: "switch", model: "CE6863-48S6CQ", version: "V200R019C10" },
      { prefix: "带外管理", from: 1, count: 2, ipBase: "10.30.13.", ipFrom: 99, type: "server", model: "FusionServer 2288H V6", version: "EulerOS 2.10" },
    ],
  },
  {
    id: "b11", code: "MM", name: "会议中心 · 多媒体", subnet: "10.60.1.0/24",
    status: "online", updatedAt: "2026-09-29 10:18",
    fleets: [
      { prefix: "接入交换机", from: 1, count: 4, ipBase: "10.60.1.", ipFrom: 3, type: "switch", model: "S5735-L24T4S-A1", version: "V200R019C10" },
      { prefix: "无线AP", from: 1, count: 6, ipBase: "10.60.1.", ipFrom: 21, type: "ap", model: "AirEngine 5761-11", version: "V200R019C10" },
      { prefix: "会议终端", from: 1, count: 6, ipBase: "10.60.1.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
      { prefix: "直播服务器", from: 1, count: 4, ipBase: "10.60.1.", ipFrom: 80, type: "server", model: "ThinkSystem SR650", version: "RHEL 8.6" },
    ],
  },
  {
    id: "b12", code: "MW", name: "仓储物流 · 无线覆盖", subnet: "10.88.1.0/24",
    status: "warning", updatedAt: "2026-09-29 09:48",
    fleets: [
      { prefix: "无线AP", from: 1, count: 10, ipBase: "10.88.1.", ipFrom: 21, type: "ap", model: "AirEngine 6761-21", version: "V200R019C10" },
      { prefix: "边缘网关", from: 1, count: 4, ipBase: "10.88.1.", ipFrom: 11, type: "edge", model: "AR617VW-LTE4", version: "V300R019" },
      { prefix: "工业交换机", from: 1, count: 4, ipBase: "10.88.1.", ipFrom: 3, type: "switch", model: "S5735I-L16T4S", version: "V200R019C10" },
      { prefix: "视频终端", from: 1, count: 2, ipBase: "10.88.1.", ipFrom: 61, type: "camera", model: "IPC-HDW2431", version: "V2.820" },
    ],
  },
];

export const boundGroups = boundSeeds.map((seed) => ({
  id: seed.id,
  name: seed.name,
  subnet: seed.subnet,
  status: seed.status,
  updatedAt: seed.updatedAt,
}));

export const boundNodes = boundSeeds.flatMap((seed) => expandGroup(seed, B_CYCLE, true));
