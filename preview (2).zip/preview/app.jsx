import { ConfigProvider } from "antd";
import zhCN from "./assets/shared/antd-zh.js";
import { AppProvider } from "./src/context.jsx";
import HeaderBar from "./src/views/header-bar/index.jsx";
import MainWorkspace from "./src/views/main-workspace/index.jsx";
import "./app.css";


export default function App() {
  return (
    <AppProvider>
      <ConfigProvider locale={zhCN}>
        <div className="app-root">
          <HeaderBar />
          <main className="app-main">
            <MainWorkspace />
          </main>
        </div>
      </ConfigProvider>
    </AppProvider>
  );
}
