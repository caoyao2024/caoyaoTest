// Layer 4: ④ 筛选工具栏 — 关键词搜索 / 支付方式 / 下单日期范围 / 金额区间 / 预约配送时段（快捷预设）/ 重置
// 快捷键：任意位置按 "/" 聚焦搜索框
import { useEffect, useRef } from "react";
import { IconPlusIcPublicClose, IconPlusIcPublicResetting, IconPlusIcPublicAlarmClock, IconPlusIcIctActionResourcePackage } from '@hui/icon-plus';
import dayjs from "dayjs";
import Button from "@nce/eview-react/Button";
import DatePicker from "@/shared/DatePicker";
import TextField from "@/shared/TextField";
import Spinner from "@/shared/Spinner";
import Select from "@/shared/Select";
import { PAY_METHODS } from "../../mock/order.js";
import "./index.css";

const at = (h, m) => dayjs().hour(h).minute(m).second(0).millisecond(0);

// 预约配送快捷预设（时间段选择带快捷预设）
const SLOT_PRESETS = [
  { label: "上午", value: [at(9, 0), at(12, 0)] },
  { label: "下午", value: [at(14, 0), at(18, 0)] },
  { label: "晚间", value: [at(18, 0), at(22, 0)] },
  { label: "全天", value: [at(8, 0), at(22, 0)] },
];

// TimePicker.RangePicker 无 eview 对应，手写两个原生 time 输入组成的时段选择器
function TimeRangePicker({ value, onChange }) {
  const from = value && value[0] ? value[0].format("HH:mm") : "";
  const to = value && value[1] ? value[1].format("HH:mm") : "";
  const setFrom = (v) => {
    const [h, m] = v.split(":").map(Number);
    onChange([dayjs().hour(h).minute(m).second(0), value && value[1] ? value[1] : dayjs().hour(22).minute(0)]);
  };
  const setTo = (v) => {
    const [h, m] = v.split(":").map(Number);
    onChange([value && value[0] ? value[0] : dayjs().hour(8).minute(0), dayjs().hour(h).minute(m).second(0)]);
  };
  return (
    <span className="fb-time-range">
      <input type="time" step="1800" value={from} onChange={(e) => setFrom(e.target.value)} />
      <span className="fb-dash">—</span>
      <input type="time" step="1800" value={to} onChange={(e) => setTo(e.target.value)} />
    </span>
  );
}

export default function FilterBar({ value, onChange, onReset, exception, exceptionCount, onClearException }) {
  const isSlotActive = (preset) => {
    if (!value.deliveryRange || !value.deliveryRange[0] || !value.deliveryRange[1]) return false;
    return (
      value.deliveryRange[0].format("HH:mm") === preset.value[0].format("HH:mm") &&
      value.deliveryRange[1].format("HH:mm") === preset.value[1].format("HH:mm")
    );
  };

  const applySlot = (preset) => {
    if (isSlotActive(preset)) {
      onChange({ deliveryRange: null });
    } else {
      onChange({ deliveryRange: preset.value });
    }
  };

  const isTimeoutException = exception === "timeout";

  const searchRef = useRef(null);

  // "/" 快捷键聚焦搜索框（输入态下不拦截）
  useEffect(() => {
    const handler = (e) => {
      if (e.key !== "/") return;
      const tag = (document.activeElement && document.activeElement.tagName) || "";
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      e.preventDefault();
      const input = searchRef.current?.querySelector?.("input");
      if (input) input.focus();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  // 金额区间校验（min > max 视为无效，过滤时忽略并提示）
  const amountInvalid =
    value.amountMin != null &&
    value.amountMax != null &&
    value.amountMin > value.amountMax;

  return (
    <div className="filter-bar">
      <div className="fb-row">
        <div className="fb-group">
          <span className="fb-label">搜索订单</span>
          <span ref={searchRef} className="fb-search">
            <TextField
              className="fb-search-input"
              placeholder="订单号 / 收货人 / 手机号（按 / 聚焦）"
              value={value.keyword}
              onChange={(v) => onChange({ keyword: v })}
            />
          </span>
        </div>
        <div className="fb-group">
          <span className="fb-label">支付方式</span>
          <Select
            enableClear
            defaultLabel="全部方式"
            style={{ width: "7.5rem" }}
            options={PAY_METHODS.map((m) => ({ value: m, text: m }))}
            value={value.payMethod}
            onChange={(v) => onChange({ payMethod: v })}
          />
        </div>
        <div className="fb-group">
          <span className="fb-label">下单日期</span>
          <DatePicker
            className="fb-date"
            style={{ width: "15rem" }}
            type="date"
            format="yyyy-MM-dd"
            range={value.dateRange ? value.dateRange.map((d) => d.toDate()) : []}
            onChange={(_dateString, date, target) => {
              if (!date) {
                onChange({ dateRange: null });
                return;
              }
              const dj = dayjs(date);
              if (target === "from") {
                onChange({ dateRange: [dj, value.dateRange?.[1] || dayjs()] });
              } else if (target === "to") {
                onChange({ dateRange: [value.dateRange?.[0] || dayjs(), dj] });
              }
            }}
          />
        </div>
        <div className="fb-group">
          <span className="fb-label">金额区间</span>
          <div className="fb-amount">
            <Spinner
              min={0}
              placeholder="最小"
              value={value.amountMin}
              onChange={(v) => onChange({ amountMin: v })}
            />
            <span className="fb-dash">—</span>
            <Spinner
              min={0}
              placeholder="最大"
              value={value.amountMax}
              onChange={(v) => onChange({ amountMax: v })}
            />
          </div>
        </div>
        <div className="fb-group">
          <span className="fb-label">预约配送</span>
          <TimeRangePicker
            value={value.deliveryRange}
            onChange={(v) => onChange({ deliveryRange: v })}
          />
          <div className="fb-chips">
            {SLOT_PRESETS.map((p) => {
              const on = isSlotActive(p);
              return (
                <a
                  key={p.label}
                  className={on ? "fb-chip fb-chip-on" : "fb-chip"}
                  onClick={() => applySlot(p)}
                >
                  {p.label}
                </a>
              );
            })}
          </div>
        </div>
        <Button
          className="fb-reset"
          text="重置"
          leftIcon={<IconPlusIcPublicResetting iconSize="0.875rem" iconColor={['currentcolor']} />}
          onClick={onReset}
        />
      </div>
      {amountInvalid && (
        <div className="fb-applied">
          <span className="fb-amount-warn">
            金额区间无效：最大金额需不小于最小金额，当前已忽略金额筛选
          </span>
        </div>
      )}
      {exception && (
        <div className="fb-applied">
          <span className="fb-applied-chip">
            {isTimeoutException ? <IconPlusIcPublicAlarmClock iconSize="0.875rem" iconColor={['currentcolor']} /> : <IconPlusIcIctActionResourcePackage iconSize="0.875rem" iconColor={['currentcolor']} />}
            已应用筛选：
            {isTimeoutException
              ? `超时未发货 · ${exceptionCount} 单`
              : `物流异常 · ${exceptionCount} 单`}
            <IconPlusIcPublicClose iconSize="0.75rem" iconColor={['currentcolor']} className="fb-chip-close" />
          </span>
        </div>
      )}
    </div>
  );
}
