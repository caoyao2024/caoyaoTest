import { Icon } from "./assets/shared/icons.js";
import ChangeFlow from "./components/ChangeFlow/index.jsx";
import "./demo.css";

// Leaf 扩容网络变更示例数据
const leafSteps = [
  { title: "查询设备信息", action: "查询设备信息", params: ["Str.serverIp", "Str.serverIp", "Str.mask", "Str.gateway"], commandLine: "display device information", no: 1 },
  { title: "创建 VLAN 200", action: "创建VLAN信息", params: ["Str.asnNum"], commandLine: "vlan 200", no: 2 },
  { title: "创建 Eth-Trunk200 聚合链路", action: "创建聚合链路", params: ["Str.M-lag-id 89"], commandLine: "interface eth-trunk 200", actionAbnormal: true, no: 3 },
  {
    type: "branch",
    condition: "是否是V2版本",
    action: "判断设备版本",
    params: ["Str.deviceVersion"],
    commandLine: "display version",
    no: 4,
    branches: [
      { label: "是", step: { title: "配置BGP邻居（V2版本）", action: "配置BGP邻居", params: ["Str.peerIp", "Str.asNum"], commandLine: "neighbor Str.peerIp as Str.asNum", no: "5.1" } },
      { label: "否", step: { title: "配置BGP邻居（V3版本）", action: "配置BGP邻居", params: ["Str.peerIp", "Str.asNum"], commandLine: "neighbor Str.peerIp as Str.asNum version 3", no: "5.2" } },
    ],
  },
  { title: "成员端口加入聚合", action: "配置成员端口", params: ["Str.vpnInstanceName"], commandLine: "eth-trunk 200\ntrunkport interface 10GE 1/0/1", no: 6 },
  { title: "MPP区Spine配置及验证", action: "MPP区Spine配置及验证", params: ["Str.vpnInstanceName"], commandLine: "display mpp spine status", no: 7 },
  { title: "扩容POD设备SDN控制", action: "扩容POD设备SDN控制", params: ["Str.gatewayConnIp"], commandLine: "sdn pod-expand --gateway Str.gatewayConnIp", no: 8 },
];

// 自定义示例数据
const rolloutSteps = [
  { title: "镜像同步", action: "同步镜像", params: ["Str.imageTag", "Str.registry"], commandLine: "docker pull registry/Str.imageTag" },
  { title: "灰度发布", action: "调整流量权重", params: ["Int.weight 10"], commandLine: "traffic-weight set 10" },
  { title: "健康检查", action: "探测探活", params: ["Str.healthEndpoint"], commandLine: "curl -f http://Str.healthEndpoint" },
  { title: "全量发布", action: "提升权重至 100", params: ["Int.weight 100"], commandLine: "traffic-weight set 100" },
];

// 无标签形态示例数据（仅步骤名称）
const simpleSteps = [
  { title: "开始变更", no: 1 },
  { title: "等待审批", no: 2 },
  { title: "执行变更", no: 3 },
  { title: "变更完成", no: 4 },
];

export default function Demo() {
  return (
    <div className="demo-page">
      <header className="demo-header">
        <h1 className="demo-title">组件预览</h1>
        <p className="demo-subtitle">罗列当前组件的多种形态。</p>
      </header>

      <section className="demo-section">
        <div className="demo-section-header">
          <h2 className="demo-section-name">ChangeFlow</h2>
          <span className="demo-section-tag">
            <Icon name="network" size={12} />
            数据展示
          </span>
        </div>
        <p className="demo-section-desc">
          配置变更流程组件。纵向流程图展示各步骤的动作与参数；加载中统一蓝色圆环，支持悬浮加粗与点击选中（蓝色边框）。
        </p>

        <div className="demo-stack">
          <div className="demo-item">
            <h3 className="demo-item-title">默认形态（自动播放加载动画）</h3>
            <ChangeFlow
              title="20260623-Leaf扩容网络变更-配置详情 V1.0"
              steps={leafSteps}
              loadingMs={3000}
            />
            <p className="demo-note">autoPlay 默认开启：卡片依次淡入，三阶段加载——①仅有标题 ②加载动作标签 ③加载参数标签；点击卡片右侧滑出节点详情侧边栏，悬浮时边框加粗。</p>
          </div>

          <div className="demo-item">
            <h3 className="demo-item-title">选中形态（加载动画 + 选中态）</h3>
            <ChangeFlow
              title="20260623-Leaf扩容网络变更-配置详情 V1.0"
              steps={leafSteps}
              loadingMs={3000}
              selectedIndex={1}
            />
            <p className="demo-note">加载动画播放的同时通过 selectedIndex 预选第 2 张卡片，展示蓝色选中边框。</p>
          </div>

          <div className="demo-item">
            <h3 className="demo-item-title">自定义数据（自定义标题与动作）</h3>
            <ChangeFlow
              title="20260701-应用灰度发布-变更详情 V2.1"
              steps={rolloutSteps}
              loadingMs={3000}
            />
            <p className="demo-note">传入自定义 steps 与 title，动作图标与参数字段可灵活配置。</p>
          </div>

          <div className="demo-item">
            <h3 className="demo-item-title">无标签形态（仅步骤名称）</h3>
            <ChangeFlow
              title="20260801-网络维护-变更流程 V1.0"
              steps={simpleSteps}
              loadingMs={3000}
            />
            <p className="demo-note">步骤无 action/params 时，卡片仅显示标题，高度自适应收缩。</p>
          </div>

          <div className="demo-item">
            <h3 className="demo-item-title">仅动作标签形态（二阶加载）</h3>
            <ChangeFlow
              title="20260623-Leaf扩容网络变更-配置详情 V1.0"
              steps={leafSteps}
              loadingMs={3000}
              showAction={true}
              showParams={false}
            />
            <p className="demo-note">showAction=true、showParams=false：卡片仅加载动作标签，不显示参数标签。</p>
          </div>

          <div className="demo-item">
            <h3 className="demo-item-title">白色主题（light）</h3>
            <ChangeFlow
              title="20260623-Leaf扩容网络变更-配置详情 V1.0"
              steps={leafSteps}
              loadingMs={3000}
              theme="light"
            />
            <p className="demo-note">theme="light"：白色背景版本，配色与交互完全一致，适合浅色界面场景。</p>
          </div>
        </div>
      </section>
    </div>
  );
}
