// Layer 4: 顶部导航栏 — 品牌 / 主主导航（原生 nav）/ 全局工具
// 顶部导航不使用 antd Menu（见 references/component/Menu.md）：选中项品牌色文字 + 2px 下划线。
import { useState } from "react";
import { Input, Badge, Tooltip } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import { useApp } from "../../context.jsx";
import { topNavItems } from "../../mock/order.js";
import "./index.css";

export default function TopBar({ collapsed, onToggleCollapsed }) {
  const { isDark, toggleDark } = useApp();
  const [activeNav, setActiveNav] = useState("order");
  const [keyword, setKeyword] = useState("");

  return (
    <header className="topbar">
      <div className="topbar-brand">
        <span className="topbar-logo">
          <Icon name="radio-tower" size="1rem" />
        </span>
        <span className="topbar-title">运营商业务受理平台</span>
        <span className="topbar-ver">V3.2</span>
      </div>

      <button
        type="button"
        className="topbar-collapse"
        onClick={onToggleCollapsed}
        aria-label={collapsed ? "展开导航" : "收起导航"}
      >
        <Icon name={collapsed ? "panel-left-open" : "panel-left-close"} size="1rem" />
      </button>

      <nav className="topbar-nav">
        {topNavItems.map((item) => (
          <button
            type="button"
            key={item.key}
            className={`topbar-nav-item${activeNav === item.key ? " active" : ""}`}
            onClick={() => setActiveNav(item.key)}
          >
            <Icon name={item.icon} size="0.875rem" />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <span className="topbar-spacer" />

      <div className="topbar-tools">
        <Input
          className="topbar-search"
          size="small"
          allowClear
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          onPressEnter={() => {}}
          placeholder="搜索工单号 / 客户 / 号码"
          suffix={<Icon name="search" size="0.875rem" />}
        />

        <Tooltip title="待办工单">
          <button type="button" className="topbar-icon-btn" aria-label="待办工单">
            <Badge count={12} size="small" offset={[2, -2]}>
              <Icon name="bell" size="1rem" />
            </Badge>
          </button>
        </Tooltip>

        <Tooltip title={isDark ? "切换浅色模式" : "切换深色模式"}>
          <button type="button" className="topbar-icon-btn" onClick={toggleDark} aria-label="切换主题">
            <Icon name={isDark ? "sun" : "moon"} size="1rem" />
          </button>
        </Tooltip>

        <div className="topbar-user">
          <img src="./assets/uploads/user.png" alt="当前用户" />
          <div className="topbar-user-meta">
            <span className="topbar-user-name">周晓东</span>
            <span className="topbar-user-role">受理专员 · 华南大区</span>
          </div>
          <Icon name="chevron-down" size="0.75rem" className="topbar-user-caret" />
        </div>
      </div>
    </header>
  );
}
