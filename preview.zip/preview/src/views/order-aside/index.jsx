// Layer 4: 受理侧栏 — 进度 / 资费预估 / 办理须知 / 最近工单
import { Progress } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import StatusTag from "../../components/status-tag/index.jsx";
import { orderNotices, recentOrders, stepItems } from "../../mock/order.js";
import "./index.css";

export default function OrderAside({ current, data, fee }) {
  const money = (n) => `¥${Number(n || 0).toFixed(2)}`;
  const percent = Math.round(((current + 1) / stepItems.length) * 100);

  return (
    <aside className="order-aside">
      <section className="aside-card">
        <div className="aside-card-head">
          <span className="aside-card-title">
            <Icon name="activity" size="1rem" />
            办理进度
          </span>
          <span className="aside-progress-num">{percent}%</span>
        </div>
        <Progress percent={percent} showInfo={false} />
        <ul className="progress-steps">
          {stepItems.map((s, i) => (
            <li
              key={s.title}
              className={`progress-step${i < current ? " done" : ""}${i === current ? " active" : ""}`}
            >
              <span className="progress-step-dot">
                {i < current ? <Icon name="check" size="0.625rem" /> : i + 1}
              </span>
              <span className="progress-step-text">{s.title}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="aside-card">
        <div className="aside-card-head">
          <span className="aside-card-title">
            <Icon name="wallet" size="1rem" />
            资费预估
          </span>
        </div>
        <div className="aside-fee">
          <div className="aside-fee-main">
            <span className="aside-fee-num">{money(fee.monthly)}</span>
            <span className="aside-fee-unit">/ 月</span>
          </div>
          <div className="aside-fee-rows">
            <div className="aside-fee-row">
              <span>首月应付</span>
              <b>{money(fee.firstMonth)}</b>
            </div>
            <div className="aside-fee-row">
              <span>增值服务</span>
              <b>{money(fee.addonSum)}</b>
            </div>
            <div className="aside-fee-row">
              <span>安装调测费</span>
              <b>{money(fee.installFee)}</b>
            </div>
          </div>
        </div>
      </section>

      <section className="aside-card">
        <div className="aside-card-head">
          <span className="aside-card-title">
            <Icon name="lightbulb" size="1rem" />
            办理须知
          </span>
        </div>
        <ul className="notice-list">
          {orderNotices.map((n) => (
            <li className="notice-item" key={n.text}>
              <Icon name={n.icon} size="0.875rem" className="notice-icon" />
              <span>{n.text}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="aside-card">
        <div className="aside-card-head">
          <span className="aside-card-title">
            <Icon name="clipboard-list" size="1rem" />
            最近受理工单
          </span>
          <a className="aside-more">全部</a>
        </div>
        <ul className="recent-list">
          {recentOrders.map((o) => (
            <li className="recent-item" key={o.id}>
              <div className="recent-top">
                <span className="recent-customer">{o.customer}</span>
                <StatusTag status={o.status} showIcon={false} />
              </div>
              <div className="recent-product">{o.product}</div>
              <div className="recent-meta">
                <span className="recent-id">{o.id}</span>
                <span className="recent-time">{o.time}</span>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </aside>
  );
}
