// Layer 4: 步骤四 — 费用确认（资费明细 / 支付方式 / 发票 / 优惠）
import { Input, Radio } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import FormField from "../../components/form-field/index.jsx";
import { payMethods, invoiceTypes } from "../../mock/order.js";
import "./index.css";

export default function StepFee({ data, setField, errors, fee }) {
  const money = (n) => `¥${Number(n || 0).toFixed(2)}`;

  return (
    <div className="step-fee">
      <div className="step-intro">
        <span className="step-intro-icon">
          <Icon name="wallet" size="1.25rem" />
        </span>
        <div>
          <h2 className="step-intro-title">费用确认</h2>
          <p className="step-intro-desc">核对资费明细与首月应付金额，选择支付方式与发票类型。</p>
        </div>
      </div>

      <div className="fee-panel">
        <div className="fee-panel-head">
          <span className="fee-panel-title">
            <Icon name="receipt" size="1rem" />
            资费明细
          </span>
          <span className="fee-panel-sub">价格含税 · 以实际出账为准</span>
        </div>

        <div className="fee-list">
          <div className="fee-row">
            <span className="fee-label">
              主套餐月费
              {fee.plan ? <em className="fee-note">（{fee.plan.name}）</em> : null}
            </span>
            <span className="fee-value">{money(fee.base)}</span>
          </div>

          {fee.addonList.map((a) => (
            <div className="fee-row" key={a.id}>
              <span className="fee-label fee-sub">
                <Icon name="plus" size="0.75rem" />
                {a.name}
              </span>
              <span className="fee-value">{money(a.price)}</span>
            </div>
          ))}

          {fee.subCardFee > 0 ? (
            <div className="fee-row">
              <span className="fee-label">
                副卡费用
                <em className="fee-note">（{data.subCards} 张 × ¥10）</em>
              </span>
              <span className="fee-value">{money(fee.subCardFee)}</span>
            </div>
          ) : null}

          <div className="fee-row fee-row-total">
            <span className="fee-label">月度费用小计</span>
            <span className="fee-value">{money(fee.monthly)} / 月</span>
          </div>

          <div className="fee-row">
            <span className="fee-label">一次性安装调测费</span>
            <span className="fee-value">{money(fee.installFee)}</span>
          </div>

          <div className="fee-row">
            <span className="fee-label">
              其中增值税
              <em className="fee-note">（税率 6%）</em>
            </span>
            <span className="fee-value fee-value-muted">{money(fee.tax)}</span>
          </div>

          <div className="fee-row fee-row-final">
            <span className="fee-label">首月应付合计</span>
            <span className="fee-value fee-value-strong">{money(fee.firstMonth)}</span>
          </div>
        </div>

        {fee.save > 0 ? (
          <div className="fee-save">
            <Icon name="gift" size="0.875rem" />
            本单套餐优惠 {money(fee.save)}/月，合约期内累计可省 {money(fee.save * 24)}
          </div>
        ) : null}
      </div>

      <div className="form-block">
        <FormField label="支付方式" required error={errors.payMethod}>
          <Radio.Group
            className="pay-cards"
            value={data.payMethod}
            onChange={(e) => setField("payMethod", e.target.value)}
          >
            {payMethods.map((p) => (
              <label key={p.value} className={`pay-card${data.payMethod === p.value ? " selected" : ""}`}>
                <Radio value={p.value}>{p.label}</Radio>
              </label>
            ))}
          </Radio.Group>
        </FormField>
      </div>

      <div className="form-block">
        <div className="form-grid">
          <FormField label="发票类型" htmlFor="f-invoice">
            <Radio.Group
              id="f-invoice"
              value={data.invoiceType}
              onChange={(e) => setField("invoiceType", e.target.value)}
            >
              {invoiceTypes.map((t) => (
                <Radio key={t.value} value={t.value}>
                  {t.label}
                </Radio>
              ))}
            </Radio.Group>
          </FormField>

          <FormField label="优惠码" hint="如有活动优惠码可在此核销" htmlFor="f-coupon">
            <Input
              id="f-coupon"
              value={data.coupon}
              onChange={(e) => setField("coupon", e.target.value)}
              placeholder="请输入优惠码（选填）"
              suffix={
                <a className="coupon-apply" onClick={() => {}}>
                  核销
                </a>
              }
            />
          </FormField>
        </div>
      </div>
    </div>
  );
}
