// Layer 4: 步骤三 — 安装信息（装机地址 / 预约时间 / 接入方式与设备）
import { Input, Select, Radio, DatePicker } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import FormField from "../../components/form-field/index.jsx";
import {
  accessTypes,
  opticalModems,
  installModes,
} from "../../mock/order.js";
import "./index.css";

function disabledDate(current) {
  return current && current.valueOf() < Date.now() - 24 * 60 * 60 * 1000;
}

export default function StepInstall({ data, setField, errors }) {
  const status = (k) => (errors[k] ? "error" : undefined);

  return (
    <div className="step-install">
      <div className="step-intro">
        <span className="step-intro-icon">
          <Icon name="map-pin" size="1.25rem" />
        </span>
        <div>
          <h2 className="step-intro-title">安装信息</h2>
          <p className="step-intro-desc">填写实际装机地址并预约上门时间，系统将自动核验光纤覆盖情况。</p>
        </div>
      </div>

      <div className="form-block">
        <div className="form-block-title">
          <span className="form-block-bar" />
          装机地址
        </div>
        <FormField
          label="详细装机地址"
          required
          error={errors.installAddress}
          hint="格式：省 / 市 / 区 / 街道 / 门牌号"
          htmlFor="f-install-addr"
        >
          <Input
            id="f-install-addr"
            status={status("installAddress")}
            value={data.installAddress}
            onChange={(e) => setField("installAddress", e.target.value)}
            placeholder="请输入详细装机地址，例如：广东省深圳市南山区科技园路 1 号 3 栋 502"
          />
        </FormField>
      </div>

      <div className="form-block">
        <div className="form-block-title">
          <span className="form-block-bar" />
          预约与接入
        </div>
        <div className="form-grid">
          <FormField label="预约上门时间" required error={errors.installTime} htmlFor="f-install-time">
            <DatePicker
              id="f-install-time"
              showTime={{ format: "HH:mm" }}
              format="YYYY-MM-DD HH:mm"
              style={{ width: "100%" }}
              value={data.installTime}
              disabledDate={disabledDate}
              placeholder="请选择日期与时间"
              onChange={(v) => setField("installTime", v)}
            />
          </FormField>

          <FormField label="接入方式" htmlFor="f-access">
            <Select
              id="f-access"
              style={{ width: "100%" }}
              value={data.accessType}
              onChange={(v) => setField("accessType", v)}
              options={accessTypes}
            />
          </FormField>

          <FormField label="光猫设备" htmlFor="f-modem">
            <Select
              id="f-modem"
              style={{ width: "100%" }}
              value={data.opticalModem}
              onChange={(v) => setField("opticalModem", v)}
              options={opticalModems}
            />
          </FormField>

          <FormField label="安装方式" htmlFor="f-install-mode">
            <Radio.Group
              id="f-install-mode"
              value={data.installMode}
              onChange={(e) => setField("installMode", e.target.value)}
            >
              {installModes.map((m) => (
                <Radio key={m.value} value={m.value}>
                  {m.label}
                </Radio>
              ))}
            </Radio.Group>
          </FormField>
        </div>
      </div>

      <div className="install-tip">
        <Icon name="lightbulb" size="1rem" />
        <span>提示：如所在楼宇暂未覆盖光纤，提交后系统会推荐就近的无线接入方案。</span>
      </div>
    </div>
  );
}
