// Layer 4: 侧边导航栏 — antd Menu（分组多级），支持展开/收起
import { useMemo, useState } from "react";
import { Menu } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import { sideMenuItems } from "../../mock/order.js";
import "./index.css";

// 仅一级菜单带图标，二级菜单不带图标
function toMenuItems(list, depth = 0) {
  return list.map((it) => ({
    key: it.key,
    icon: depth === 0 ? <Icon name={it.icon} size="1rem" /> : undefined,
    label: it.label,
    children: it.children ? toMenuItems(it.children, depth + 1) : undefined,
  }));
}

export default function SideNav({ collapsed }) {
  const items = useMemo(() => toMenuItems(sideMenuItems), []);
  const [selectedKeys, setSelectedKeys] = useState(["order-create"]);
  const [openKeys, setOpenKeys] = useState(["grp-order", "grp-ticket"]);

  const collapseProps = collapsed
    ? { inlineCollapsed: true }
    : { inlineCollapsed: false, openKeys, onOpenChange: setOpenKeys };

  return (
    <aside className={`side-nav${collapsed ? " collapsed" : ""}`}>
      <Menu
        mode="inline"
        items={items}
        selectedKeys={selectedKeys}
        onClick={({ key }) => setSelectedKeys([key])}
        style={{ borderInlineEnd: "none", background: "transparent" }}
        {...collapseProps}
      />
    </aside>
  );
}
