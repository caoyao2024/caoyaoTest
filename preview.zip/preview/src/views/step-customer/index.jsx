// Layer 4: 步骤一 — 客户资料（实名信息 / 联系方式）
import { Input, Select, Radio } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import FormField from "../../components/form-field/index.jsx";
import { certTypes } from "../../mock/order.js";
import "./index.css";

export default function StepCustomer({ data, setField, errors }) {
  const status = (k) => (errors[k] ? "error" : undefined);

  return (
    <div className="step-customer">
      <div className="step-intro">
        <span className="step-intro-icon">
          <Icon name="id-card" size="1.25rem" />
        </span>
        <div>
          <h2 className="step-intro-title">客户资料</h2>
          <p className="step-intro-desc">请按证件原件如实填写实名信息，用于入网登记与合同签署。</p>
        </div>
      </div>

      <div className="form-block">
        <div className="form-block-title">
          <span className="form-block-bar" />
          客户类型
        </div>
        <Radio.Group
          value={data.customerType}
          onChange={(e) => setField("customerType", e.target.value)}
        >
          <Radio value="personal">个人客户</Radio>
          <Radio value="enterprise">政企客户</Radio>
        </Radio.Group>
      </div>

      <div className="form-block">
        <div className="form-block-title">
          <span className="form-block-bar" />
          实名信息
        </div>
        <div className="form-grid">
          {data.customerType === "enterprise" ? (
            <>
              <FormField label="单位名称" required error={errors.enterpriseName} htmlFor="f-enterprise">
                <Input
                  id="f-enterprise"
                  status={status("enterpriseName")}
                  value={data.enterpriseName}
                  onChange={(e) => setField("enterpriseName", e.target.value)}
                  placeholder="请输入营业执照上的单位全称"
                />
              </FormField>
              <FormField label="联系人" htmlFor="f-contact">
                <Input
                  id="f-contact"
                  value={data.contactPerson}
                  onChange={(e) => setField("contactPerson", e.target.value)}
                  placeholder="请输入经办人姓名"
                />
              </FormField>
            </>
          ) : null}

          <FormField
            label={data.customerType === "enterprise" ? "经办人姓名" : "客户姓名"}
            required
            error={errors.customerName}
            htmlFor="f-name"
          >
            <Input
              id="f-name"
              status={status("customerName")}
              value={data.customerName}
              onChange={(e) => setField("customerName", e.target.value)}
              placeholder="请输入客户真实姓名"
            />
          </FormField>

          <FormField label="证件类型" required htmlFor="f-cert-type">
            <Select
              id="f-cert-type"
              style={{ width: "100%" }}
              value={data.certType}
              onChange={(v) => setField("certType", v)}
              options={certTypes}
            />
          </FormField>

          <FormField label="证件号码" required error={errors.certNo} htmlFor="f-cert-no">
            <Input
              id="f-cert-no"
              status={status("certNo")}
              value={data.certNo}
              onChange={(e) => setField("certNo", e.target.value)}
              placeholder="请输入证件号码"
            />
          </FormField>

          <FormField label="联系电话" required error={errors.phone} htmlFor="f-phone">
            <Input
              id="f-phone"
              status={status("phone")}
              value={data.phone}
              onChange={(e) => setField("phone", e.target.value)}
              placeholder="请输入 11 位手机号码"
              maxLength={11}
            />
          </FormField>

          <FormField label="电子邮箱" error={errors.email} hint="用于接收电子发票与业务通知" htmlFor="f-email">
            <Input
              id="f-email"
              status={status("email")}
              value={data.email}
              onChange={(e) => setField("email", e.target.value)}
              placeholder="请输入常用邮箱"
            />
          </FormField>
        </div>
      </div>

      <div className="form-block">
        <div className="form-block-title">
          <span className="form-block-bar" />
          联系地址
        </div>
        <FormField label="客户通信地址" htmlFor="f-address">
          <Input
            id="f-address"
            value={data.address}
            onChange={(e) => setField("address", e.target.value)}
            placeholder="请输入客户日常通信地址（选填，可与装机地址不同）"
          />
        </FormField>
      </div>
    </div>
  );
}
