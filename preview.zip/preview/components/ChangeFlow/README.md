# ChangeFlow

配置变更流程组件：以「开始 → 步骤卡片 → 结束」的纵向流程图，展示网络/配置变更各步骤的执行动作与参数，并带加载动画。

## Features

- 纵向流程图：终端节点（开始/结束）+ 步骤卡片 + 箭头连线
- 步骤卡片展示：标题、执行动作、参数字段（可多个）；参数过多时自动折叠为 "+N"，点击展开剩余标签浮窗
- 自动播放加载动画：卡片依次淡入，加载中显示线性渐变边框 + 蓝色旋转圆环，完成后揭示卡片内容
- 点击卡片：选中显示蓝色边框，同时右侧滑出节点详情侧边栏（节点名称 / 匹配动作 / 匹配参数 / 关联参数命令行）
- 顶部导航栏：图标 + 标题 + 操作按钮
- 视图缩放：顶部 +/− 控件对流程图进行缩放（50%–150%，步进 10%）
- 深色运维控制台风格，开箱即用

## Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `title` | `string` | `"网络变更-配置详情"` | 顶部标题 |
| `steps` | `Array<Step>` | — (required) | 步骤数据 |
| `autoPlay` | `boolean` | `true` | 是否自动播放加载动画；`false` 时直接展示已加载完成的静态形态 |
| `loadingMs` | `number` | `1500` | 每张卡片加载所需毫秒数（顺序出现，加载完成后进入下一张） |
| `startLabel` / `endLabel` | `string` | `"开始"` / `"结束"` | 首尾终端节点文案 |
| `headerIcon` | `string` | `"clipboard-list"` | 顶部图标（Lucide 图标名） |
| `actions` | `Array<{ label, icon }>` | 内置三项 | 顶部右侧操作按钮 |
| `selectedIndex` | `number` | `null` | 受控选中项索引；不传则组件内部维护选中态 |
| `onSelect` | `(index) => void` | — | 点击卡片选中时的回调 |

### Step

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `no` | `number` | — | 步骤序号（显示在标题前，如 `1.`）；不传则不显示序号 |
| `title` | `string` | — (required) | 步骤标题 |
| `action` | `string` | — (required) | 执行动作文案 |
| `params` | `string[]` | `[]` | 参数字段（可多个，超出卡片宽度自动折叠为 `+N`，点击展开浮窗） |
| `commandLine` | `string` | — | 关联命令行（详情侧边栏展示） |
| `actionAbnormal` | `boolean` | `false` | 动作标签是否异常（匹配到多个重复动作包）；异常时显示警告图标 + 红色着色，hover 提示"匹配到多个重复动作包，请人工确认选择" |
| `actionIcon` | `string` | `"circle-dot"` | 动作图标（Lucide 图标名，节点图标） |

### Branch（条件分支节点）

steps 数组中可插入 `type: "branch"` 的分支节点，在两条路径间做条件分流：

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `type` | `"branch"` | — (required) | 节点类型，固定为 `"branch"` |
| `condition` | `string` | — (required) | 判断条件文案（如"是否是V2版本"） |
| `branches` | `Array<{ label, step }>` | — (required) | 分支列表；`label` 为"是/否"等分支标签，`step` 为该分支的 Step 数据 |

## Usage

```jsx
import ChangeFlow from "./ChangeFlow/index.jsx";

const steps = [
  { title: "查询设备信息", action: "查询设备信息", params: ["Str.serverIp"], commandLine: "display device information" },
  { title: "创建 VLAN 200", action: "创建VLAN信息", params: ["Str.asnNum"], commandLine: "vlan 200" },
  { title: "创建 Eth-Trunk200 聚合链路", action: "创建聚合链路", params: ["Str.M-lag-id 89"], commandLine: "interface eth-trunk 200" },
];

<ChangeFlow title="20260623-Leaf扩容网络变更-配置详情 V1.0" steps={steps} />
```
