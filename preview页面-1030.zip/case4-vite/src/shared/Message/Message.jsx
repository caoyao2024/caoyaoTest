import { useState } from "react";
import { createPortal } from "react-dom";
import DivMessage from "@nce/eview-react/DivMessage";

let _setNotice = null;

function notify(type, text) {
  if (_setNotice) _setNotice({ type, text, key: Date.now() });
}

export const message = {
  success: (text) => notify("success", text),
  error: (text) => notify("error", text),
  info: (text) => notify("default", text),
  warning: (text) => notify("warn", text),
};

export function MessageContainer() {
  const [notice, setNotice] = useState(null);
  _setNotice = setNotice;

  if (!notice) return null;

  return createPortal(
    <div
      style={{
        position: "fixed",
        top: 16,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 1050,
      }}
    >
      <DivMessage
        key={notice.key}
        display
        type={notice.type}
        text={notice.text}
        enableDisposeTimeOut
        onClose={() => setNotice(null)}
      />
    </div>,
    document.body
  );
}
