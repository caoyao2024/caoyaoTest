import "./Progress.css";

export default function Progress({ percent = 0, size = "default", strokeColor }) {
  const p = Math.min(100, Math.max(0, percent));
  const color = strokeColor || "var(--primary)";
  return (
    <div className={`app-progress app-progress-${size}`}>
      <div className="app-progress-track">
        <div
          className="app-progress-fill"
          style={{ width: `${p}%`, background: color }}
        />
      </div>
      <span className="app-progress-text">{p}%</span>
    </div>
  );
}
