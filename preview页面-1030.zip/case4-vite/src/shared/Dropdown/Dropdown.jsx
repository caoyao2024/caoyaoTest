import { useState, useRef, useEffect } from "react";
import "./Dropdown.css";

export default function Dropdown({ menu, trigger = ["click"], placement = "bottomLeft", children }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  const handleTriggerClick = (e) => {
    e.stopPropagation();
    setOpen((o) => !o);
  };

  const handleItemClick = (item) => {
    if (item.type === "divider") return;
    setOpen(false);
    if (menu.onClick) menu.onClick({ key: item.key });
  };

  const alignClass = placement.includes("Right") ? "app-dropdown-menu-right" : "app-dropdown-menu-left";

  return (
    <span className="app-dropdown" ref={ref}>
      <span className="app-dropdown-trigger" onClick={handleTriggerClick}>
        {children}
      </span>
      {open && (
        <div className={`app-dropdown-menu ${alignClass}`}>
          {(menu.items || []).map((item, idx) =>
            item.type === "divider" ? (
              <div key={`divider-${idx}`} className="app-dropdown-divider" />
            ) : (
              <div
                key={item.key || idx}
                className={`app-dropdown-item ${
                  menu.selectedKeys && menu.selectedKeys.includes(item.key)
                    ? "app-dropdown-item-selected"
                    : ""
                }`}
                onClick={() => handleItemClick(item)}
              >
                {item.icon}
                {item.label}
              </div>
            )
          )}
        </div>
      )}
    </span>
  );
}
