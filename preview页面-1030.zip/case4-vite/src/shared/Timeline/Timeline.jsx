import "./Timeline.css";

export default function Timeline({ items = [], className }) {
  return (
    <div className={`app-timeline ${className || ""}`}>
      {items.map((item, idx) => (
        <div key={item.key || idx} className="app-timeline-item">
          <div className="app-timeline-dot-wrap">
            <span className={`app-timeline-dot app-timeline-dot-${item.color || "gray"}`} />
            {idx < items.length - 1 && <span className="app-timeline-line" />}
          </div>
          <div className="app-timeline-content">{item.children}</div>
        </div>
      ))}
    </div>
  );
}
