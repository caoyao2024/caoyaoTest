import React, { useState } from 'react';
import { initialState } from '../state';

import '../styles/HeaderNavigation.less';

import { IconPlusIcPublicTransverseRectangleTemplate } from '@nce/icon-plus';

const systemName = initialState.systemName;
const userName = initialState.userName;


export const HeaderNavigation = () => {


  return (
    <div id="headerShellContainer" className="headerShellContainer_style">
      <div id="hdrLeftSection" className="hdrLeftSection_style">
        <IconPlusIcPublicTransverseRectangleTemplate id="hdrHamburgerIcon" className="hdrHamburgerIcon_style" type="lined" />
        <IconPlusIcPublicTransverseRectangleTemplate id="hdrLogoImg" className="hdrLogoImg_style" iconColor="primary" type="lined" />
        <span id="hdrSystemName" className="hdrSystemName_style">{systemName}</span>
      </div>
      <div id="hdrRightSection" className="hdrRightSection_style">
        <IconPlusIcPublicTransverseRectangleTemplate id="hdrHelpIcon" className="hdrHelpIcon_style" type="lined" />
        <IconPlusIcPublicTransverseRectangleTemplate id="hdrLangIcon" className="hdrLangIcon_style" type="lined" />
        <IconPlusIcPublicTransverseRectangleTemplate id="hdrSunIcon" className="hdrSunIcon_style" type="lined" />
        <div id="hdrUserSection" className="hdrUserSection_style">
          <IconPlusIcPublicTransverseRectangleTemplate id="hdrUserIcon" className="hdrUserIcon_style" type="lined" />
          <span id="hdrUserName" className="hdrUserName_style">{userName}</span>
        </div>
      </div>
    </div>
  );
};

export default HeaderNavigation;