import React, { useState } from 'react';
import { initialState } from '../state';

import '../styles/MainCard.less';

import Tab, { TabItem } from '@nce/eview-react/Tab';
import TextField from '@nce/eview-react/TextField';
import { IconPlusIcPublicTransverseRectangleTemplate } from '@nce/icon-plus';
import Button from '@nce/eview-react/Button';
import Tag from '@nce/eview-react/Tag';
import Switch from '@nce/eview-react/Switch';

const listItems = initialState.listItems;
const secondaryTabs = initialState.secondaryTabs;


export const MainCard = () => {
  const [mCnPrimaryNavSelectedIndex, setMCnPrimaryNavSelectedIndex] = useState(initialState.mCnPrimaryNavSelectedIndex);
  const [mCnSecondaryNavSelectedIndex, setMCnSecondaryNavSelectedIndex] = useState(initialState.mCnSecondaryNavSelectedIndex);


  return (
    <div id="mainShellContainer" className="mainShellContainer_style">
      <div id="mCnCardContent" className="mCnCardContent_style">
        <span id="mCnTitle" className="mCnTitle_style">策略中心</span>
        <Tab id="mCnPrimaryNav" className="mCnPrimaryNav_style" size="medium" type="main" selectedIndex={mCnPrimaryNavSelectedIndex} onClick={(index) => setMCnPrimaryNavSelectedIndex(index)}>
          <TabItem id="mnC_primaryTab1" className="mnC_primaryTab1_style" title="故障思维链"></TabItem>
          <TabItem id="mnC_primaryTab2" className="mnC_primaryTab2_style" title="XXX思维链"></TabItem>
          <TabItem id="mnC_primaryTab3" className="mnC_primaryTab3_style" title="自定义思维链"></TabItem>
        </Tab>
        <Tab id="mCnSecondaryNav" className="mCnSecondaryNav_style" size="small" type="sub" selectedIndex={mCnSecondaryNavSelectedIndex} onClick={(index) => setMCnSecondaryNavSelectedIndex(index)}>
          {(secondaryTabs || []).map((item, idx) => (
            <TabItem id="mCnSecondaryTabItem" className="mCnSecondaryTabItem_style" title={item.label}></TabItem>
          ))}
        </Tab>
        <div id="mCnToolbar" className="mCnToolbar_style">
          <div id="mCnToolbarLeft" className="mCnToolbarLeft_style"><TextField id="mCnSearchInput" className="mCnSearchInput_style" prefix={<IconPlusIcPublicTransverseRectangleTemplate  />} placeholder="Search" /></div>
          <div id="mCnToolbarRight" className="mCnToolbarRight_style">
            <Button id="mCnDeleteBtn" className="mCnDeleteBtn_style" text="删除" onClick={(e) => {}} />
            <Button id="mCnDisableBtn" className="mCnDisableBtn_style" text="禁用" onClick={(e) => {}} />
            <Button id="mCnCreateBtn" className="mCnCreateBtn_style" text="创建" status="primary" onClick={(e) => {}} />
          </div>
        </div>
        <div id="mCnList" className="mCnList_style">
          {(listItems || []).map((item, idx) => (
            <div id="mCnListItem" className="mCnListItem_style">
              <div id="mCnListItemCol1" className="mCnListItemCol1_style">
                <div id="mCnListItemCol1ImgCon" className="mCnListItemCol1ImgCon_style"><IconPlusIcPublicTransverseRectangleTemplate id="mCnListItemCol1Img" className="mCnListItemCol1Img_style" iconColor="primary" type="lined" /></div>
                <div id="mCnListItemCol1Text" className="mCnListItemCol1Text_style">
                  <span id="mCnListItemCol1Top" className="mCnListItemCol1Top_style">{item.col1Top}</span>
                  <span id="mCnListItemCol1Bottom" className="mCnListItemCol1Bottom_style">{item.col1Bottom}</span>
                </div>
              </div>
              <div id="mCnListItemCol2" className="mCnListItemCol2_style">
                <span id="mCnListItemCol2Top" className="mCnListItemCol2Top_style">{item.col2Top}</span>
                <Tag id="mCnListItemCol2Bottom" className="mCnListItemCol2Bottom_style" color="danger">{item.col2Bottom}</Tag>
              </div>
              <div id="mCnListItemCol3" className="mCnListItemCol3_style">
                <span id="mCnListItemCol3Top" className="mCnListItemCol3Top_style">{item.col3Top}</span>
                <span id="mCnListItemCol3Bottom" className="mCnListItemCol3Bottom_style">{item.col3Bottom}</span>
              </div>
              <div id="mCnListItemCol4" className="mCnListItemCol4_style">
                <span id="mCnListItemCol4Label" className="mCnListItemCol4Label_style">状态</span>
                <div id="mCnListItemCol4StatusRow" className="mCnListItemCol4StatusRow_style">
                  <div id="mCnListItemCol4Dot" className="mCnListItemCol4Dot_style" />
                  <span id="mCnListItemCol4Text" className="mCnListItemCol4Text_style">{item.col4Text}</span>
                </div>
              </div>
              <div id="mCnListItemCol5" className="mCnListItemCol5_style">
                <span id="mCnListItemCol5Label" className="mCnListItemCol5Label_style">是否启用</span>
                <Switch id="mCnListItemCol5Switch" className="mCnListItemCol5Switch_style" />
              </div>
              <div id="mCnListItemCol6" className="mCnListItemCol6_style">
                <span id="mCnListItemCol6Top" className="mCnListItemCol6Top_style">{item.col6Top}</span>
                <span id="mCnListItemCol6Bottom" className="mCnListItemCol6Bottom_style">{item.col6Bottom}</span>
              </div>
              <div id="mCnListItemCol7" className="mCnListItemCol7_style">
                <span id="mCnListItemCol7Top" className="mCnListItemCol7Top_style">{item.col7Top}</span>
                <span id="mCnListItemCol7Bottom" className="mCnListItemCol7Bottom_style">{item.col7Bottom}</span>
              </div>
              <div id="mCnListItemCol8" className="mCnListItemCol8_style">
                <span id="mCnListItemCol8Top" className="mCnListItemCol8Top_style">{item.col8Top}</span>
                <span id="mCnListItemCol8Bottom" className="mCnListItemCol8Bottom_style">{item.col8Bottom}</span>
              </div>
              <div id="mCnListItemCol9" className="mCnListItemCol9_style">
                <span id="mCnListItemCol9Top" className="mCnListItemCol9Top_style">{item.col9Top}</span>
                <span id="mCnListItemCol9Bottom" className="mCnListItemCol9Bottom_style">{item.col9Bottom}</span>
              </div>
              <div id="mCnListItemCol10" className="mCnListItemCol10_style">
                <IconPlusIcPublicTransverseRectangleTemplate id="mCnListItemCol10IconEdit" className="mCnListItemCol10IconEdit_style" />
                <IconPlusIcPublicTransverseRectangleTemplate id="mCnListItemCol10IconCopy" className="mCnListItemCol10IconCopy_style" />
                <IconPlusIcPublicTransverseRectangleTemplate id="mCnListItemCol10IconTrash" className="mCnListItemCol10IconTrash_style" />
                <IconPlusIcPublicTransverseRectangleTemplate id="mCnListItemCol10IconMore" className="mCnListItemCol10IconMore_style" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MainCard;