import { createBrowserRouter, Navigate } from 'react-router-dom';
import App from '../App';

import Page_pageShellRootPage from '../pages/page_pageShellRoot';

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { index: true, element: <Navigate to="/page_pageShellRoot" replace /> },
      { path: '/page_pageShellRoot', element: <Page_pageShellRootPage /> },
    ],
  },
]);

export default router;