import React, { useState } from 'react';
import { initialState } from './state';

import './styles/page_pageShellRoot.less';

import HeaderNavigation from './components/HeaderNavigation';
import Sidebar from './components/Sidebar';
import MainCard from './components/MainCard';

const PagePageShellRootPage = () => {
  const [activeSecondaryTab, setActiveSecondaryTab] = useState(initialState.activeSecondaryTab);
  const [activeTabKey, setActiveTabKey] = useState(initialState.activeTabKey);
  const [searchVal, setSearchVal] = useState(initialState.searchVal);

  return (
    <div id="pageShellRoot" className="pageShellRoot_style">
      <HeaderNavigation  />
      <div id="contentShellArea" className="contentShellArea_style">
        <Sidebar  />
        <MainCard  />
      </div>
    </div>
  );
};

export default PagePageShellRootPage;