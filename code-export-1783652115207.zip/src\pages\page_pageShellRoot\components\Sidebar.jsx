import React, { useState } from 'react';
import { initialState } from '../state';

import '../styles/Sidebar.less';

import { IconPlusIcPublicTransverseRectangleTemplate } from '@nce/icon-plus';
import Accordion from '@nce/eview-react/Accordion';
import IconButton from '@nce/eview-react/IconButton';


export const Sidebar = () => {
  const [selectedValue, setSelectedValue] = useState(initialState.selectedValue);

  // 数据转换（编译期生成）
  const menuData = [
    {
      title: "首页",
      value: "home",
      icon: <IconPlusIcPublicTransverseRectangleTemplate  />
    },
    {
      title: "配置",
      value: "settings",
      icon: <IconPlusIcPublicTransverseRectangleTemplate  />
    },
    {
      title: "监控",
      value: "monitor",
      icon: <IconPlusIcPublicTransverseRectangleTemplate  />
    },
    {
      title: "日志",
      value: "logs",
      icon: <IconPlusIcPublicTransverseRectangleTemplate  />
    },
    {
      title: "管理",
      value: "product",
      icon: <IconPlusIcPublicTransverseRectangleTemplate  />
    }
  ];
  


  return (
    <div id="sideShellContainer" className="sideShellContainer_style">
      <div id="sdbLogoContainer" className="sdbLogoContainer_style"><IconPlusIcPublicTransverseRectangleTemplate id="sdbLogoImg" className="sdbLogoImg_style" iconColor="primary" type="lined" /></div>
      <div id="sdbMenuContainer" className="sdbMenuContainer_style"><Accordion id="sdbMainMenu" className="sdbMainMenu_style" data={menuData} selectedValue={selectedValue} onClick={(node) => setSelectedValue(node.value)} expanded={true} hideTitleBar={true} enableMultiOpen={true} isControlSelectedValue={true} enableExpand={true} /></div>
      <div id="sdbBottomContainer" className="sdbBottomContainer_style">
        <IconButton id="sdbHelpBtn" className="sdbHelpBtn_style" iconName={<IconPlusIcPublicTransverseRectangleTemplate  />} onClick={(e) => {}} />
        <IconButton id="sdbLogoutBtn" className="sdbLogoutBtn_style" iconName={<IconPlusIcPublicTransverseRectangleTemplate  />} onClick={(e) => {}} />
      </div>
    </div>
  );
};

export default Sidebar;