/**
 * 页面级数据源（自动生成，请勿手动修改）
 * 1:1 对应 A2UI JSON 的 state 字段
 */
export const initialState = {
  logoImage: "./pattern/logo-master.svg",
  systemName: "IMaster NCE",
  userName: "Admin",
  searchVal: "",
  secondaryTabs: [
  {
    key: "FI-Region01",
    label: "FI-Region01"
  },
  {
    key: "FI-Region02",
    label: "FI-Region02"
  },
  {
    key: "FI-Region03",
    label: "FI-Region03"
  },
  {
    key: "FI-Region04",
    label: "FI-Region04"
  },
  {
    key: "FI-Region05",
    label: "FI-Region05"
  }
],
  listItems: [
  {
    col1Img: "./pattern/icon-thought.svg",
    col1Top: "思维链名称",
    col1Bottom: "验证Telemetry场景级思维链werr",
    col2Top: "故障级别",
    col2Bottom: "紧急",
    col3Top: "描述",
    col3Bottom: "验证Telemetry场景级思维链",
    col4Status: true,
    col4Text: "成功",
    col5Value: true,
    col6Top: "创建时间",
    col6Bottom: "2025-05-11 10:11:24",
    col7Top: "更新时间",
    col7Bottom: "2025-05-11 10:11:24",
    col8Top: "更新用户",
    col8Bottom: "admin",
    col9Top: "最新版本",
    col9Bottom: "V3 历史版本"
  },
  {
    col1Img: "./pattern/icon-thought.svg",
    col1Top: "思维链名称",
    col1Bottom: "验证Telemetry场景级思维链",
    col2Top: "故障级别",
    col2Bottom: "紧急",
    col3Top: "描述",
    col3Bottom: "验证Telemetry场景级思维链",
    col4Status: true,
    col4Text: "成功",
    col5Value: true,
    col6Top: "创建时间",
    col6Bottom: "2025-05-11 10:11:24",
    col7Top: "更新时间",
    col7Bottom: "2025-05-11 10:11:24",
    col8Top: "更新用户",
    col8Bottom: "admin",
    col9Top: "最新版本",
    col9Bottom: "V3 历史版本"
  },
  {
    col1Img: "./pattern/icon-thought.svg",
    col1Top: "思维链名称",
    col1Bottom: "IP地址冲突验证",
    col2Top: "故障级别",
    col2Bottom: "紧急",
    col3Top: "描述",
    col3Bottom: "ARP冲突告罄处置",
    col4Status: true,
    col4Text: "成功",
    col5Value: true,
    col6Top: "创建时间",
    col6Bottom: "2025-05-11 10:11:24",
    col7Top: "更新时间",
    col7Bottom: "2025-05-11 10:11:24",
    col8Top: "更新用户",
    col8Bottom: "admin",
    col9Top: "最新版本",
    col9Bottom: "V3 历史版本"
  },
  {
    col1Img: "./pattern/icon-thought.svg",
    col1Top: "思维链名称",
    col1Bottom: "IP地址冲突验证",
    col2Top: "故障级别",
    col2Bottom: "紧急",
    col3Top: "描述",
    col3Bottom: "ARP冲突告罄处置",
    col4Status: true,
    col4Text: "成功",
    col5Value: true,
    col6Top: "创建时间",
    col6Bottom: "2025-05-11 10:11:24",
    col7Top: "更新时间",
    col7Bottom: "2025-05-11 10:11:24",
    col8Top: "更新用户",
    col8Bottom: "admin",
    col9Top: "最新版本",
    col9Bottom: "V3 历史版本"
  },
  {
    col1Img: "./pattern/icon-thought.svg",
    col1Top: "思维链名称",
    col1Bottom: "IP地址冲突验证",
    col2Top: "故障级别",
    col2Bottom: "紧急",
    col3Top: "描述",
    col3Bottom: "ARP冲突告罄处置",
    col4Status: true,
    col4Text: "成功",
    col5Value: true,
    col6Top: "创建时间",
    col6Bottom: "2025-05-11 10:11:24",
    col7Top: "更新时间",
    col7Bottom: "2025-05-11 10:11:24",
    col8Top: "更新用户",
    col8Bottom: "admin",
    col9Top: "最新版本",
    col9Bottom: "V3 历史版本"
  },
  {
    col1Img: "./pattern/icon-thought.svg",
    col1Top: "思维链名称",
    col1Bottom: "IP地址冲突验证",
    col2Top: "故障级别",
    col2Bottom: "紧急",
    col3Top: "描述",
    col3Bottom: "ARP冲突告罄处置",
    col4Status: true,
    col4Text: "成功",
    col5Value: true,
    col6Top: "创建时间",
    col6Bottom: "2025-05-11 10:11:24",
    col7Top: "更新时间",
    col7Bottom: "2025-05-11 10:11:24",
    col8Top: "更新用户",
    col8Bottom: "admin",
    col9Top: "最新版本",
    col9Bottom: "V3 历史版本"
  }
],
  selectedValue: "",
  mCnPrimaryNavSelectedIndex: 0,
  mCnSecondaryNavSelectedIndex: 0,
};
