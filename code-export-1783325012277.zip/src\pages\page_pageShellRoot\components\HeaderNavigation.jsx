import React from 'react';
import { initialState } from '../state';

import '../styles/HeaderNavigation.less';

import { IconPlusIcPublicTransverseRectangleTemplate } from '@hui/icon-plus';

const logoImage = initialState.logoImage;
const systemName = initialState.systemName;
const userName = initialState.userName;


export const HeaderNavigation = () => {
  return (
      <div id="headerShellContainer" className="headerShellContainer_style">
        <div id="hdrLeftSection" className="hdrLeftSection_style">
          <IconPlusIcPublicTransverseRectangleTemplate id="hdrHamburgerIcon" className="hdrHamburgerIcon_style" />
          <img id="hdrLogoImg" className="hdrLogoImg_style" src={logoImage} alt="Logo" />
          <span id="hdrSystemName" className="hdrSystemName_style">{systemName}</span>
        </div>
        <div id="hdrRightSection" className="hdrRightSection_style">
          <IconPlusIcPublicTransverseRectangleTemplate id="hdrHelpIcon" className="hdrHelpIcon_style" />
          <IconPlusIcPublicTransverseRectangleTemplate id="hdrLangIcon" className="hdrLangIcon_style" />
          <IconPlusIcPublicTransverseRectangleTemplate id="hdrSunIcon" className="hdrSunIcon_style" />
          <div id="hdrUserSection" className="hdrUserSection_style">
            <IconPlusIcPublicTransverseRectangleTemplate id="hdrUserIcon" className="hdrUserIcon_style" />
            <span id="hdrUserName" className="hdrUserName_style">{userName}</span>
          </div>
        </div>
      </div>
  );
};

export default HeaderNavigation;