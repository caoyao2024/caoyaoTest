import React from 'react';
import { initialState } from '../state';

import '../styles/Sidebar.less';

import Menu from '@/components/Menu';
import Button from '@nce/eview-react/Button';
import { IconPlusIcPublicTransverseRectangleTemplate } from '@hui/icon-plus';

const menuItems = initialState.menuItems;


export const Sidebar = () => {
  return (
      <div id="sideShellContainer" className="sideShellContainer_style">
        <div id="sdbLogoContainer" className="sdbLogoContainer_style"><img id="sdbLogoImg" className="sdbLogoImg_style" src="./pattern/icon-arouse.svg" alt="Logo" /></div>
        <div id="sdbMenuContainer" className="sdbMenuContainer_style"><Menu id="sdbMainMenu" className="sdbMainMenu_style" mode="vertical" inlineCollapsed={true} selectedKeys={sdbMainMenu_selectedKeys} items={menuItems} /></div>
        <div id="sdbBottomContainer" className="sdbBottomContainer_style">
          <Button id="sdbHelpBtn" className="sdbHelpBtn_style" shape="circle" leftIcon={sdbHelpBtn_leftIcon} />
          <Button id="sdbLogoutBtn" className="sdbLogoutBtn_style" shape="circle" leftIcon={sdbLogoutBtn_leftIcon} />
        </div>
      </div>
  );
};

export default Sidebar;