import React from 'react';
import { initialState } from '../state';

import '../styles/MainCard.less';

import Tabs from '@/components/Tabs';
import TabItem from '@/components/TabItem';
import TextField from '@nce/eview-react/TextField';
import { IconPlusIcPublicTransverseRectangleTemplate } from '@hui/icon-plus';
import Button from '@nce/eview-react/Button';

const activeSecondaryTab = initialState.activeSecondaryTab;
const activeTabKey = initialState.activeTabKey;


export const MainCard = () => {
  return (
      <div id="mainShellContainer" className="mainShellContainer_style">
        <div id="mCnCardContent" className="mCnCardContent_style">
          <span id="mCnTitle" className="mCnTitle_style">策略中心</span>
          <Tabs id="mCnPrimaryNav" className="mCnPrimaryNav_style" activeKey={activeTabKey} types="line" size="medium">
            <TabItem id="mnC_primaryTab1" className="mnC_primaryTab1_style" key="fault" label="故障思维链" content="" />
            <TabItem id="mnC_primaryTab2" className="mnC_primaryTab2_style" key="xxx" label="XXX思维链" content="" />
            <TabItem id="mnC_primaryTab3" className="mnC_primaryTab3_style" key="custom" label="自定义思维链" content="" />
          </Tabs>
          <Tabs id="mCnSecondaryNav" className="mCnSecondaryNav_style" activeKey={activeSecondaryTab} types="card" size="small" />
          <div id="mCnToolbar" className="mCnToolbar_style">
            <div id="mCnToolbarLeft" className="mCnToolbarLeft_style"><TextField id="mCnSearchInput" className="mCnSearchInput_style" value={searchVal} onChange={(e) => setSearchVal(e.target.value)} placeholder="Search" prefix={mCnSearchInput_prefix} size="normal" type="text" /></div>
            <div id="mCnToolbarRight" className="mCnToolbarRight_style">
              <Button id="mCnDeleteBtn" className="mCnDeleteBtn_style" text="删除" />
              <Button id="mCnDisableBtn" className="mCnDisableBtn_style" text="禁用" />
              <Button id="mCnCreateBtn" className="mCnCreateBtn_style" text="创建" status="primary" />
            </div>
          </div>
          <div id="mCnList" className="mCnList_style" />
        </div>
      </div>
  );
};

export default MainCard;