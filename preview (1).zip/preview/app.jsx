import { useEffect } from "react";
import { ConfigProvider } from "antd";
import dayjs from "dayjs";
import { IntlProvider } from "react-intl";
import zhCN from "./assets/shared/antd-zh.js";
import { AppProvider, useApp } from "./src/context.jsx";
import { messages } from "./src/i18n.js";
import AppHeader from "./src/views/app-header/index.jsx";
import AppSidebar from "./src/views/app-sidebar/index.jsx";
import Workbench from "./src/views/workbench/index.jsx";
import "./app.css";

// Layer 5: 页面骨架 — Provider（全局状态）→ ConfigProvider（antd 语种）→ IntlProvider（文案）
export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}

function AppShell() {
  const { lang } = useApp();

  // antd / dayjs 语种跟随（中文 locale 由 antd-zh.js 注入，英文为两者默认值）
  useEffect(() => {
    dayjs.locale(lang === "zh" ? "zh-cn" : "en");
  }, [lang]);

  return (
    <ConfigProvider locale={lang === "zh" ? zhCN : undefined}>
      <IntlProvider locale={lang} messages={messages[lang]}>
        <div className="app-root">
          <AppHeader />
          <div className="app-body">
            <AppSidebar />
            <main className="app-main">
              <Workbench />
            </main>
          </div>
        </div>
      </IntlProvider>
    </ConfigProvider>
  );
}
