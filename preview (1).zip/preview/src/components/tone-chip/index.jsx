import "./index.css";

// Layer 3: 语义色标签底座（状态 / 优先级共用），tone 对应语义色系 token
export default function ToneChip({ tone = "neutral", dot = false, children, className = "" }) {
  return (
    <span className={"chip chip--" + tone + (className ? " " + className : "")}>
      {dot ? <span className="chip__dot" /> : null}
      <span className="chip__text">{children}</span>
    </span>
  );
}
