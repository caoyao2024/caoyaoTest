import ToneChip from "../tone-chip/index.jsx";
import { statusMap } from "../../mock/task.js";
import { useT } from "../../i18n.js";

// Layer 3: 任务状态标签 — 语义色随 dark 自动翻转
export default function StatusTag({ status }) {
  const t = useT();
  const item = statusMap[status] || statusMap.pending;
  return (
    <ToneChip tone={item.tone} dot>
      {t(item.labelId, item.defaultLabel)}
    </ToneChip>
  );
}
