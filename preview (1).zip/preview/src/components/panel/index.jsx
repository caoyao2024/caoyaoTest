import "./index.css";

// Layer 3: 内容容器（布局容器，非 antd Card）— 卡片阴影在则不叠加描边
export default function Panel({ title, description, extra, children, className = "", bodyClassName = "" }) {
  return (
    <section className={"panel" + (className ? " " + className : "")}>
      {title ? (
        <header className="panel__head">
          <div className="panel__head-main">
            <h3 className="panel__title">{title}</h3>
            {description ? <p className="panel__desc">{description}</p> : null}
          </div>
          {extra ? <div className="panel__extra">{extra}</div> : null}
        </header>
      ) : null}
      <div className={"panel__body" + (bodyClassName ? " " + bodyClassName : "")}>{children}</div>
    </section>
  );
}
