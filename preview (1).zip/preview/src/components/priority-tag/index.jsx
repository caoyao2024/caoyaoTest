import ToneChip from "../tone-chip/index.jsx";
import { priorityMap } from "../../mock/task.js";
import { useT } from "../../i18n.js";

// Layer 3: 优先级标签
export default function PriorityTag({ priority }) {
  const t = useT();
  const item = priorityMap[priority] || priorityMap.medium;
  return <ToneChip tone={item.tone}>{t(item.labelId, item.defaultLabel)}</ToneChip>;
}
