import "./index.css";

// Layer 3: 数字输入 + 单位（行内组合，Space.Compact 不可用时使用 CSS Flex）
export default function FieldInline({ children }) {
  return <div className="field-inline">{children}</div>;
}

export function FieldInlineUnit({ children }) {
  return <span className="field-inline__unit">{children}</span>;
}
