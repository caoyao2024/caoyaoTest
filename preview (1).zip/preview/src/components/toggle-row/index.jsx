import { Icon } from "../../../assets/shared/icon.jsx";
import "./index.css";

// Layer 3: 开关设置行 — 说明在左、控件在右，开启态高亮
export default function ToggleRow({ icon = "sliders-horizontal", title, description, stateText, enabled, control, className = "" }) {
  return (
    <div className={"toggle-row" + (enabled ? " is-on" : "") + (className ? " " + className : "")}>
      <span className="toggle-row__icon">
        <Icon name={icon} size="1.25rem" />
      </span>
      <span className="toggle-row__text">
        <span className="toggle-row__title">
          {title}
          {stateText ? (
            <em className={"toggle-row__state" + (enabled ? " is-on" : "")}>{stateText}</em>
          ) : null}
        </span>
        <p className="toggle-row__desc">{description}</p>
      </span>
      <span className="toggle-row__control">{control}</span>
    </div>
  );
}
