import { useEffect } from "react";
import { DatePicker, Form, Input, InputNumber, Modal, Radio, Select, Switch } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import ToggleRow from "../../components/toggle-row/index.jsx";
import FieldInline from "../../components/field-inline/index.jsx";
import { deviceGroups, owners, protocols, regions, taskTypes } from "../../mock/task.js";
import { useApp } from "../../context.jsx";
import { pick, useT } from "../../i18n.js";
import "./index.css";

const { RangePicker } = DatePicker;

// Layer 4: 表单弹窗 — 新建 / 编辑任务，同样支持高级采集开关联动
export default function TaskModal({ open, mode, record, onCancel, onSubmit }) {
  const t = useT();
  const { lang } = useApp();
  const [form] = Form.useForm();
  const advanced = Form.useWatch("advanced", form);

  useEffect(() => {
    if (!open) return;
    if (mode === "edit" && record) {
      form.setFieldsValue({
        name: lang === "en" ? record.nameEn : record.nameZh,
        type: record.type,
        deviceGroups: [record.group],
        region: record.region,
        owner: record.owner,
        priority: record.priority,
        advanced: !!record.advanced,
        freq: 5,
        freqUnit: "min",
        protocol: "snmp",
        receivers: [record.owner],
        note: "",
      });
    } else {
      form.resetFields();
    }
  }, [open, mode, record]);

  const options = (list) => list.map((it) => ({ value: it.value, label: pick(lang, it) }));

  const unitOptions = [
    { value: "sec", label: t("form.freq.unit.sec", "秒") },
    { value: "min", label: t("form.freq.unit.min", "分钟") },
    { value: "hour", label: t("form.freq.unit.hour", "小时") },
  ];

  return (
    <Modal
      open={open}
      width={760}
      maskClosable={false}
      title={mode === "edit" ? t("modal.edit.title", "编辑巡检任务") : t("modal.create.title", "新建巡检任务")}
      okText={t("common.ok", "确定")}
      cancelText={t("common.cancel", "取消")}
      onOk={() => form.submit()}
      onCancel={onCancel}
    >
      <Form
        form={form}
        layout="vertical"
        className="task-modal"
        onFinish={(values) => onSubmit(values, mode)}
        initialValues={{ type: "periodic", priority: "medium", advanced: false, freq: 5, freqUnit: "min", protocol: "snmp" }}
      >
        <p className="task-modal__desc">
          <Icon name="info" size="0.875rem" />
          {t("modal.desc", "填写任务名称与关联设备组，可按需开启高级采集。")}
        </p>

        <div className="task-modal__grid">
          <Form.Item
            className="task-modal__full"
            label={t("form.name", "任务名称")}
            name="name"
            rules={[{ required: true, message: t("form.name.rule", "请输入任务名称") }]}
          >
            <Input placeholder={t("form.name.placeholder", "例如：深圳核心网夜间巡检")} maxLength={40} allowClear />
          </Form.Item>

          <Form.Item
            label={t("form.type", "任务类型")}
            name="type"
            rules={[{ required: true, message: t("form.type.rule", "请选择任务类型") }]}
          >
            <Select options={options(taskTypes)} />
          </Form.Item>

          <Form.Item label={t("form.region", "所属区域")} name="region">
            <Select allowClear placeholder={t("form.region.placeholder", "请选择所属区域")} options={options(regions)} />
          </Form.Item>

          <Form.Item
            className="task-modal__full"
            label={t("form.deviceGroup", "关联设备组")}
            name="deviceGroups"
            rules={[{ required: true, message: t("form.deviceGroup.rule", "请至少选择一个设备组") }]}
          >
            <Select mode="multiple" maxTagCount="responsive" placeholder={t("form.deviceGroup.placeholder", "请选择至少一个设备组")} options={options(deviceGroups)} />
          </Form.Item>

          <Form.Item
            label={t("form.owner", "负责人")}
            name="owner"
            rules={[{ required: true, message: t("form.owner.rule", "请选择负责人") }]}
          >
            <Select showSearch placeholder={t("form.owner.placeholder", "请选择负责人")} options={options(owners)} />
          </Form.Item>

          <Form.Item label={t("form.window", "执行窗口")} name="window">
            <RangePicker showTime={{ format: "HH:mm" }} format="YYYY-MM-DD HH:mm" className="u-full-width" />
          </Form.Item>
        </div>

        <ToggleRow
          icon="sliders-horizontal"
          title={t("form.advanced", "启用高级采集")}
          description={t("modal.advanced.desc", "开启后需要补充采集频率、上报协议与告警接收人")}
          stateText={advanced ? t("form.advanced.on", "已开启") : t("form.advanced.off", "已关闭")}
          enabled={advanced}
          control={
            <Form.Item name="advanced" valuePropName="checked" noStyle>
              <Switch />
            </Form.Item>
          }
        />

        {advanced ? (
          <div className="task-modal__advanced">
            <div className="task-modal__grid">
              <Form.Item label={t("form.freq", "采集频率")}>
                <FieldInline>
                  <Form.Item name="freq" noStyle>
                    <InputNumber min={1} max={1440} style={{ width: "100%" }} />
                  </Form.Item>
                  <Form.Item name="freqUnit" noStyle>
                    <Select options={unitOptions} style={{ width: "7rem" }} />
                  </Form.Item>
                </FieldInline>
              </Form.Item>

              <Form.Item label={t("form.protocol", "上报协议")} name="protocol">
                <Radio.Group options={options(protocols)} optionType="button" buttonStyle="solid" />
              </Form.Item>

              <Form.Item
                className="task-modal__full"
                label={t("form.receivers", "告警接收人")}
                name="receivers"
              >
                <Select mode="multiple" maxTagCount="responsive" placeholder={t("form.receivers.placeholder", "请选择接收人（可多选）")} options={options(owners)} />
              </Form.Item>
            </div>
          </div>
        ) : null}

        <Form.Item className="task-modal__note" label={t("modal.note", "备注")} name="note">
          <Input.TextArea rows={2} maxLength={120} placeholder={t("modal.note.placeholder", "选填，便于团队快速了解任务用途")} />
        </Form.Item>

        <p className="task-modal__hint">
          <Icon name="send" size="0.875rem" />
          {t("modal.hint", "提交后将立即下发到采集编排引擎。")}
        </p>
      </Form>
    </Modal>
  );
}
