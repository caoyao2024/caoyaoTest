import { Button, Dropdown, Input, Menu, Tooltip } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import { navModules } from "../../mock/nav.js";
import { useApp } from "../../context.jsx";
import { useT } from "../../i18n.js";
import "./index.css";

// Layer 4: 顶部导航 — 品牌 / 全局模块导航 / 国际化 + 主题切换 / 用户区
export default function AppHeader() {
  const t = useT();
  const { lang, setLang, isDark, toggleDark, activeModule, selectModule } = useApp();

  const moduleItems = navModules.map((m) => ({
    key: m.key,
    icon: <Icon name={m.icon} size="1rem" />,
    label: t(m.labelId, m.defaultLabel),
  }));

  const langItems = [
    { key: "zh", label: t("header.lang.zh", "中文") },
    { key: "en", label: t("header.lang.en", "English") },
  ];

  const userItems = [
    { key: "profile", icon: <Icon name="user" size="0.875rem" />, label: t("header.user.profile", "个人中心") },
    { key: "account", icon: <Icon name="user-cog" size="0.875rem" />, label: t("header.user.setting", "账号设置") },
    { type: "divider" },
    { key: "logout", icon: <Icon name="log-out" size="0.875rem" />, label: t("header.user.logout", "退出登录"), danger: true },
  ];

  const themeKey = isDark ? "light" : "dark";
  const themeLabel = isDark ? t("header.theme.light", "浅色") : t("header.theme.dark", "深色");

  return (
    <header className="app-header">
      <div className="app-header__brand">
        <span className="app-header__logo">
          <Icon name="workflow" size="1rem" />
        </span>
        <span className="app-header__brand-text">
          <strong>{t("app.name", "智能运维平台")}</strong>
          <em>{t("app.tagline", "网络自动化巡检 · 采集编排")}</em>
        </span>
      </div>

      <nav className="app-header__nav">
        <Menu
          mode="horizontal"
          selectedKeys={[activeModule]}
          items={moduleItems}
          onClick={({ key }) => selectModule(key)}
        />
      </nav>

      <div className="app-header__tools">
        <Input
          className="app-header__search"
          size="small"
          allowClear
          placeholder={t("header.search.placeholder", "搜索任务名称、编号或负责人")}
          suffix={<Icon name="search" size="0.875rem" />}
        />
        <Dropdown
          trigger={["click"]}
          placement="bottomRight"
          menu={{ items: langItems, selectedKeys: [lang], onClick: ({ key }) => setLang(key) }}
        >
          <Button type="text" icon={<Icon name="languages" size="0.875rem" />}>
            {lang === "zh" ? t("header.lang.zh", "中文") : t("header.lang.en", "English")}
          </Button>
        </Dropdown>
        <Tooltip title={t("header.theme", "主题") + " · " + themeLabel}>
          <Button
            type="text"
            data-theme={themeKey}
            icon={<Icon name={isDark ? "sun" : "moon"} size="0.875rem" />}
            onClick={toggleDark}
          >
            {themeLabel}
          </Button>
        </Tooltip>
        <span className="app-header__divider" />
        <Dropdown trigger={["click"]} placement="bottomRight" menu={{ items: userItems }}>
          <button type="button" className="user-chip">
            <img className="user-chip__avatar" src="./assets/uploads/user.png" alt="" />
            <span className="user-chip__meta">
              <strong>{t("header.user.name", "张启明")}</strong>
              <em>{t("header.user.role", "网络运维工程师")}</em>
            </span>
            <Icon name="chevron-down" size="0.875rem" />
          </button>
        </Dropdown>
      </div>
    </header>
  );
}
