import { useMemo, useState } from "react";
import { Button, Input, Progress, Select, Table, Tooltip, message } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import Panel from "../../components/panel/index.jsx";
import StatusTag from "../../components/status-tag/index.jsx";
import PriorityTag from "../../components/priority-tag/index.jsx";
import { deviceGroups, owners, statusOptions, taskTypes } from "../../mock/task.js";
import { useApp } from "../../context.jsx";
import { pick, useT } from "../../i18n.js";
import "./index.css";

// Layer 4: 任务列表 — 关键词 / 状态筛选、行选择、批量操作、分页
export default function TaskTable({ tasks, onEdit, onDelete, onBatchDelete, onBatchRun }) {
  const t = useT();
  const { lang } = useApp();
  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState("all");
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const labelOf = (list, value) => pick(lang, list.find((it) => it.value === value));

  const filtered = useMemo(() => {
    const kw = keyword.trim().toLowerCase();
    return tasks.filter((row) => {
      if (status !== "all" && row.status !== status) return false;
      if (!kw) return true;
      const fields = [
        row.id,
        row.nameZh,
        row.nameEn,
        labelOf(owners, row.owner),
        labelOf(deviceGroups, row.group),
      ];
      return fields.some((f) => f && String(f).toLowerCase().includes(kw));
    });
  }, [tasks, keyword, status, lang]);

  const columns = [
    {
      title: t("table.col.id", "任务编号"),
      dataIndex: "id",
      width: 132,
      render: (value) => <span className="cell-code">{value}</span>,
    },
    {
      title: t("table.col.name", "任务名称"),
      dataIndex: "nameZh",
      width: 280,
      render: (_value, row) => (
        <span className="cell-name">
          <a onClick={() => onEdit(row)}>{lang === "en" ? row.nameEn : row.nameZh}</a>
          <em>
            <Icon name="folder-tree" size="0.75rem" />
            {labelOf(deviceGroups, row.group)}
          </em>
        </span>
      ),
    },
    {
      title: t("table.col.type", "类型"),
      dataIndex: "type",
      width: 128,
      render: (value) => <span className="cell-text">{labelOf(taskTypes, value)}</span>,
    },
    {
      title: t("table.col.status", "状态"),
      dataIndex: "status",
      width: 120,
      render: (value) => <StatusTag status={value} />,
    },
    {
      title: t("table.col.priority", "优先级"),
      dataIndex: "priority",
      width: 96,
      render: (value) => <PriorityTag priority={value} />,
    },
    {
      title: t("table.col.owner", "负责人"),
      dataIndex: "owner",
      width: 120,
      render: (value) => <span className="cell-text">{labelOf(owners, value)}</span>,
    },
    {
      title: t("table.col.lastRun", "最近执行"),
      dataIndex: "lastRun",
      width: 172,
      sorter: (a, b) => String(a.lastRun).localeCompare(String(b.lastRun)),
      render: (value) => (
        <span className="cell-time">
          <Icon name="clock" size="0.75rem" />
          {value}
        </span>
      ),
    },
    {
      title: t("table.col.duration", "耗时"),
      dataIndex: "duration",
      width: 104,
      align: "right",
      render: (value) => <span className="cell-num">{value}</span>,
    },
    {
      title: t("table.col.progress", "采集进度"),
      dataIndex: "progress",
      width: 168,
      render: (value) => (
        <span className="cell-progress">
          <Progress percent={value} size="small" showInfo={false} />
          <em>{value}%</em>
        </span>
      ),
    },
    {
      title: t("table.col.action", "操作"),
      key: "action",
      width: 128,
      render: (_value, row) => (
        <span className="cell-actions">
          <Tooltip title={t("table.action.view", "查看详情")}>
            <Button type="text" shape="circle" size="small" icon={<Icon name="eye" size="0.875rem" />} />
          </Tooltip>
          <Tooltip title={t("table.action.edit", "编辑任务")}>
            <Button
              type="text"
              shape="circle"
              size="small"
              icon={<Icon name="pencil" size="0.875rem" />}
              onClick={() => onEdit(row)}
            />
          </Tooltip>
          <Tooltip title={t("table.action.delete", "删除任务")}>
            <Button
              type="text"
              danger
              shape="circle"
              size="small"
              icon={<Icon name="trash-2" size="0.875rem" />}
              onClick={() => onDelete(row)}
            />
          </Tooltip>
        </span>
      ),
    },
  ];

  const selectedCount = selectedRowKeys.length;

  return (
    <Panel
      className="task-table-panel"
      title={t("table.title", "任务列表")}
      description={t("table.desc", "共 {total} 个巡检任务，支持按状态筛选与批量操作", { total: tasks.length })}
    >
      <div className="table-toolbar">
        <Input
          className="table-toolbar__search"
          size="small"
          allowClear
          value={keyword}
          onChange={(e) => {
            setKeyword(e.target.value);
            setPage(1);
          }}
          placeholder={t("table.search.placeholder", "搜索任务名称、编号或负责人")}
          suffix={<Icon name="search" size="0.875rem" />}
        />
        <Select
          size="small"
          className="table-toolbar__status"
          value={status}
          onChange={(value) => {
            setStatus(value);
            setPage(1);
          }}
          options={[{ value: "all", label: t("common.all", "全部") }].concat(
            statusOptions.map((s) => ({ value: s.value, label: t(s.labelId, s.defaultLabel) }))
          )}
        />
        <span className="table-toolbar__spacer" />
        <Button
          size="small"
          icon={<Icon name="download" size="0.875rem" />}
          onClick={() => message.success(t("toast.exported", "导出任务已生成"))}
        >
          {t("common.export", "导出")}
        </Button>
      </div>

      {selectedCount ? (
        <div className="table-batch">
          <span className="table-batch__text">
            <Icon name="square-check" size="0.875rem" />
            {t("common.selectedCount", "已选 {count} 项", { count: selectedCount })}
          </span>
          <span className="table-batch__actions">
            <Button
              size="small"
              icon={<Icon name="play" size="0.875rem" />}
              onClick={() => {
                onBatchRun(selectedRowKeys);
                setSelectedRowKeys([]);
              }}
            >
              {t("table.batch.run", "批量执行")}
            </Button>
            <Button
              size="small"
              icon={<Icon name="download" size="0.875rem" />}
              onClick={() => message.success(t("toast.exported", "导出任务已生成"))}
            >
              {t("table.batch.export", "批量导出")}
            </Button>
            <Button
              size="small"
              danger
              icon={<Icon name="trash-2" size="0.875rem" />}
              onClick={() => {
                onBatchDelete(selectedRowKeys);
                setSelectedRowKeys([]);
              }}
            >
              {t("common.delete", "删除")}
            </Button>
            <Button size="small" icon={<Icon name="x" size="0.875rem" />} onClick={() => setSelectedRowKeys([])}>
              {t("table.batch.clear", "取消选择")}
            </Button>
          </span>
        </div>
      ) : null}

      <Table
        rowKey="id"
        size="middle"
        columns={columns}
        dataSource={filtered}
        rowSelection={{ selectedRowKeys, onChange: (keys) => setSelectedRowKeys(keys), preserveSelectedRowKeys: true }}
        scroll={{ x: 1560 }}
        locale={{ emptyText: t("table.empty", "暂无匹配的任务") }}
        pagination={{
          current: page,
          pageSize,
          total: filtered.length,
          showSizeChanger: true,
          pageSizeOptions: [5, 10, 20, 50],
          showTotal: (total) => t("table.total", "共 {total} 条", { total }),
          onChange: (nextPage, nextSize) => {
            setPage(nextPage);
            setPageSize(nextSize);
          },
        }}
      />
    </Panel>
  );
}
