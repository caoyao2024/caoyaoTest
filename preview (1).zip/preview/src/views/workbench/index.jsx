import { useMemo, useState } from "react";
import { Breadcrumb, Button, Form, Progress, message } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import Panel from "../../components/panel/index.jsx";
import StatusTag from "../../components/status-tag/index.jsx";
import TaskForm from "../task-form/index.jsx";
import TaskTable from "../task-table/index.jsx";
import TaskModal from "../task-modal/index.jsx";
import { policies, tasks } from "../../mock/task.js";
import { navModules } from "../../mock/nav.js";
import { useApp } from "../../context.jsx";
import { pick, useT } from "../../i18n.js";
import "./index.css";

// Layer 4: 页面装配 — 任务中心（表单 + 概览 + 列表 + 弹窗）；其余模块为占位页
export default function Workbench() {
  const { activeModule } = useApp();
  if (activeModule !== "tasks") return <ModulePlaceholder />;
  return <TaskWorkbench />;
}

function subLabelOf(activeSub) {
  for (const mod of navModules) {
    const hit = mod.children.find((c) => c.key === activeSub);
    if (hit) return hit;
  }
  return null;
}

function ModulePlaceholder() {
  const t = useT();
  const { activeModule, selectModule } = useApp();
  const mod = navModules.find((m) => m.key === activeModule) || navModules[0];

  return (
    <div className="placeholder">
      <span className="placeholder__icon">
        <Icon name={mod.icon} size="2.5rem" />
      </span>
      <h2 className="placeholder__title">{t("placeholder.title", "模块建设中")}</h2>
      <p className="placeholder__desc">{t("placeholder.desc", "该模块正在迭代，原型仅完整实现「任务中心 · 任务列表」。")}</p>
      <Button type="primary" icon={<Icon name="clipboard-list" size="0.875rem" />} onClick={() => selectModule("tasks")}>
        {t("placeholder.back", "返回任务中心")}
      </Button>
    </div>
  );
}

function TaskWorkbench() {
  const t = useT();
  const { lang, activeSub } = useApp();
  const [form] = Form.useForm();
  const [rows, setRows] = useState(tasks);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("create");
  const [editing, setEditing] = useState(null);

  const sub = subLabelOf(activeSub);

  const metrics = useMemo(() => {
    const count = (status) => rows.filter((r) => r.status === status).length;
    const success = count("success");
    const failed = count("failed");
    const warning = count("warning");
    const settled = success + failed + warning;
    return {
      total: rows.length,
      running: count("running"),
      success,
      failed,
      warning,
      advanced: rows.filter((r) => r.advanced).length,
      health: settled ? Math.round((success / settled) * 100) : 0,
    };
  }, [rows]);

  const recent = useMemo(() => {
    return rows
      .filter((r) => r.status !== "pending" && r.status !== "queued")
      .slice()
      .sort((a, b) => String(b.lastRun).localeCompare(String(a.lastRun)))
      .slice(0, 5);
  }, [rows]);

  const nameOf = (row) => (lang === "en" ? row.nameEn : row.nameZh);

  const buildRow = (values) => ({
    id: "TSK-" + Date.now().toString().slice(-6),
    nameZh: (values.name || "").trim(),
    nameEn: (values.name || "").trim(),
    type: values.type || "periodic",
    group: (values.deviceGroups && values.deviceGroups[0]) || "g1",
    region: values.region || "r1",
    status: "pending",
    priority: values.priority || "medium",
    owner: values.owner || "u1",
    lastRun: "—",
    duration: "—",
    progress: 0,
    advanced: !!values.advanced,
  });

  const handleFormSubmit = (values) => {
    const row = buildRow(values);
    setRows((prev) => [row, ...prev]);
    message.success(t("toast.created", "任务「{name}」已创建", { name: nameOf(row) }));
  };

  const handleModalSubmit = (values, mode) => {
    if (mode === "edit" && editing) {
      setRows((prev) =>
        prev.map((r) =>
          r.id === editing.id
            ? {
                ...r,
                nameZh: (values.name || "").trim(),
                nameEn: (values.name || "").trim(),
                type: values.type || r.type,
                group: (values.deviceGroups && values.deviceGroups[0]) || r.group,
                region: values.region || r.region,
                owner: values.owner || r.owner,
                priority: values.priority || r.priority,
                advanced: !!values.advanced,
              }
            : r
        )
      );
      message.success(t("toast.updated", "任务「{name}」已更新", { name: (values.name || "").trim() }));
    } else {
      const row = buildRow(values);
      setRows((prev) => [row, ...prev]);
      message.success(t("toast.created", "任务「{name}」已创建", { name: nameOf(row) }));
    }
    setModalOpen(false);
  };

  const handleCreate = () => {
    setModalMode("create");
    setEditing(null);
    setModalOpen(true);
  };

  const handleEdit = (row) => {
    setModalMode("edit");
    setEditing(row);
    setModalOpen(true);
  };

  const handleDelete = (row) => {
    setRows((prev) => prev.filter((r) => r.id !== row.id));
    message.success(t("toast.deleted", "已删除 {count} 条任务", { count: 1 }));
  };

  const handleBatchDelete = (keys) => {
    setRows((prev) => prev.filter((r) => !keys.includes(r.id)));
    message.success(t("toast.deleted", "已删除 {count} 条任务", { count: keys.length }));
  };

  const handleBatchRun = (keys) => {
    setRows((prev) => prev.map((r) => (keys.includes(r.id) ? { ...r, status: "running", progress: 5 } : r)));
    message.success(t("toast.batchRun", "已提交 {count} 条任务执行", { count: keys.length }));
  };

  const handleApplyPolicy = (policy) => {
    form.setFieldsValue({ advanced: true, ...policy.values });
    message.success(t("toast.policyApplied", "已套用采集策略：{name}", { name: pick(lang, policy) }));
  };

  return (
    <div className="workbench">
      <div className="workbench__head">
        <div className="workbench__head-main">
          <Breadcrumb
            items={[
              { title: t("crumb.home", "首页") },
              { title: t("nav.tasks", "任务中心") },
              { title: sub ? t(sub.labelId, sub.defaultLabel) : t("menu.tasks.list", "任务列表") },
            ]}
          />
          <h2 className="workbench__title">{t("workbench.title", "巡检任务编排")}</h2>
          <p className="workbench__desc">{t("workbench.desc", "配置采集任务的基础信息与高级采集策略，提交后即可下发到编排引擎并跟踪执行结果。")}</p>
        </div>
        <div className="workbench__actions">
          <Button
            icon={<Icon name="refresh-cw" size="0.875rem" />}
            onClick={() => message.success(t("toast.refreshed", "数据已刷新"))}
          >
            {t("common.refresh", "刷新")}
          </Button>
          <Button type="primary" icon={<Icon name="plus" size="0.875rem" />} onClick={handleCreate}>
            {t("workbench.action.new", "新建任务")}
          </Button>
        </div>
      </div>

      <div className="workbench__grid">
        <TaskForm form={form} onSubmit={handleFormSubmit} />

        <aside className="workbench__aside">
          <Panel title={t("metrics.title", "执行概览")} description={t("metrics.desc", "近 24 小时采集统计")}>
            <div className="metrics">
              <span className="metric">
                <em className="metric__label">
                  <Icon name="clipboard-list" size="0.75rem" />
                  {t("metrics.total", "任务总数")}
                </em>
                <strong className="metric__value">{metrics.total}</strong>
              </span>
              <span className="metric">
                <em className="metric__label">
                  <Icon name="activity" size="0.75rem" />
                  {t("metrics.running", "执行中")}
                </em>
                <strong className="metric__value metric__value--info">{metrics.running}</strong>
              </span>
              <span className="metric">
                <em className="metric__label">
                  <Icon name="circle-check" size="0.75rem" />
                  {t("metrics.success", "执行成功")}
                </em>
                <strong className="metric__value metric__value--success">{metrics.success}</strong>
              </span>
              <span className="metric">
                <em className="metric__label">
                  <Icon name="circle-alert" size="0.75rem" />
                  {t("metrics.failed", "执行失败")}
                </em>
                <strong className="metric__value metric__value--error">{metrics.failed}</strong>
              </span>
              <span className="metric">
                <em className="metric__label">
                  <Icon name="triangle-alert" size="0.75rem" />
                  {t("metrics.warning", "存在告警")}
                </em>
                <strong className="metric__value">{metrics.warning}</strong>
              </span>
              <span className="metric">
                <em className="metric__label">
                  <Icon name="sliders-horizontal" size="0.75rem" />
                  {t("metrics.advanced", "已启用高级采集")}
                </em>
                <strong className="metric__value">{metrics.advanced}</strong>
              </span>
            </div>

            <div className="health">
              <span className="health__row">
                <em>{t("metrics.health", "采集成功率")}</em>
                <strong>{metrics.health}%</strong>
              </span>
              <Progress percent={metrics.health} showInfo={false} size="small" />
            </div>
          </Panel>

          <Panel title={t("policies.title", "推荐采集策略")} description={t("policies.desc", "一键套用到当前表单")}>
            <ul className="policies">
              {policies.map((policy) => (
                <li key={policy.key}>
                  <button type="button" className="policy" onClick={() => handleApplyPolicy(policy)}>
                    <span className={"policy__icon policy__icon--" + policy.tone}>
                      <Icon name={policy.icon} size="1rem" />
                    </span>
                    <span className="policy__text">
                      <strong>{pick(lang, policy)}</strong>
                      <em>{lang === "en" ? policy.enDesc : policy.zhDesc}</em>
                    </span>
                    <Icon name="arrow-up-right" size="0.875rem" />
                  </button>
                </li>
              ))}
            </ul>
          </Panel>

          <Panel title={t("recent.title", "最近执行记录")} description={t("recent.desc", "取最近 5 条执行结果")}>
            <ul className="recent">
              {recent.map((row) => (
                <li className="recent__item" key={row.id}>
                  <span className="recent__top">
                    <StatusTag status={row.status} />
                    <em>{row.lastRun}</em>
                  </span>
                  <span className="recent__name">
                    <Icon name="folder-tree" size="0.75rem" />
                    {nameOf(row)}
                  </span>
                </li>
              ))}
            </ul>
          </Panel>
        </aside>
      </div>

      <TaskTable
        tasks={rows}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onBatchDelete={handleBatchDelete}
        onBatchRun={handleBatchRun}
      />

      <TaskModal
        open={modalOpen}
        mode={modalMode}
        record={editing}
        onCancel={() => setModalOpen(false)}
        onSubmit={handleModalSubmit}
      />
    </div>
  );
}
