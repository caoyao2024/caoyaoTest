import { Menu } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import { navModules } from "../../mock/nav.js";
import { useApp } from "../../context.jsx";
import { useT } from "../../i18n.js";
import "./index.css";

// Layer 4: 侧边导航 — 展示当前模块的子菜单，支持折叠
export default function AppSidebar() {
  const t = useT();
  const { sidebarCollapsed, toggleSidebar, activeModule, activeSub, selectSub } = useApp();
  const mod = navModules.find((m) => m.key === activeModule) || navModules[0];

  const items = mod.children.map((c) => ({
    key: c.key,
    icon: <Icon name={c.icon} size="1rem" />,
    label: t(c.labelId, c.defaultLabel),
  }));

  return (
    <aside className={"app-sidebar" + (sidebarCollapsed ? " is-collapsed" : "")}>
      <div className="app-sidebar__head">
        {sidebarCollapsed ? (
          <span className="app-sidebar__dot" />
        ) : (
          <span className="app-sidebar__heading">
            <em>{t("sidebar.group", "导航")}</em>
            <strong>{t(mod.labelId, mod.defaultLabel)}</strong>
          </span>
        )}
      </div>

      <div className="app-sidebar__body">
        <Menu
          mode="inline"
          inlineCollapsed={sidebarCollapsed}
          selectedKeys={[activeSub]}
          items={items}
          onClick={({ key }) => selectSub(key)}
        />
      </div>

      <div className="app-sidebar__foot">
        <button type="button" className="app-sidebar__toggle" onClick={toggleSidebar}>
          <Icon name={sidebarCollapsed ? "chevron-right" : "chevron-left"} size="0.875rem" />
          {sidebarCollapsed ? null : <span>{t("sidebar.collapse", "收起导航")}</span>}
        </button>
      </div>
    </aside>
  );
}
