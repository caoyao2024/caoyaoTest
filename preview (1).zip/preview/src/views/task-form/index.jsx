import { Button, DatePicker, Form, Input, InputNumber, Radio, Select, Switch, TimePicker, message } from "antd";
import { Icon } from "../../../assets/shared/icon.jsx";
import Panel from "../../components/panel/index.jsx";
import ToggleRow from "../../components/toggle-row/index.jsx";
import FieldInline, { FieldInlineUnit } from "../../components/field-inline/index.jsx";
import { deviceGroups, owners, protocols, regions, taskTypes } from "../../mock/task.js";
import { useApp } from "../../context.jsx";
import { pick, useT } from "../../i18n.js";
import "./index.css";

const { RangePicker } = DatePicker;

// Layer 4: 主体表单区 — 「启用高级采集」开关联动展开详细采集参数（表单实例由页面装配层持有）
export default function TaskForm({ form, onSubmit }) {
  const t = useT();
  const { lang } = useApp();
  const advanced = Form.useWatch("advanced", form);

  const options = (list) => list.map((it) => ({ value: it.value, label: pick(lang, it) }));

  const unitOptions = [
    { value: "sec", label: t("form.freq.unit.sec", "秒") },
    { value: "min", label: t("form.freq.unit.min", "分钟") },
    { value: "hour", label: t("form.freq.unit.hour", "小时") },
  ];

  const handleFinish = (values) => {
    onSubmit(values);
    form.resetFields();
  };

  return (
    <Panel
      className="task-form-panel"
      title={t("form.section.basic", "基础信息")}
      description={t("form.section.basic.desc", "任务的名称、归属与调度窗口")}
      extra={
        <span className="task-form-panel__tag">
          <Icon name="clipboard-list" size="0.875rem" />
          {t("nav.tasks", "任务中心")}
        </span>
      }
    >
      <Form
        form={form}
        layout="vertical"
        className="task-form"
        onFinish={handleFinish}
        initialValues={{
          priority: "medium",
          schedule: "daily",
          advanced: false,
          freq: 5,
          freqUnit: "min",
          sampling: 30,
          concurrency: 8,
          protocol: "snmp",
          timeout: 3000,
          retry: true,
          retryTimes: 2,
          deepScan: true,
        }}
      >
        <div className="task-form__grid">
          <Form.Item
            label={t("form.name", "任务名称")}
            name="name"
            rules={[{ required: true, message: t("form.name.rule", "请输入任务名称") }]}
            extra={t("form.name.extra", "名称需在团队内唯一，建议包含区域与采集对象")}
          >
            <Input placeholder={t("form.name.placeholder", "例如：深圳核心网夜间巡检")} maxLength={40} allowClear />
          </Form.Item>

          <Form.Item
            label={t("form.type", "任务类型")}
            name="type"
            rules={[{ required: true, message: t("form.type.rule", "请选择任务类型") }]}
          >
            <Select placeholder={t("form.type.placeholder", "请选择任务类型")} options={options(taskTypes)} />
          </Form.Item>

          <Form.Item
            className="task-form__full"
            label={t("form.deviceGroup", "关联设备组")}
            name="deviceGroups"
            rules={[{ required: true, message: t("form.deviceGroup.rule", "请至少选择一个设备组") }]}
          >
            <Select
              mode="multiple"
              maxTagCount="responsive"
              placeholder={t("form.deviceGroup.placeholder", "请选择至少一个设备组")}
              options={options(deviceGroups)}
            />
          </Form.Item>

          <Form.Item label={t("form.region", "所属区域")} name="region">
            <Select allowClear placeholder={t("form.region.placeholder", "请选择所属区域")} options={options(regions)} />
          </Form.Item>

          <Form.Item
            label={t("form.owner", "负责人")}
            name="owner"
            rules={[{ required: true, message: t("form.owner.rule", "请选择负责人") }]}
          >
            <Select showSearch placeholder={t("form.owner.placeholder", "请选择负责人")} options={options(owners)} />
          </Form.Item>

          <Form.Item label={t("form.schedule", "调度周期")} name="schedule">
            <Select
              placeholder={t("form.schedule.placeholder", "请选择调度周期")}
              options={[
                { value: "daily", label: t("form.schedule.daily", "每天") },
                { value: "weekly", label: t("form.schedule.weekly", "每周") },
                { value: "monthly", label: t("form.schedule.monthly", "每月") },
                { value: "once", label: t("form.schedule.once", "单次执行") },
              ]}
            />
          </Form.Item>

          <Form.Item label={t("form.priority", "优先级")} name="priority">
            <Radio.Group
              options={[
                { value: "high", label: t("priority.high", "高") },
                { value: "medium", label: t("priority.medium", "中") },
                { value: "low", label: t("priority.low", "低") },
              ]}
              optionType="button"
              buttonStyle="solid"
            />
          </Form.Item>

          <Form.Item
            className="task-form__full"
            label={t("form.window", "执行窗口")}
            name="window"
            extra={t("form.window.tip", "避开业务高峰期，窗口内按调度周期自动执行")}
          >
            <RangePicker showTime={{ format: "HH:mm" }} format="YYYY-MM-DD HH:mm" className="u-full-width" />
          </Form.Item>

          <Form.Item className="task-form__full" label={t("form.desc", "任务说明")} name="desc">
            <Input.TextArea
              rows={3}
              maxLength={200}
              showCount
              placeholder={t("form.desc.placeholder", "补充任务背景、影响范围与异常回滚方式")}
            />
          </Form.Item>
        </div>

        {/* ── 高级采集开关：开启后展开详细采集参数 ── */}
        <ToggleRow
          className="task-form__toggle"
          icon="sliders-horizontal"
          title={t("form.advanced", "启用高级采集")}
          description={t("form.advanced.desc", "开启后可自定义采集频率、上报协议与阈值，适用于高精度巡检场景。")}
          stateText={advanced ? t("form.advanced.on", "已开启") : t("form.advanced.off", "已关闭")}
          enabled={advanced}
          control={
            <Form.Item name="advanced" valuePropName="checked" noStyle>
              <Switch />
            </Form.Item>
          }
        />

        <p className="task-form__hint">
          <Icon name={advanced ? "circle-check" : "info"} size="0.875rem" />
          {advanced
            ? t("form.advanced.summary.on", "高级采集已开启，将按下列参数下发采集指令。")
            : t("form.advanced.summary.off", "当前使用默认采集策略（5 分钟 / SNMP v3）。")}
        </p>

        {advanced ? (
          <div className="task-form__advanced">
            <div className="task-form__advanced-head">
              <Icon name="sparkles" size="1rem" />
              <strong>{t("form.advanced.section", "采集参数")}</strong>
              <em>{t("form.advanced.section.desc", "仅高级采集开启时生效")}</em>
            </div>

            <div className="task-form__grid">
              <Form.Item label={t("form.freq", "采集频率")}>
                <FieldInline>
                  <Form.Item name="freq" noStyle>
                    <InputNumber min={1} max={1440} style={{ width: "100%" }} />
                  </Form.Item>
                  <Form.Item name="freqUnit" noStyle>
                    <Select options={unitOptions} style={{ width: "7rem" }} />
                  </Form.Item>
                </FieldInline>
              </Form.Item>

              <Form.Item label={t("form.sampling", "单次采样时长")}>
                <FieldInline>
                  <Form.Item name="sampling" noStyle>
                    <InputNumber min={5} max={600} style={{ width: "100%" }} />
                  </Form.Item>
                  <FieldInlineUnit>{t("form.sampling.suffix", "秒")}</FieldInlineUnit>
                </FieldInline>
              </Form.Item>

              <Form.Item label={t("form.concurrency", "并发采集数")}>
                <FieldInline>
                  <Form.Item name="concurrency" noStyle>
                    <InputNumber min={1} max={64} style={{ width: "100%" }} />
                  </Form.Item>
                  <FieldInlineUnit>{t("form.concurrency.suffix", "路")}</FieldInlineUnit>
                </FieldInline>
              </Form.Item>

              <Form.Item label={t("form.timeout", "超时阈值")}>
                <FieldInline>
                  <Form.Item name="timeout" noStyle>
                    <InputNumber min={100} max={60000} step={100} style={{ width: "100%" }} />
                  </Form.Item>
                  <FieldInlineUnit>{t("form.timeout.suffix", "毫秒")}</FieldInlineUnit>
                </FieldInline>
              </Form.Item>

              <Form.Item className="task-form__full" label={t("form.protocol", "上报协议")} name="protocol">
                <Radio.Group options={options(protocols)} optionType="button" buttonStyle="solid" />
              </Form.Item>

              <Form.Item label={t("form.receivers", "告警接收人")} name="receivers">
                <Select
                  mode="multiple"
                  maxTagCount="responsive"
                  placeholder={t("form.receivers.placeholder", "请选择接收人（可多选）")}
                  options={options(owners)}
                />
              </Form.Item>

              <Form.Item label={t("form.silence", "静默期开始")} name="silence">
                <TimePicker
                  format="HH:mm"
                  minuteStep={15}
                  className="u-full-width"
                  placeholder={t("form.silence.placeholder", "请选择时间")}
                />
              </Form.Item>

              <div className="task-form__full setting-row">
                <span className="setting-row__text">
                  <strong>{t("form.retry", "失败重试")}</strong>
                  <em>{t("form.retryTimes", "重试次数")}</em>
                </span>
                <span className="setting-row__action">
                  <Form.Item name="retry" valuePropName="checked" noStyle>
                    <Switch size="small" />
                  </Form.Item>
                  <Form.Item name="retryTimes" noStyle>
                    <InputNumber min={1} max={10} size="small" style={{ width: "5rem" }} />
                  </Form.Item>
                </span>
              </div>

              <div className="task-form__full setting-row">
                <span className="setting-row__text">
                  <strong>{t("form.deepScan", "深度扫描")}</strong>
                  <em>{t("form.deepScan.desc", "对关键节点执行全字段解析，耗时更长但指标更完整")}</em>
                </span>
                <span className="setting-row__action">
                  <Form.Item name="deepScan" valuePropName="checked" noStyle>
                    <Switch size="small" />
                  </Form.Item>
                </span>
              </div>
            </div>
          </div>
        ) : null}

        <div className="task-form__foot">
          <Button
            icon={<Icon name="rotate-ccw" size="0.875rem" />}
            onClick={() => {
              form.resetFields();
              message.success(t("toast.refreshed", "数据已刷新"));
            }}
          >
            {t("common.reset", "重置")}
          </Button>
          <Button icon={<Icon name="save" size="0.875rem" />} onClick={() => message.success(t("toast.draft", "草稿已保存"))}>
            {t("common.draft", "存为草稿")}
          </Button>
          <Button type="primary" htmlType="submit" icon={<Icon name="send" size="0.875rem" />}>
            {t("common.submit", "提交任务")}
          </Button>
        </div>
      </Form>
    </Panel>
  );
}
