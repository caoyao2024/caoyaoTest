// Layer 2: 导航结构数据 — 顶部模块与侧边菜单同源
// labelId / defaultLabel 交由 i18n 字典解析，图标名交 build 校验注入。

export const navModules = [
  {
    key: "overview",
    icon: "layout-dashboard",
    labelId: "nav.overview",
    defaultLabel: "概览",
    children: [
      { key: "ov-dashboard", icon: "gauge", labelId: "menu.ov.dashboard", defaultLabel: "全局概览" },
      { key: "ov-realtime", icon: "activity", labelId: "menu.ov.realtime", defaultLabel: "实时监控" },
      { key: "ov-capacity", icon: "database", labelId: "menu.ov.capacity", defaultLabel: "容量分析" },
      { key: "ov-report", icon: "file-text", labelId: "menu.ov.report", defaultLabel: "运营报表" },
    ],
  },
  {
    key: "tasks",
    icon: "clipboard-list",
    labelId: "nav.tasks",
    defaultLabel: "任务中心",
    children: [
      { key: "task-list", icon: "list-checks", labelId: "menu.tasks.list", defaultLabel: "任务列表" },
      { key: "task-template", icon: "layers", labelId: "menu.tasks.template", defaultLabel: "任务模板" },
      { key: "task-history", icon: "clipboard-check", labelId: "menu.tasks.history", defaultLabel: "执行记录" },
      { key: "task-policy", icon: "sliders-horizontal", labelId: "menu.tasks.policy", defaultLabel: "采集策略" },
      { key: "task-calendar", icon: "calendar-days", labelId: "menu.tasks.calendar", defaultLabel: "调度日历" },
    ],
  },
  {
    key: "devices",
    icon: "server",
    labelId: "nav.devices",
    defaultLabel: "设备资源",
    children: [
      { key: "dev-ledger", icon: "hard-drive", labelId: "menu.dev.ledger", defaultLabel: "设备台账" },
      { key: "dev-group", icon: "folder-tree", labelId: "menu.dev.group", defaultLabel: "分组管理" },
      { key: "dev-topology", icon: "network", labelId: "menu.dev.topology", defaultLabel: "拓扑视图" },
      { key: "dev-credential", icon: "key-round", labelId: "menu.dev.credential", defaultLabel: "凭证管理" },
    ],
  },
  {
    key: "alarms",
    icon: "bell-ring",
    labelId: "nav.alarms",
    defaultLabel: "告警中心",
    children: [
      { key: "alarm-active", icon: "triangle-alert", labelId: "menu.alarm.active", defaultLabel: "当前告警" },
      { key: "alarm-history", icon: "clock", labelId: "menu.alarm.history", defaultLabel: "历史告警" },
      { key: "alarm-rule", icon: "shield-check", labelId: "menu.alarm.rule", defaultLabel: "告警规则" },
      { key: "alarm-route", icon: "send", labelId: "menu.alarm.route", defaultLabel: "通知路由" },
    ],
  },
  {
    key: "settings",
    icon: "settings",
    labelId: "nav.settings",
    defaultLabel: "系统设置",
    children: [
      { key: "set-user", icon: "users", labelId: "menu.set.user", defaultLabel: "用户管理" },
      { key: "set-role", icon: "shield-check", labelId: "menu.set.role", defaultLabel: "角色权限" },
      { key: "set-param", icon: "sliders-horizontal", labelId: "menu.set.param", defaultLabel: "系统参数" },
      { key: "set-audit", icon: "clipboard-check", labelId: "menu.set.audit", defaultLabel: "操作审计" },
    ],
  },
];
