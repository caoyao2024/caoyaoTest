// Layer 2: 业务 Mock 数据 — 巡检任务域
// 选项型数据携带 zh / en 双语字段；状态与优先级携带 labelId 交由 i18n 字典解析。

export const taskTypes = [
  { value: "periodic", zh: "周期巡检", en: "Scheduled Inspection" },
  { value: "special", zh: "专项巡检", en: "Special Inspection" },
  { value: "discovery", zh: "自动发现", en: "Auto Discovery" },
  { value: "compliance", zh: "合规核查", en: "Compliance Audit" },
];

export const deviceGroups = [
  { value: "g1", zh: "华南-深圳核心网", en: "South · Shenzhen Core" },
  { value: "g2", zh: "华东-上海接入层", en: "East · Shanghai Access" },
  { value: "g3", zh: "华南-广州城域网", en: "South · Guangzhou MAN" },
  { value: "g4", zh: "华北-北京数据中心", en: "North · Beijing Data Center" },
  { value: "g5", zh: "华东-杭州汇聚环", en: "East · Hangzhou Aggregation" },
  { value: "g6", zh: "西部-成都出口链路", en: "West · Chengdu Egress" },
  { value: "g7", zh: "华中-武汉核心节点", en: "Central · Wuhan Core" },
  { value: "g8", zh: "华东-南京安全域", en: "East · Nanjing Security Zone" },
];

export const regions = [
  { value: "r1", zh: "华南", en: "South China" },
  { value: "r2", zh: "华东", en: "East China" },
  { value: "r3", zh: "华北", en: "North China" },
  { value: "r4", zh: "西部", en: "West China" },
];

export const owners = [
  { value: "u1", zh: "张启明", en: "Zhang Qiming" },
  { value: "u2", zh: "李思远", en: "Li Siyuan" },
  { value: "u3", zh: "王语宁", en: "Wang Yuning" },
  { value: "u4", zh: "陈立航", en: "Chen Lihang" },
  { value: "u5", zh: "赵敏", en: "Zhao Min" },
  { value: "u6", zh: "周子谦", en: "Zhou Ziqian" },
  { value: "u7", zh: "刘瀚文", en: "Liu Hanwen" },
  { value: "u8", zh: "孙若瑜", en: "Sun Ruoyu" },
];

export const protocols = [
  { value: "snmp", zh: "SNMP v3", en: "SNMP v3" },
  { value: "netconf", zh: "NETCONF", en: "NETCONF" },
  { value: "syslog", zh: "Syslog", en: "Syslog" },
  { value: "gnmi", zh: "gNMI", en: "gNMI" },
];

// tone → 语义色系（StatusTag 按 tone 取 token）
export const statusMap = {
  success: { tone: "success", labelId: "status.success", defaultLabel: "执行成功" },
  running: { tone: "info", labelId: "status.running", defaultLabel: "执行中" },
  queued: { tone: "critical", labelId: "status.queued", defaultLabel: "排队中" },
  failed: { tone: "error", labelId: "status.failed", defaultLabel: "执行失败" },
  warning: { tone: "warning", labelId: "status.warning", defaultLabel: "存在告警" },
  paused: { tone: "neutral", labelId: "status.paused", defaultLabel: "已暂停" },
  pending: { tone: "neutral", labelId: "status.pending", defaultLabel: "待执行" },
};

export const statusOptions = [
  { value: "success", labelId: "status.success", defaultLabel: "执行成功" },
  { value: "running", labelId: "status.running", defaultLabel: "执行中" },
  { value: "queued", labelId: "status.queued", defaultLabel: "排队中" },
  { value: "failed", labelId: "status.failed", defaultLabel: "执行失败" },
  { value: "warning", labelId: "status.warning", defaultLabel: "存在告警" },
  { value: "paused", labelId: "status.paused", defaultLabel: "已暂停" },
  { value: "pending", labelId: "status.pending", defaultLabel: "待执行" },
];

export const priorityMap = {
  high: { tone: "critical", labelId: "priority.high", defaultLabel: "高" },
  medium: { tone: "info", labelId: "priority.medium", defaultLabel: "中" },
  low: { tone: "neutral", labelId: "priority.low", defaultLabel: "低" },
};

export const tasks = [
  { id: "TSK-202601", nameZh: "深圳核心网夜间巡检", nameEn: "Shenzhen core nightly inspection", type: "periodic", group: "g1", region: "r1", status: "success", priority: "high", owner: "u1", lastRun: "2026-09-28 02:00", duration: "12m 30s", progress: 100, advanced: true },
  { id: "TSK-202602", nameZh: "上海接入层端口核查", nameEn: "Shanghai access layer port audit", type: "special", group: "g2", region: "r2", status: "running", priority: "high", owner: "u2", lastRun: "2026-09-28 09:15", duration: "04m 12s", progress: 62, advanced: true },
  { id: "TSK-202603", nameZh: "广州城域网光功率采集", nameEn: "Guangzhou MAN optical power collection", type: "periodic", group: "g3", region: "r1", status: "success", priority: "medium", owner: "u3", lastRun: "2026-09-28 06:30", duration: "08m 45s", progress: 100, advanced: false },
  { id: "TSK-202604", nameZh: "北京数据中心温控采集", nameEn: "Beijing DC thermal collection", type: "periodic", group: "g4", region: "r3", status: "warning", priority: "high", owner: "u4", lastRun: "2026-09-28 07:00", duration: "15m 02s", progress: 100, advanced: true },
  { id: "TSK-202605", nameZh: "杭州汇聚环带宽分析", nameEn: "Hangzhou aggregation bandwidth analysis", type: "special", group: "g5", region: "r2", status: "failed", priority: "high", owner: "u5", lastRun: "2026-09-27 23:40", duration: "02m 08s", progress: 34, advanced: true },
  { id: "TSK-202606", nameZh: "成都出口链路质量探测", nameEn: "Chengdu egress link quality probe", type: "periodic", group: "g6", region: "r4", status: "queued", priority: "medium", owner: "u6", lastRun: "2026-09-28 10:05", duration: "—", progress: 0, advanced: false },
  { id: "TSK-202607", nameZh: "武汉核心路由器配置备份", nameEn: "Wuhan core router configuration backup", type: "periodic", group: "g7", region: "r1", status: "success", priority: "high", owner: "u7", lastRun: "2026-09-28 01:20", duration: "21m 44s", progress: 100, advanced: true },
  { id: "TSK-202608", nameZh: "西安无线基站信号采集", nameEn: "Xi'an base station signal collection", type: "special", group: "g2", region: "r4", status: "paused", priority: "low", owner: "u8", lastRun: "2026-09-20 14:10", duration: "09m 31s", progress: 0, advanced: false },
  { id: "TSK-202609", nameZh: "南京防火墙策略合规核查", nameEn: "Nanjing firewall policy compliance audit", type: "compliance", group: "g8", region: "r2", status: "success", priority: "high", owner: "u1", lastRun: "2026-09-28 08:00", duration: "06m 19s", progress: 100, advanced: true },
  { id: "TSK-202610", nameZh: "苏州园区交换机资产发现", nameEn: "Suzhou campus switch asset discovery", type: "discovery", group: "g4", region: "r2", status: "success", priority: "medium", owner: "u2", lastRun: "2026-09-28 03:45", duration: "18m 07s", progress: 100, advanced: false },
  { id: "TSK-202611", nameZh: "天津环网链路丢包探测", nameEn: "Tianjin ring packet loss probe", type: "periodic", group: "g5", region: "r3", status: "warning", priority: "medium", owner: "u3", lastRun: "2026-09-28 05:12", duration: "07m 55s", progress: 100, advanced: true },
  { id: "TSK-202612", nameZh: "重庆骨干出口流量采集", nameEn: "Chongqing backbone egress traffic", type: "periodic", group: "g6", region: "r4", status: "running", priority: "high", owner: "u4", lastRun: "2026-09-28 10:20", duration: "03m 26s", progress: 48, advanced: true },
  { id: "TSK-202613", nameZh: "青岛海缆节点健康巡检", nameEn: "Qingdao submarine node health check", type: "periodic", group: "g1", region: "r3", status: "pending", priority: "medium", owner: "u5", lastRun: "2026-09-29 02:00", duration: "—", progress: 0, advanced: false },
  { id: "TSK-202614", nameZh: "长沙接入网电源采集", nameEn: "Changsha access network power collection", type: "periodic", group: "g2", region: "r1", status: "success", priority: "low", owner: "u6", lastRun: "2026-09-28 04:30", duration: "05m 48s", progress: 100, advanced: false },
  { id: "TSK-202615", nameZh: "郑州城域核心告警联动巡检", nameEn: "Zhengzhou MAN alarm linkage inspection", type: "special", group: "g3", region: "r3", status: "failed", priority: "high", owner: "u7", lastRun: "2026-09-27 22:05", duration: "01m 12s", progress: 12, advanced: true },
  { id: "TSK-202616", nameZh: "福州 OTN 波长性能采集", nameEn: "Fuzhou OTN wavelength performance", type: "periodic", group: "g4", region: "r2", status: "success", priority: "medium", owner: "u8", lastRun: "2026-09-28 06:00", duration: "11m 03s", progress: 100, advanced: true },
  { id: "TSK-202617", nameZh: "厦门园区 AP 射频扫描", nameEn: "Xiamen campus AP RF scan", type: "discovery", group: "g5", region: "r2", status: "paused", priority: "low", owner: "u1", lastRun: "2026-09-15 09:30", duration: "13m 20s", progress: 0, advanced: false },
  { id: "TSK-202618", nameZh: "合肥云计算资源池采集", nameEn: "Hefei cloud resource pool collection", type: "periodic", group: "g6", region: "r2", status: "success", priority: "medium", owner: "u2", lastRun: "2026-09-28 07:45", duration: "09m 58s", progress: 100, advanced: true },
  { id: "TSK-202619", nameZh: "济南专线隧道质量探测", nameEn: "Jinan leased line tunnel probe", type: "periodic", group: "g1", region: "r3", status: "queued", priority: "medium", owner: "u3", lastRun: "2026-09-28 10:10", duration: "—", progress: 0, advanced: false },
  { id: "TSK-202620", nameZh: "昆明基站能效采集", nameEn: "Kunming base station energy efficiency", type: "periodic", group: "g2", region: "r4", status: "warning", priority: "low", owner: "u4", lastRun: "2026-09-28 05:55", duration: "16m 37s", progress: 100, advanced: true },
  { id: "TSK-202621", nameZh: "沈阳汇聚设备配置核查", nameEn: "Shenyang aggregation configuration audit", type: "compliance", group: "g3", region: "r3", status: "success", priority: "high", owner: "u5", lastRun: "2026-09-28 02:40", duration: "10m 14s", progress: 100, advanced: true },
  { id: "TSK-202622", nameZh: "大连港区专网时延采集", nameEn: "Dalian port private network latency", type: "periodic", group: "g4", region: "r3", status: "running", priority: "medium", owner: "u6", lastRun: "2026-09-28 10:25", duration: "02m 51s", progress: 71, advanced: false },
  { id: "TSK-202623", nameZh: "南昌传输环告警核查", nameEn: "Nanchang transport ring alarm audit", type: "special", group: "g5", region: "r1", status: "pending", priority: "medium", owner: "u7", lastRun: "2026-09-29 01:30", duration: "—", progress: 0, advanced: false },
  { id: "TSK-202624", nameZh: "贵阳新区汇聚层巡检", nameEn: "Guiyang new district aggregation inspection", type: "periodic", group: "g6", region: "r4", status: "failed", priority: "high", owner: "u8", lastRun: "2026-09-27 19:30", duration: "00m 46s", progress: 8, advanced: true },
];

// 推荐采集策略（次级列表，可一键套用到表单）
export const policies = [
  {
    key: "p1",
    icon: "zap",
    tone: "critical",
    zh: "秒级高频采集",
    en: "Second-level polling",
    zhDesc: "适用核心链路质量监控",
    enDesc: "For core link quality monitoring",
    values: { freq: 10, freqUnit: "sec", sampling: 15, concurrency: 16, timeout: 1500, deepScan: true },
  },
  {
    key: "p2",
    icon: "activity",
    tone: "info",
    zh: "标准 5 分钟采集",
    en: "Standard 5-minute polling",
    zhDesc: "通用性能指标采集基线",
    enDesc: "Baseline for generic performance metrics",
    values: { freq: 5, freqUnit: "min", sampling: 30, concurrency: 8, timeout: 3000, deepScan: false },
  },
  {
    key: "p3",
    icon: "shield-check",
    tone: "success",
    zh: "合规核查采集",
    en: "Compliance audit polling",
    zhDesc: "配置与策略一致性比对",
    enDesc: "Config and policy consistency check",
    values: { freq: 30, freqUnit: "min", protocol: "netconf", timeout: 8000, deepScan: true },
  },
  {
    key: "p4",
    icon: "scan-line",
    tone: "neutral",
    zh: "资产自动发现",
    en: "Asset auto discovery",
    zhDesc: "周期性网段扫描与纳管",
    enDesc: "Periodic subnet scan and onboarding",
    values: { freq: 60, freqUnit: "min", protocol: "syslog", concurrency: 24, deepScan: false },
  },
  {
    key: "p5",
    icon: "hard-drive",
    tone: "neutral",
    zh: "配置备份采集",
    en: "Configuration backup",
    zhDesc: "变更前后配置快照留存",
    enDesc: "Snapshot config before and after change",
    values: { freq: 1, freqUnit: "hour", protocol: "netconf", retry: true, retryTimes: 3 },
  },
];

