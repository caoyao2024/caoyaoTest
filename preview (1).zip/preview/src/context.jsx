import { useState, useEffect, createContext, useContext } from "react";
import { navModules } from "./mock/nav.js";

// Layer 1: 全局状态 — 主题模式、语言、导航与侧边栏折叠
// 换肤单轨驱动:isDark 只切换 <html> 的 .dark class;
// 普通 H5 元素(token 四层)与 antd 组件(ant.css 换肤层)同源跟随,无需 React 参与换肤。
const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [isDark, setIsDark] = useState(false);
  const [lang, setLang] = useState("zh");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeModule, setActiveModule] = useState("tasks");
  const [activeSub, setActiveSub] = useState("task-list");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", isDark);
  }, [isDark]);

  useEffect(() => {
    document.documentElement.setAttribute("lang", lang === "zh" ? "zh-CN" : "en");
  }, [lang]);

  const value = {
    isDark,
    toggleDark: () => setIsDark((d) => !d),
    lang,
    setLang,
    sidebarCollapsed,
    toggleSidebar: () => setSidebarCollapsed((c) => !c),
    activeModule,
    activeSub,
    selectModule: (moduleKey) => {
      setActiveModule(moduleKey);
      const mod = navModules.find((m) => m.key === moduleKey);
      setActiveSub(mod && mod.children.length ? mod.children[0].key : "");
    },
    selectSub: setActiveSub,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  return useContext(AppContext);
}
