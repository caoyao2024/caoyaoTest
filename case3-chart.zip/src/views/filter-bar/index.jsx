// Layer 4: 筛选条 — 关键词搜索 / 时间范围切换 / 行业下拉 / 导出下拉，联动下方所有数据区
import Button from "@nce/eview-react/Button";
import { IconPlusIcBpitFileexcel, IconPlusIcPublicChevronDown, IconPlusIcPublicDownload, IconPlusIcPublicSearch, IconPlusIcPublicTxtFileTextured } from '@hui/icon-plus';
import TextField from "@/shared/TextField";
import SelectCard from "@nce/eview-react/SelectCard";
import Select from "@/shared/Select";
import Dropdown from "@/shared/Dropdown";
import { useApp } from "../../context.jsx";
import { useNotice } from "@/shared/useNotice";
import { CUSTOMER_COUNTS, INDUSTRY_OPTIONS, TIME_RANGES, getRiskCustomers } from "../../mock/dashboard.jsx";
import "./index.css";

const EXPORT_MENU_ITEMS = [
  { key: "excel", label: "导出 Excel", icon: <IconPlusIcBpitFileexcel iconSize="0.875rem" iconColor={['currentcolor']} /> },
  { key: "pdf", label: "导出 PDF", icon: <IconPlusIcPublicTxtFileTextured iconSize="0.875rem" iconColor={['currentcolor']} /> },
];

export default function FilterBar() {
  const { timeRange, setTimeRange, industry, setIndustry, keyword, setKeyword } = useApp();
  const { notify, noticeNode } = useNotice();

  const customerTotal = CUSTOMER_COUNTS[industry] != null ? CUSTOMER_COUNTS[industry] : CUSTOMER_COUNTS["全部行业"];
  const riskCount = getRiskCustomers(timeRange, industry, keyword).length;
  const isFilterActive = industry !== "全部行业" || keyword.trim() !== "";

  const handleExport = ({ key }) => {
    const format = key === "excel" ? "Excel" : "PDF";
    notify("success", `正在导出当前筛选结果（${format}），共 ${riskCount} 条风险记录…`);
  };

  const handleReset = () => {
    setKeyword("");
    setIndustry("全部行业");
    setTimeRange("30d");
    notify("default", "已重置筛选条件");
  };

  return (
    <section className="filter-bar">
      <span style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
        <TextField
          className="filter-search"
          value={keyword}
          onChange={(value) => setKeyword(value)}
          placeholder="搜索客户、行业或负责人"
          style={{ paddingRight: "1.75rem" }}
        />
        <IconPlusIcPublicSearch iconSize="0.875rem" iconColor={['var(--text-placeholder)']} style={{ position: "absolute", right: "0.5rem", pointerEvents: "none" }} />
      </span>
      <SelectCard
        data={TIME_RANGES.map((range) => ({ text: range.label, value: range.key }))}
        value={timeRange}
        onChange={(value) => setTimeRange(value)}
      />
      <Select
        className="filter-industry"
        value={industry}
        onChange={(value) => setIndustry(value)}
        options={INDUSTRY_OPTIONS.map((item) => ({ value: item, text: item }))}
      />
      <span className="filter-summary">
        在管客户 {customerTotal} 家 · 风险记录 {riskCount} 条
      </span>
      {isFilterActive ? (
        <a className="filter-reset" onClick={handleReset}>重置筛选</a>
      ) : null}
      <Dropdown menu={{ items: EXPORT_MENU_ITEMS, onClick: handleExport }} placement="bottomRight">
        <Button
          text="导出"
          leftIcon={<IconPlusIcPublicDownload iconSize="0.875rem" iconColor={['currentcolor']} />}
          rightIcon={<IconPlusIcPublicChevronDown iconSize="0.875rem" iconColor={['currentcolor']} className="filter-export-caret" />}
        />
      </Dropdown>
      {noticeNode}
    </section>
  );
}
