// Layer 4: 风险客户表格 — 12 行 / 状态页签（联动饼图与 KPI 下钻）/ 多选批量操作 / 行点击开详情抽屉 / 关键词搜索 / 排序筛选 / 分页
import { useEffect, useMemo, useState } from "react";
import { IconPlusIcCarUser, IconPlusIcPublicClipboard, IconPlusIcPublicEllipsis, IconPlusIcPublicEye, IconPlusIcPublicSearch, IconPlusIcPublicSend } from '@hui/icon-plus';
import Table from "@nce/eview-react/Table";
import Tab, { TabItem } from "@nce/eview-react/Tab";
import Button from "@nce/eview-react/Button";
import TextField from "@/shared/TextField";
import SimpleProgress from "@/shared/SimpleProgress";
import Dropdown from "@/shared/Dropdown";
import dayjs from "dayjs";
import SectionCard from "../../components/section-card/index.jsx";
import StatusTag from "../../components/status-tag/index.jsx";
import { useApp } from "../../context.jsx";
import { useNotice } from "@/shared/useNotice";
import { INDUSTRY_OPTIONS, TIME_RANGES, getRiskCustomers } from "../../mock/dashboard.jsx";
import "./index.css";

const STATUS_TABS = ["全部", "健康", "观察", "风险", "流失预警"];
const STATUS_ORDER = ["健康", "观察", "风险", "流失预警"];

const ROW_MENU_ITEMS = [
  { key: "detail", label: "查看详情", icon: <IconPlusIcPublicEye iconSize="0.875rem" iconColor={['currentcolor']} /> },
  { key: "change-owner", label: "修改负责人", icon: <IconPlusIcCarUser iconSize="0.875rem" iconColor={['currentcolor']} /> },
  { key: "watchlist", label: "加入观察名单", icon: <IconPlusIcPublicClipboard iconSize="0.875rem" iconColor={['currentcolor']} /> },
  { key: "transfer-csm", label: "转移 CSM", icon: <IconPlusIcPublicSend iconSize="0.875rem" iconColor={['currentcolor']} /> },
];

// 健康分语义色：健康=success / 观察=critical（警示橙）/ 风险与流失预警=error
function healthTone(score) {
  if (score >= 80) return "var(--success)";
  if (score >= 60) return "var(--critical)";
  return "var(--error)";
}

export default function RiskTable() {
  const {
    timeRange,
    industry,
    keyword,
    setKeyword,
    tableStatusFilter,
    setTableStatusFilter,
    openCustomerDrawer,
    openFollowUpModal,
    openTransferModal,
  } = useApp();
  const { notify, noticeNode } = useNotice();

  const [checkedIndexes, setCheckedIndexes] = useState([]);
  const [paginationState, setPaginationState] = useState({ current: 1, pageSize: 10 });

  const activeRange = TIME_RANGES.find((range) => range.key === timeRange);
  const rangeLabel = activeRange ? activeRange.label : "近30天";

  const filteredRows = useMemo(
    () => getRiskCustomers(timeRange, industry, keyword),
    [timeRange, industry, keyword]
  );

  const statusCounts = useMemo(() => {
    const counts = { 全部: filteredRows.length };
    STATUS_ORDER.forEach((status) => {
      counts[status] = filteredRows.filter((row) => row.status === status).length;
    });
    return counts;
  }, [filteredRows]);

  const tableRows = useMemo(
    () => (tableStatusFilter === "全部" ? filteredRows : filteredRows.filter((row) => row.status === tableStatusFilter)),
    [tableStatusFilter, filteredRows]
  );

  // 筛选或页签变化后回到第 1 页并清空勾选，避免越界页码与失效行序号
  useEffect(() => {
    setPaginationState((prev) => ({ ...prev, current: 1 }));
    setCheckedIndexes([]);
  }, [timeRange, industry, keyword, tableStatusFilter]);

  const handleRowAction = (action, record, event) => {
    if (event) event.stopPropagation();
    if (action === "follow") {
      openFollowUpModal({ mode: "follow", customerId: record.id });
      return;
    }
    if (action === "transfer") {
      openTransferModal({ customerId: record.id, customerName: record.companyName });
      return;
    }
    if (action === "detail") {
      openCustomerDrawer(record.id);
      return;
    }
    if (action === "change-owner" || action === "transfer-csm") {
      openTransferModal({ customerId: record.id, customerName: record.companyName });
      return;
    }
    if (action === "watchlist") {
      notify("success", `已将「${record.companyName}」加入观察名单`);
    }
  };

  // 行点击打开详情抽屉（选择列与操作列点击除外）
  const handleRowClick = (row, event) => {
    if (event && event.target && event.target.closest("input, label, .row-actions, a")) return;
    const record = row?.rawData;
    if (record) openCustomerDrawer(record.id);
  };

  const handleBulkFollow = () => {
    notify("success", `已为选中的 ${checkedIndexes.length} 家客户批量创建跟进任务`);
    setCheckedIndexes([]);
  };

  const handleBulkTransfer = () => {
    openTransferModal({ customerId: null, customerName: `选中的 ${checkedIndexes.length} 家客户` });
  };

  const columns = [
    {
      title: "公司名称",
      key: "companyName",
      allowSort: false,
      render: (cell, _rowData, _options, row) => (
        <a className="table-link" onClick={(event) => handleRowAction("detail", row?.rawData, event)}>{cell}</a>
      ),
    },
    {
      title: "行业",
      key: "industry",
      width: 104,
      allowSort: false,
    },
    {
      title: "健康分",
      key: "healthScore",
      width: 148,
      align: "right",
      render: (score) => (
        <div className="score-cell">
          <div className="score-cell-bar">
            <SimpleProgress percent={score} color={healthTone(score)} style={{ margin: 0 }} />
          </div>
          <span className="score-cell-num" style={{ color: healthTone(score) }}>{score}</span>
        </div>
      ),
    },
    {
      title: "CSM 负责人",
      key: "csm",
      width: 132,
      allowSort: false,
      render: (name) => (
        <span className="csm-cell">
          <img className="csm-avatar" src="/uploads/user.png" alt={name} />
          {name}
        </span>
      ),
    },
    {
      title: "续约日期",
      key: "renewalDate",
      width: 128,
      render: (date) => <span>{dayjs(date).format("YYYY-MM-DD")}</span>,
    },
    {
      title: "状态",
      key: "status",
      width: 116,
      allowSort: false,
      render: (status) => <StatusTag status={status} />,
    },
    {
      title: "操作",
      key: "actions",
      width: 188,
      allowSort: false,
      render: (_cell, _rowData, _options, row) => {
        const record = row?.rawData;
        return (
          <div
            className="row-actions"
            onClick={(event) => event.stopPropagation()}
            style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}
          >
            <a className="table-link" onClick={() => handleRowAction("follow", record)}>跟进</a>
            <a className="table-link" onClick={() => handleRowAction("transfer", record)}>转交</a>
            <Dropdown
              menu={{ items: ROW_MENU_ITEMS, onClick: ({ key }) => handleRowAction(key, record) }}
              placement="bottomRight"
            >
              <IconPlusIcPublicEllipsis iconSize="0.875rem" iconColor={['currentcolor']} className="row-more-icon" />
            </Dropdown>
          </div>
        );
      },
    },
  ];

  const statusTabIndex = Math.max(0, STATUS_TABS.indexOf(tableStatusFilter));
  const totalRecord = filteredRows.length;

  return (
    <SectionCard
      className="risk-table-card"
      title="风险客户跟进"
      subtitle={`数据范围：${rangeLabel} · ${industry}${keyword ? ` · 关键词「${keyword}」` : ""} · 共 ${totalRecord} 条 · 点击行查看详情`}
      actions={
        <span style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
          <TextField
            className="risk-table-search"
            size="small"
            value={keyword}
            onChange={(value) => setKeyword(value)}
            placeholder="搜索公司 / 负责人"
            style={{ paddingRight: "1.5rem" }}
          />
          <IconPlusIcPublicSearch iconSize="0.75rem" iconColor={['var(--text-placeholder)']} style={{ position: "absolute", right: "0.5rem", pointerEvents: "none" }} />
        </span>
      }
    >
      <Tab
        selectedIndex={statusTabIndex}
        draggable={false}
        onClick={(index, title) => setTableStatusFilter(title)}
        className="risk-table-tabs"
        tabContentStyle={{ height: 0, minHeight: 0, overflow: "hidden", padding: 0 }}
      >
        {STATUS_TABS.map((status) => (
          <TabItem
            key={status}
            title={status}
            titleExtraContent={<span className="status-tab-count">{statusCounts[status]}</span>}
          >
            <span />
          </TabItem>
        ))}
      </Tab>
      {checkedIndexes.length > 0 ? (
        <div className="bulk-bar">
          <span className="bulk-bar-count">已选 {checkedIndexes.length} 项</span>
          <Button size="small" text="批量跟进" onClick={handleBulkFollow} />
          <Button size="small" text="批量转交" onClick={handleBulkTransfer} />
          <a className="table-link" onClick={() => setCheckedIndexes([])}>清空</a>
        </div>
      ) : null}
      <Table
        columns={columns}
        dataset={tableRows}
        enableCheckBox
        checkType="multi"
        checkedRows={checkedIndexes}
        onRowCheck={(_row, checkedRows) => setCheckedIndexes(checkedRows)}
        onHeaderCheck={(checkedRows) => setCheckedIndexes(checkedRows)}
        onRowClick={handleRowClick}
        enableZebraCrossing={false}
        enableColumnCompareUpdate
        width="unset"
        enablePagination
        enableAutoPaging
        pagingProps={{
          currentPage: paginationState.current,
          pageSize: paginationState.pageSize,
          pageSizeOptions: [10, 12, 20],
          onPageSizeChange: (size) => setPaginationState({ current: 1, pageSize: size }),
        }}
        onPageChange={(currentPage) => setPaginationState((prev) => ({ ...prev, current: currentPage }))}
      />
      {noticeNode}
    </SectionCard>
  );
}
