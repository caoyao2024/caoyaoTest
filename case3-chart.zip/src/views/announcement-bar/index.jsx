// Layer 4: 产品公告 — 右下角悬浮组件：收起为胶囊按钮，展开为公告面板（轮播 + 左右切换 + 指示点），点击公告查看详情
import { useEffect, useRef, useState } from "react";
import { IconPlusIcPublicChevronDown, IconPlusIcPublicLeftArrow, IconPlusIcPublicNotice, IconPlusIcPublicRightArrow } from '@hui/icon-plus';
import Dialog from "@nce/eview-react/Dialog";
import Tag from "@/shared/Tag";
import { ANNOUNCEMENTS } from "../../mock/dashboard.jsx";
import "./index.css";

const AUTOPLAY_INTERVAL = 5000;

export default function AnnouncementBar() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [detail, setDetail] = useState(null);
  const [slideIndex, setSlideIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => {
    if (!isExpanded || isPaused || ANNOUNCEMENTS.length <= 1) return undefined;
    timerRef.current = setInterval(() => {
      setSlideIndex((prev) => (prev + 1) % ANNOUNCEMENTS.length);
    }, AUTOPLAY_INTERVAL);
    return () => clearInterval(timerRef.current);
  }, [isExpanded, isPaused]);

  const goPrev = () => {
    setSlideIndex((prev) => (prev - 1 + ANNOUNCEMENTS.length) % ANNOUNCEMENTS.length);
  };

  const goNext = () => {
    setSlideIndex((prev) => (prev + 1) % ANNOUNCEMENTS.length);
  };

  const current = ANNOUNCEMENTS[slideIndex];

  return (
    <div className="announce-float">
      {isExpanded ? (
        <div className="announce-panel" onMouseEnter={() => setIsPaused(true)} onMouseLeave={() => setIsPaused(false)}>
          <div className="announce-panel-head">
            <span className="announce-icon">
              <IconPlusIcPublicNotice iconSize="0.875rem" iconColor={['currentcolor']} />
            </span>
            <span className="announce-panel-title">产品公告</span>
            <button
              type="button"
              className="announce-collapse"
              title="收起公告"
              aria-label="收起公告"
              onClick={() => setIsExpanded(false)}
            >
              <IconPlusIcPublicChevronDown iconSize="0.875rem" iconColor={['currentcolor']} />
            </button>
          </div>
          <div className="announce-panel-body">
            <button type="button" className="announce-arrow" title="上一条" aria-label="上一条" onClick={goPrev}>
              <IconPlusIcPublicLeftArrow iconSize="0.875rem" iconColor={['currentcolor']} />
            </button>
            <div className="announce-carousel">
              <div
                key={current.id}
                className="announce-slide"
                onClick={() => setDetail(current)}
              >
                <div className="announce-slide-top">
                  <Tag color={current.tagColor} className="announce-tag">{current.tag}</Tag>
                  <span className="announce-slide-date">{current.date}</span>
                </div>
                <p className="announce-slide-title">{current.title}</p>
                <p className="announce-slide-desc">{current.description}</p>
              </div>
              <div className="announce-dots">
                {ANNOUNCEMENTS.map((item, i) => (
                  <span
                    key={item.id}
                    className={`announce-dot ${i === slideIndex ? "is-active" : ""}`}
                    onClick={() => setSlideIndex(i)}
                  />
                ))}
              </div>
            </div>
            <button type="button" className="announce-arrow" title="下一条" aria-label="下一条" onClick={goNext}>
              <IconPlusIcPublicRightArrow iconSize="0.875rem" iconColor={['currentcolor']} />
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          className="announce-fab-btn"
          title="展开产品公告"
          aria-label="展开产品公告"
          onClick={() => setIsExpanded(true)}
        >
          <IconPlusIcPublicNotice iconSize="1rem" iconColor={['currentcolor']} className="announce-fab-icon" />
          <span>产品公告</span>
          <span className="announce-fab-count">{ANNOUNCEMENTS.length}</span>
        </button>
      )}

      <Dialog
        isOpen={Boolean(detail)}
        title={
          detail ? (
            <span className="announce-detail-title">
              <Tag color={detail.tagColor} className="announce-tag">{detail.tag}</Tag>
              {detail.title}
            </span>
          ) : (
            ""
          )
        }
        onClose={() => setDetail(null)}
        size={["32rem", "auto"]}
        style={{ maxHeight: "80vh" }}
      >
        {detail ? (
          <div className="announce-detail">
            <p className="announce-detail-date">发布于 {detail.date}</p>
            <p className="announce-detail-text">{detail.description}</p>
            <p className="announce-detail-note">如需了解升级节奏与影响范围，请联系产品团队或在团队管理页查看排期。</p>
          </div>
        ) : null}
      </Dialog>
    </div>
  );
}
