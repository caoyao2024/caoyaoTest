// Layer 3: 图表卡右上角操作组 — 刷新 | 分隔线 | 设置 + 更多（Icon 组）
import { IconPlusIcPublicEllipsis, IconPlusIcPublicRefreshClockwise, IconPlusIcPublicSetting } from '@hui/icon-plus';
import { useNotice } from "@/shared/useNotice";
import "./index.css";

export default function ChartActions({ refreshText = "图表数据已刷新" }) {
  const { notify, noticeNode } = useNotice();

  const handleRefresh = () => {
    notify("success", refreshText);
  };

  return (
    <div className="chart-actions">
      <IconPlusIcPublicRefreshClockwise iconSize="1rem" iconColor={['currentcolor']} className="chart-action-icon" />
      <span className="chart-actions-divider" />
      <IconPlusIcPublicSetting iconSize="1rem" iconColor={['currentcolor']} className="chart-action-icon" onClick={() => notify("default", "已打开图表设置（演示）")} title="图表设置" />
      <IconPlusIcPublicEllipsis iconSize="1rem" iconColor={['currentcolor']} className="chart-action-icon" />
      {noticeNode}
    </div>
  );
}
