import { useEffect, useRef, useState } from "react";
import "./Dropdown.css";

export default function Dropdown({
  trigger = ["click"],
  placement = "bottomLeft",
  menu,
  dropdownRender,
  children,
  className = "",
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const isClick = Array.isArray(trigger)
    ? trigger.includes("click")
    : trigger === "click";

  useEffect(() => {
    if (!open) return undefined;
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const toggle = (e) => {
    if (e && typeof e.stopPropagation === "function") e.stopPropagation();
    setOpen((o) => !o);
  };

  const alignRight = String(placement).toLowerCase().includes("right");

  let overlay = null;
  if (open) {
    if (dropdownRender) {
      overlay = dropdownRender();
    } else if (menu) {
      overlay = (
        <ul className={`app-dropdown-menu ${className}`}>
          {menu.items?.map((item, i) =>
            item.type === "divider" ? (
              <li key={`divider-${i}`} className="app-dropdown-divider" />
            ) : (
              <li key={item.key ?? i} className="app-dropdown-li">
                <button
                  type="button"
                  className={`app-dropdown-item ${item.danger ? "is-danger" : ""}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    menu.onClick?.({ key: item.key, domEvent: e });
                    setOpen(false);
                  }}
                >
                  {item.icon ? (
                    <span className="app-dropdown-item-icon">{item.icon}</span>
                  ) : null}
                  <span>{item.label}</span>
                </button>
              </li>
            )
          )}
        </ul>
      );
    }
  }

  return (
    <span ref={ref} className="app-dropdown">
      <span className="app-dropdown-trigger" onClick={isClick ? toggle : undefined}>
        {children}
      </span>
      {overlay ? (
        <div className={`app-dropdown-overlay ${alignRight ? "is-right" : "is-left"}`}>
          {overlay}
        </div>
      ) : null}
    </span>
  );
}
