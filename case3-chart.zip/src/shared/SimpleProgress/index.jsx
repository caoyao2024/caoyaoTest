export { default } from "./SimpleProgress.jsx";
