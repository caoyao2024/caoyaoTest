export default function SimpleProgress({ percent, color = "var(--primary)", showLabel = false, style }) {
  const p = Math.min(100, Math.max(0, percent ?? 0));
  return (
    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", ...(style || {}) }}>
      <div
        style={{
          flex: 1,
          height: "0.5rem",
          background: "var(--hover, rgba(0,0,0,0.05))",
          borderRadius: "0.25rem",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${p}%`,
            height: "100%",
            background: color,
            transition: "width .2s",
          }}
        />
      </div>
      {showLabel ? (
        <span
          style={{
            color: "var(--on-surface-variant)",
            minWidth: "2.5rem",
            textAlign: "right",
          }}
        >
          {p}%
        </span>
      ) : null}
    </div>
  );
}
