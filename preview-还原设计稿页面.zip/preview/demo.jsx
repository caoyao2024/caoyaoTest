import { useEffect } from "react";
import { Icon } from "./assets/shared/icons.js";
import ChangeFlow from "./components/ChangeFlow/index.jsx";
import "./demo.css";

// 第 3 步「配置VPN实例」的关联命令行（点击该卡片后抽屉内代码块展示）
const VPN_CLI = `ip vpn-instance {vpnInstanceName}
  ipv4-family
    route-distinguisher {rtNum}:{tenantVni}
    vpn-target 0:{tenantVni} export-extcommunity
    vpn-target 0:{tenantVni} export-extcommunity evpn
    vpn-target 0:{tenantVni} import-extcommunity
    vpn-target 0:{tenantVni} import-extcommunity evpn
  description DCI_TEST_ac_router
  vxlan vni {tenantVni}`;

// 流程数据：默认形态（autoPlay 自动播放加载动画）
const flowSteps = [
  { title: "查询设备信息", action: "查询设备信息", params: ["Str.serverIp", "Str.mask"], commandLine: "display device information", no: 1 },
  { title: "创建 VLAN 200", action: "创建VLAN信息", params: ["Str.asnNum"], commandLine: "vlan 200", no: 2 },
  { title: "配置VPN实例", action: "配置VPN实例", params: ["Str.vpnInstanceName", "Str.asnNum"], commandLine: VPN_CLI, no: 3 },
  { title: "配置BGP邻居", action: "配置BGP邻居", params: ["Str.peerIp", "Str.asNum"], commandLine: "neighbor Str.peerIp as Str.asNum", no: 4 },
  { title: "成员端口加入聚合", action: "配置成员端口", params: ["Str.vpnInstanceName"], commandLine: "eth-trunk 200\ntrunkport interface 10GE 1/0/1", no: 5 },
  { title: "配置验证", action: "验证配置", params: ["Str.vpnInstanceName"], commandLine: "display ip vpn-instance", no: 6 },
];

// 折叠菜单栏图标项（第 4 个「列表」选中）
const railItems = [
  { icon: "house", label: "首页" },
  { icon: "message-square", label: "消息" },
  { icon: "bot", label: "机器人" },
  { icon: "list", label: "列表", active: true },
];

// header 右侧图标项
const headerActions = [
  { icon: "search", label: "搜索" },
  { icon: "circle-question-mark", label: "帮助" },
  { icon: "sun", label: "主题" },
];

// 左卡片「匹配动作」表格（8 行）
const actionTable = [
  { action: "查询设备信息", step: "查询设备信息", pkg: "queryDeviceInfo", desc: "查询设备信息" },
  { action: "创建VLAN信息", step: "创建 VLAN 200", pkg: "createVlan", desc: "创建VLAN信息" },
  { action: "创建聚合链路", step: "创建 Eth-Trunk200", pkg: "createEthTrunk", desc: "创建聚合链路" },
  { action: "配置VPN实例", step: "配置VPN实例", pkg: "configVpnInstance", desc: "配置VPN实例" },
  { action: "配置BGP邻居", step: "配置BGP邻居", pkg: "configBgpNeighbor", desc: "配置BGP邻居" },
  { action: "配置成员端口", step: "成员端口加入聚合", pkg: "configMemberPort", desc: "配置成员端口" },
  { action: "验证配置", step: "配置验证", pkg: "verifyConfig", desc: "验证配置" },
  { action: "扩容POD设备SDN控制", step: "扩容", pkg: "podExpandSdn", desc: "扩容POD设备SDN控制" },
];

export default function Demo() {
  // 整页深色：给 <html> 加 .dark，让全部 token 自动翻深色（ops 控制台风格）
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <div className="app-shell">
      {/* 顶部 header（48px） */}
      <header className="app-header">
        <div className="app-header-left">
          <button className="app-icon-btn" type="button" aria-label="菜单">
            <Icon name="menu" size={18} />
          </button>
          <div className="app-logo">
            <span className="app-logo-mark">
              <Icon name="network" size={18} color="#ffffff" />
            </span>
            <span className="app-logo-text">iMaster NCE</span>
          </div>
        </div>
        <div className="app-header-right">
          {headerActions.map((a, i) => (
            <button key={i} className="app-icon-btn" type="button" aria-label={a.label}>
              <Icon name={a.icon} size={18} />
            </button>
          ))}
          <button className="app-icon-btn" type="button" aria-label="用户">
            <Icon name="user" size={18} />
          </button>
          <span className="app-user-name">Admin</span>
        </div>
      </header>

      <div className="app-body">
        {/* 折叠菜单栏 */}
        <nav className="app-rail">
          <span className="app-rail-avatar" title="智能体">
            <Icon name="bot" size={24} color="#ffffff" />
          </span>
          <div className="app-rail-items">
            {railItems.map((it, i) => (
              <button
                key={i}
                className={`app-rail-item ${it.active ? "app-rail-item--active" : ""}`}
                type="button"
                aria-label={it.label}
                title={it.label}
              >
                <Icon name={it.icon} size={16} />
              </button>
            ))}
          </div>
          <button className="app-rail-toggle" type="button" aria-label="折叠展开" title="折叠/展开">
            <Icon name="panel-left-open" size={16} />
          </button>
        </nav>

        {/* 对话内容 */}
        <aside className="app-conv">
          <div className="app-conv-header">
            <button className="app-icon-btn" type="button" aria-label="返回">
              <Icon name="chevron-left" size={18} />
            </button>
            <span className="app-conv-title">创建应用互访工作流</span>
            <button className="app-icon-btn" type="button" aria-label="更多">
              <Icon name="ellipsis" size={18} />
            </button>
          </div>
          <div className="app-conv-list">
            {/* 右对话：用户提问 */}
            <div className="app-chat-msg app-chat-msg--right">
              <div className="app-chat-bubble">创建一个 DCI 到云端的应用互访工作流。</div>
            </div>

            {/* 左对话：智能体富文本卡片 */}
            <div className="app-chat-msg app-chat-msg--left">
              <div className="app-chat-bubble app-chat-bubble--rich">
                {/* 思考头：勾选 + 已完成思考 + 下折叠 */}
                <div className="chat-think">
                  <Icon name="check" size={14} />
                  <span className="chat-think-text">已完成思考</span>
                  <Icon name="chevron-down" size={14} className="chat-think-chevron" />
                </div>

                {/* 引言 */}
                <p className="chat-line">好的。已确认，为您重新整理匹配到对应的8个动作。</p>

                {/* 动作匹配表 */}
                <div className="chat-table-wrap">
                  <table className="chat-table">
                    <thead>
                      <tr>
                        <th>匹配动作</th>
                        <th>对应步骤</th>
                        <th>所属包</th>
                        <th>描述</th>
                      </tr>
                    </thead>
                    <tbody>
                      {actionTable.map((r, i) => (
                        <tr key={i}>
                          <td>
                            <span className="chat-action-tag">
                              <Icon name="circle-dot" size={12} color="#cb8efb" />
                              {r.action}
                            </span>
                          </td>
                          <td>{r.step}</td>
                          <td className="chat-mono">{r.pkg}</td>
                          <td>{r.desc}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* 下一步确认 + 提示 */}
                <p className="chat-line chat-line--bold">下一步确认</p>
                <p className="chat-line">请确认以上动作，是否要继续推导动作参数并生成工作流规划文档？</p>
                <p className="chat-line">（确认请回复“1”，如需调整请文字说明）</p>

                {/* 卡片底部：耗时 + 操作图标 */}
                <div className="chat-footer">
                  <span className="chat-time">耗时50s</span>
                  <div className="chat-actions">
                    <button className="chat-action-btn" type="button" aria-label="刷新"><Icon name="rotate-cw" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="复制"><Icon name="copy" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="点赞"><Icon name="thumbs-up" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="不认可"><Icon name="thumbs-down" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="更多"><Icon name="ellipsis" size={14} /></button>
                  </div>
                </div>
              </div>
            </div>

            {/* 右对话：确认回复 */}
            <div className="app-chat-msg app-chat-msg--right">
              <div className="app-chat-bubble">1</div>
            </div>

            {/* 第二个左对话卡片：内容配置 + 工作流规划文档小卡片 */}
            <div className="app-chat-msg app-chat-msg--left">
              <div className="app-chat-bubble app-chat-bubble--rich">
                <div className="chat-think">
                  <Icon name="check" size={14} />
                  <span className="chat-think-text">已完成思考</span>
                  <Icon name="chevron-down" size={14} className="chat-think-chevron" />
                </div>

                <p className="chat-line chat-line--bold">内容配置</p>
                <p className="chat-line chat-line--pre">{`1.意图解析：ACL规则add操作，单设备+条件分支模式，包含TCP/UDP协议分支
2.工作流步骤设计：查询设备→映射设备→检查ACL组→配置ACL组→根据协议类型配置规则
3.Action匹配：queryDevicesPaged、QueryAclGroup、ConfigAclGroup、ConfigSourceDestAclRule、ConfigSourceAclRule
4.参数推断：9个参数（devlp、aclGroupName、protocol、sourcelp、sourceMask、action、ruleId、destIp、destMask）
5.意图确认：逻辑完整，无遗漏
6.工作流编排：6个执行步骤，包含条件分支`}</p>

                <div className="chat-sub-card">
                  <Icon name="file-text" size={28} color="var(--primary)" />
                  <div className="chat-sub-card-body">
                    <div className="chat-sub-card-line1">
                      <span className="chat-sub-card-title">工作流设计方案</span>
                      <span className="chat-sub-card-tag">v1.0.1</span>
                    </div>
                    <div className="chat-sub-card-line2">
                      <span className="chat-sub-card-time">2026-06-23 13:56:32</span>
                      <span className="chat-sub-card-sep" />
                      <span className="chat-sub-card-desc">方案描述描述描述描述描述描述描述描述描述描述描述描述描述描述</span>
                    </div>
                  </div>
                </div>

                <p className="chat-line">工作流规划文档已生成，请确认文档全部内容，确认后开始执行工作流创建。</p>

                <div className="chat-footer">
                  <span className="chat-time">耗时50s</span>
                  <div className="chat-actions">
                    <button className="chat-action-btn" type="button" aria-label="刷新"><Icon name="rotate-cw" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="复制"><Icon name="copy" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="点赞"><Icon name="thumbs-up" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="不认可"><Icon name="thumbs-down" size={14} /></button>
                    <button className="chat-action-btn" type="button" aria-label="更多"><Icon name="ellipsis" size={14} /></button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 固定底部输入区 */}
          <div className="app-conv-footer">
            <div className="chat-input-actions">
              <button className="chat-input-btn" type="button">
                <Icon name="sliders-horizontal" size={16} />
                配置变量
              </button>
              <button className="chat-input-btn" type="button">
                <Icon name="file-pen" size={16} />
                MOP文档变更
              </button>
            </div>
            <div className="chat-input-wrap">
              <textarea className="chat-input" placeholder={'输入问题或输入"/"触发提示词'} rows={2} />
              <div className="chat-input-bar">
                <span className="chat-input-count">1/2000</span>
                <div className="chat-input-icons">
                  <button className="chat-input-icon" type="button" aria-label="附件"><Icon name="paperclip" size={20} /></button>
                  <button className="chat-input-icon" type="button" aria-label="语音"><Icon name="mic" size={20} /></button>
                  <button className="chat-input-send" type="button" aria-label="发送"><Icon name="send" size={20} /></button>
                </div>
              </div>
            </div>
            <div className="chat-input-hint">
              <Icon name="info" size={12} />
              <span>内容由AI生成，无法确保准确性和完整性，仅供参考。</span>
            </div>
          </div>
        </aside>

        {/* 内容展示区 */}
        <main className="app-content">
          <div className="app-content-topbar">
            <div className="app-content-topbar-left">
              <span className="app-content-title-group">
                <Icon name="layout-grid" size={14} />
                <h1 className="app-content-title">全景画布</h1>
              </span>
              <span className="app-content-divider" />
              <span className="app-content-tag">
                <Icon name="file-text" size={12} />
                工作流设计方案
                <button className="app-content-tag-close" type="button" aria-label="关闭">
                  <Icon name="x" size={12} />
                </button>
              </span>
            </div>
            <button className="app-icon-btn" type="button" aria-label="全屏">
              <Icon name="maximize-2" size={18} />
            </button>
          </div>
          <div className="app-content-body">
            <ChangeFlow
              title="20260623-DCI VPN实例配置-变更详情 V1.0"
              steps={flowSteps}
              loadingMs={3000}
            />
          </div>
        </main>
      </div>
    </div>
  );
}
